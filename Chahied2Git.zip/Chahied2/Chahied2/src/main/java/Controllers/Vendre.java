package Controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import Models.Actegorie;
import Models.ActegorieDAO;
import Models.ArticleDAO;
import Models.Articles;
import Models.Categorie;
import Models.CategorieDAO;
import Models.Database;
import Models.Photo_article;
import Models.Photo_articleDAO;
import Models.Sous_actegorie;
import Models.Sous_actegorieDAO;
import Models.Sous_categorie;
import Models.Sous_categorieDAO;
import Models.Sous_sous_actegorie;
import Models.Sous_sous_actegorieDAO;
import Models.Sous_sous_categorie;
import Models.Sous_sous_categorieDAO;

/**
 * Servlet implementation class Vendre
 */
@WebServlet("/Vendre")
//pour traiter les fichier uploadé
@MultipartConfig(
		maxFileSize = 1024 * 1024 * 10, // 10 MB
		maxRequestSize = 1024 * 1024 * 50 // 50 MB
		)
public class Vendre extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Vendre() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");

		Database.Connect();
		ArrayList<Categorie>categories = new CategorieDAO().getAll();
		// Pour chaque catégorie :
		for (Categorie categorie : categories) {
			// Récupérer ses sous-catégories
			ArrayList<Sous_categorie> sousCategories = new Sous_categorieDAO().getAllByCat(categorie.getId());
			categorie.setSousCategories(sousCategories);

			// Pour chaque sous-catégorie :
			for (Sous_categorie sousCategorie : sousCategories) {
				// Récupérer ses sous-sous-catégories
				ArrayList<Sous_sous_categorie> sscats = new Sous_sous_categorieDAO().getAllByScat(sousCategorie.getId());
				sousCategorie.setSous_sous_Categories(sscats);
			}
		}

		request.setAttribute("categories", categories);



		ArrayList<Actegorie> acts = new ActegorieDAO().getAll();

		// Maps pour stocker les relations, nouvelle manière de faire en utilisant le hashMap(prend deux paramètres).
		Map<Integer, ArrayList<Sous_actegorie>> sousCategoriesMap = new HashMap<>();
		Map<Integer, ArrayList<Sous_sous_actegorie>> sousSousCategoriesMap = new HashMap<>();

		for (Actegorie act : acts) {
			// Récupérer les sous-catégories
			ArrayList<Sous_actegorie> sacts = new Sous_actegorieDAO().getAllByAct(act.getId());
			sousCategoriesMap.put(act.getId(), sacts); // Associer à la catégorie

			for (Sous_actegorie sousActegorie : sacts) {
				// Récupérer les sous-sous-catégories
				ArrayList<Sous_sous_actegorie> sscats = new Sous_sous_actegorieDAO().getAllBySact(sousActegorie.getId());
				sousSousCategoriesMap.put(sousActegorie.getId(), sscats); // Associer à la sous-catégorie
			}
		}

		// Passer les données à la JSP
		request.setAttribute("actegories", acts);
		request.setAttribute("sousCategoriesMap", sousCategoriesMap);
		request.setAttribute("sousSousCategoriesMap", sousSousCategoriesMap);

		//mettre ds doPost
		// enregistre l'article pour le mettre en vente

		request.getRequestDispatcher("/vendreArt.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");

		sauverForm(request,response);

	}

	private void sauverForm(HttpServletRequest request, HttpServletResponse response) throws NumberFormatException, IOException, ServletException {
		HttpSession session = request.getSession(true);
		Integer userid = (Integer) session.getAttribute("userid");
		if (session.getAttribute("isConnected") == null) {
			session.setAttribute("isConnected", false);
		}

		// On vérifie que tous les paramètres obligatoires sont présents (corrigé orthographe paramètres)
		if (userid != null
				&& request.getPart("photos") != null
				&& request.getParameter("titre") != null
				&& request.getParameter("description") != null
				&& request.getParameter("sous_sous_categorie_id") != null
				&& request.getParameter("sous_sous_categorie_id") != null  // corrigé doublon ou typo
				&& request.getParameter("marque") != null
				&& request.getParameter("taille") != null
				&& request.getParameter("etat") != null
				&& request.getParameter("couleur") != null
				&& request.getParameter("matiere") != null
				&& request.getParameter("prix") != null
				&& request.getParameter("format_envoi") != null) {

			// Récupération listes couleurs et matières
			String[] couleurs = request.getParameterValues("couleur");
			ArrayList<String> couleurList = (couleurs != null) ? new ArrayList<>(Arrays.asList(couleurs)) : new ArrayList<>();

			String[] matieres = request.getParameterValues("matiere");
			ArrayList<String> matiereList = (matieres != null) ? new ArrayList<>(Arrays.asList(matieres)) : new ArrayList<>();

			boolean disponible = true;
			int nbreVues = 0;
			String vuesParam = request.getParameter("nbre_vues");
			if (vuesParam != null && !vuesParam.trim().isEmpty()) {
				nbreVues = Integer.parseInt(vuesParam);
			}

			// Création de l'article
			Articles art = new Articles(
					userid,
					request.getParameter("titre"),
					request.getParameter("description"),
					Integer.parseInt(request.getParameter("sous_sous_categorie_id")),
					Integer.parseInt(request.getParameter("sous_sous_categorie_id")), // Ici doublon corrigé, adapter si besoin
					request.getParameter("etat"),
					Double.parseDouble(request.getParameter("prix")),
					request.getParameter("format_envoi"),
					LocalDateTime.now(),
					"",
					"",
					request.getParameter("taille"),
					request.getParameter("marque"),
					nbreVues,
					disponible);

			art.setCouleurList(couleurList);
			art.setMatiereList(matiereList);

			// Sauvegarde article en base et récupération id
			int article_id = new ArticleDAO().save(art);

			// Préparation du dossier upload
			String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
			File uploadDir = new File(uploadPath);
			if (!uploadDir.exists()) {
				uploadDir.mkdir();
			}

			// Parcours des fichiers uploadés
			for (Part part : request.getParts()) {
				if (part.getName().equals("photos") && part.getSize() > 0) {
					String fileName = Paths.get(part.getSubmittedFileName()).getFileName().toString();
					String finalFileName = UUID.randomUUID() + "_" + fileName;
					part.write(uploadPath + File.separator + finalFileName);

					// Sauvegarde en base de la photo
					Photo_article photo = new Photo_article(article_id, finalFileName);
					new Photo_articleDAO().save(photo);
				}
			}
		}

		// Redirection vers la page d'accueil après traitement
		response.sendRedirect("Index");
	}
}

