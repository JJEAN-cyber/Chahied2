package Controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.ArticleDAO;
import Models.Articles;
import Models.Database;
import Models.FavoriDAO;
import Models.Photo_article;
import Models.Photo_articleDAO;
import Models.Utilisateur;

/**
 * Servlet implementation class Favori
 */
@WebServlet("/Favori")
public class Favori extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Favori() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Database.Connect();
		// ID utilisateur en session avec la clé "userId"
		Integer userid = (Integer) request.getSession().getAttribute("userid");
		request.setAttribute("userid", userid);

		if (userid == null) {
			// Utilisateur non connecté, rediriger vers page connexion
			response.sendRedirect("Connexion");
			return;
		}

		FavoriDAO favoriDAO = new FavoriDAO();
		ArticleDAO articleDAO = new ArticleDAO();
		Photo_articleDAO photoDAO = new Photo_articleDAO();

		// Récupérer les IDs favoris de l'utilisateur
		ArrayList<Integer> favorisIds = favoriDAO.getListArticlesByFavoriIdsByUserId(userid);

		// Charger les objets Articles
		ArrayList<Articles> favorisArts = new ArrayList<>();
		for (Integer id : favorisIds) {
			Articles art = articleDAO.getById(id);
			if (art != null) {
				favorisArts.add(art);
			}
		}

		// Charger les photos pour chaque article
		ArrayList<Photo_article> favorisPharts = new ArrayList<>();
		for (Articles art : favorisArts) {
			ArrayList<Photo_article> photos = photoDAO.getAllByArts(art.getId());
			favorisPharts.addAll(photos);
		}

		request.setAttribute("favorisArts", favorisArts);
		request.setAttribute("favorisPharts", favorisPharts);

		request.getRequestDispatcher("favori.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  Database.Connect();

	        HttpSession session = request.getSession(false);
	        Integer userid = (session != null) ? (Integer) session.getAttribute("userid") : null;

	        if (userid == null) {
	            response.sendRedirect("Connexion");
	            return;
	        }

	        String articleIdstr = request.getParameter("articleId");
	        if (articleIdstr != null) {
	            int articleId;
	            try {
	                articleId = Integer.parseInt(articleIdstr);
	            } catch (NumberFormatException e) {
	                articleId = -1;
	            }
	            if (articleId != -1) {
	                FavoriDAO favoriDAO = new FavoriDAO();
	                Set<Integer> favorisIds = favoriDAO.getFavorisIdsByUserId(userid);
	                if (favorisIds == null) {
	                    favorisIds = new HashSet<>();
	                }
	                if (favorisIds.contains(articleId)) {
	                    favoriDAO.supprimerFavori(userid, articleId);
	                } else {
	                    favoriDAO.ajouterFavori(userid, articleId);
	                }
	            }
	        }
	        doGet(request, response);
	    }
	}