package Controllers;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.ArticleDAO;
import Models.Articles;
import Models.Commande;
import Models.CommandeDAO;
import Models.ConversationDAO;
import Models.Database;
import Models.Message;
import Models.MessageDAO;
import Models.Panier;
import Models.Photo_article;
import Models.Photo_articleDAO;
import Models.Resume_commande;
import Models.Resume_commandeDAO;

@WebServlet("/Cashout5")
public class Cashout5 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Cashout5() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Database.Connect();

		// Debug paramètres reçus
		System.out.println("Param id: '" + request.getParameter("id") + "'");
		System.out.println("Param article_id: '" + request.getParameter("article_id") + "'");

		int artid = Integer.parseInt(request.getParameter("article_id"));

		// Chargement article complet
		Articles p = new ArticleDAO().getById(artid);

		// Photos (toutes ici, mais tu peux filtrer par article)/ici jai choisi de mettre une condition ds ma jsp au lieu de creer une methode allBy
		ArrayList<Photo_article> pharts = new Photo_articleDAO().getAll();

		// Passage à la JSP
		request.setAttribute("arts", p);
		request.setAttribute("pharts", pharts);

		//pour fil d'ariane recuperation de l'id pour page detail
		request.setAttribute("article_id", request.getParameter("article_id"));



//instanciation d'une session de stockage d'objet relative au panier fictif,important pour que l'utilisateur puisse tout le temps y avoir acces ds le cas d'un vrai panier
		HttpSession session = request.getSession(true);

		// Panier fictif
		Panier panier = (Panier) session.getAttribute("panier");
		if (panier == null) {
			panier = new Panier();
			session.setAttribute("panier", panier);
		}

		boolean commandeok = false;

		// Suppression d'un produit du panier
		if (request.getParameter("delete") != null) {
			int idproduit = Integer.parseInt(request.getParameter("delete"));
			panier.delete(idproduit);
			session.setAttribute("panier", panier);
			System.out.println("DELETE OK");
		}

		// Calcul des frais
		double totalArticles = p.getPrix();
		double fraisProtection = totalArticles * 0.10;
		double fraisPort = totalArticles * 0.20;
		double totalFraisCommande = totalArticles + fraisProtection + fraisPort;

		// Envoi à la JSP
		request.setAttribute("totalArticles", totalArticles);
		request.setAttribute("fraisProtection", fraisProtection);
		request.setAttribute("fraisPort", fraisPort);
		request.setAttribute("totalCommande", totalFraisCommande);

		// Validation commande
		if (request.getParameter("valider") != null) {
			CommandeDAO commandedao = new CommandeDAO();
			Resume_commandeDAO detaildao = new Resume_commandeDAO();

			int utilisateur_id = (int) session.getAttribute("userid");
			String adresse_livraison = request.getParameter("adresse");
			String option_livraison = request.getParameter("livraison");
			String telephone = request.getParameter("telephone");
			double montant_total = totalArticles;
			LocalDateTime date_commande = LocalDateTime.now();

			// 1️⃣ Création de la commande (sans article_id)
			Commande commande = new Commande(
					utilisateur_id,
					adresse_livraison,
					option_livraison,
					telephone,
					montant_total,
					date_commande
					);

			int commandeid = commandedao.save(commande);
			System.out.println("ID commande généré = " + commandeid);

			// 2️⃣ Ajout du résumé seulement si commande OK
			if (commandeid > 0) {
				Resume_commande d = new Resume_commande();
				d.setCommande_id(commandeid);     // ID de la commande généré par MySQL
				d.setArticle_id(p.getId());       // L'article acheté
				d.setTotal_commande(totalArticles);
				d.setFrais_protection_acheteur(fraisProtection);
				d.setFrais_port(fraisPort);
				d.setTotal_frais_commande(totalFraisCommande);
				detaildao.save(d);
				new ArticleDAO().setIndisponible(p.getId());


				// 1️⃣ Identifiants acheteur / vendeur : ICI on caste l'objet userid en integer on le type car il doit retourner une valeur integer
				int acheteurId = (int) session.getAttribute("userid");
				int vendeurId = new ArticleDAO().getOwnerId(p.getId());
				int articleId = p.getId();

				// 2️⃣ Récupération ou création de la conversation
				ConversationDAO conversationDAO = new ConversationDAO();
				int conversationId = conversationDAO.getOrCreateConversationId(acheteurId, vendeurId, articleId);

				if (conversationId > 0) {
					// 3️⃣ Création du message automatique
					Message m = new Message();
					m.setExpediteur_id(acheteurId);
					m.setDestinataire_id(vendeurId);
					m.setArticle_id(articleId);
					m.setConversation_id(conversationId);
					m.setContenu("Bonjour, votre article '" + p.getTitre() + "' a été acheté !");
					m.setDate_envoi(LocalDateTime.now());

					// 4️⃣ Sauvegarde du message
					new MessageDAO().save(m);
				} else {
					System.out.println("❌ Impossible de créer ou récupérer la conversation !");
				}

			}

			// 3️⃣ Vider le panier
			panier.vider();
			session.setAttribute("panier", panier);

			commandeok = true;

			// 4️⃣ Stocker l'id commande
			session.setAttribute("lastCommandeId", commandeid);

			// 5️⃣ Redirection confirmation
			response.sendRedirect("Commandeok");
			return;
		}

		// Si commande non validée → page recapitulative
		if (!commandeok) {
			request.getRequestDispatcher("/cashout2.jsp").forward(request, response);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
