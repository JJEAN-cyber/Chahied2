package Controllers;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.*;

@WebServlet("/Header")
public class Header extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Header() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       //ici je verifie que la requete recu http soit bien interprétée ave lencodage utf8 , pratique pour les symboles et accent
    	//Pareil pour l'envoi de requete
    	request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        Database.Connect();

        //On récupère la session HTTP si elle existe déjà (sans en créer une nouvelle).
        HttpSession session = request.getSession(false);
        //Si la session existe, on récupère l'attribut "userid" qui doit contenir l'identifiant de l'utilisateur connecté. Sinon, userid est null.
        Integer userid = (session != null) ? (Integer) session.getAttribute("userid") : null;
       
        String usernom = null;
        if (userid != null) {
        	//si il ya bien un identifiant de lutilisateur alors a laide dun objet dao utilisateurDAO(obliger de l'appler la method doit etre surement en static)
            UtilisateurDAO utilisateurDAO = new UtilisateurDAO();
            //On recupere lobjet utilisateur  par son id
            Utilisateur utilisateur = utilisateurDAO.getById(userid);
            if (utilisateur != null) {
            	//si l'objet n'est pas null alors on extirpe l'info qui est le nom de l'utilisateur.
                usernom = utilisateur.getNom(); 
            }
        }

        request.setAttribute("usernom", usernom);

        Database.Connect();

        // Récupérer et préparer tes catégories, sous-catégories et actégories
        // Je recupere une liste de categorie en apellant une methode getall qui retourne la liste de toute les categories qui est situé ds ctegorieDAO
        ArrayList<Categorie> categories = new CategorieDAO().getAll();
        //Je creer la boucle categorie
        for (Categorie categorie : categories) {
        	//ENsuite ds cette boucle je veux afficher la liste de sous categorie identifié par l'identifiant unique de la categorie a cliqué ou a surpassé par le biais de la methode qui me permet d'afficher la liste de sous categorie  par l'id d'une categorie pris en parametre
            ArrayList<Sous_categorie> sousCategories = new Sous_categorieDAO().getAllByCat(categorie.getId());
            //Ensuite je set donc je modifie et recupere les valeursqui sont la liste de sous categorie qui est ds mon entité que je recupere ds l'objet categorie
            categorie.setSousCategories(sousCategories); 
            //J'imbrique ma deuxieme boucle car non seulement les souscategorie doivent etre affichées (ce qui est fait)mais faut qu'elles permmettent d'afficher des sous sous categorie donc j'appel des sous categorie ds une boucle pour appeler l'objet sous sous categorieDAO par la methode qui permet d'afficher les sous sous categorie par sous categorie par une requete sql
            for (Sous_categorie sousCategorie : sousCategories) {
                ArrayList<Sous_sous_categorie> sscats = new Sous_sous_categorieDAO().getAllByScat(sousCategorie.getId());
                //:Maintenant jinsert  et modifie les valeurs de soussouscatgories qui se trouvent ds la table sous categorie pris ds la table et lentité sous sous categories tout sa ds l'objet sous categorie qui est sousCategorie(ds la deuxime boucle) 
                sousCategorie.setSous_sous_Categories(sscats);
            }
        }
        //echange entre vue et controlleur, la requete qui set et enregistre peut aller de la vue au controlleur ou du controlleur a la vue , cela s'appel un appel cest le role de la request(la requête http)
        request.setAttribute("categories", categories);

        ArrayList<Actegorie> actegories = new ActegorieDAO().getAll();
        for (Actegorie actegorie : actegories) {
            ArrayList<Sous_actegorie> sousActegories = new Sous_actegorieDAO().getAllByAct(actegorie.getId());
            actegorie.setSousActegories(sousActegories);
            for (Sous_actegorie sousActegorie : sousActegories) {
                ArrayList<Sous_sous_actegorie> ssacts = new Sous_sous_actegorieDAO().getAllBySact(sousActegorie.getId());
                sousActegorie.setSous_sous_Actegories(ssacts);
            }
        }
        request.setAttribute("actegories", actegories);

        System.out.println("HeaderServlet exécutée avec succès !");

        try {
            request.getRequestDispatcher("/headerBurger.jsp").include(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
