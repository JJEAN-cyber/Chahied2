package Controllers;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.ArticleDAO;
import Models.Articles;
import Models.Database;
import Models.Recherches;
import Models.RechercheDAO;
import Models.Sous_sous_categorie;
import Models.Sous_sous_categorieDAO;
import Models.Utilisateur;
import Models.UtilisateurDAO;

/**
 * Servlet implementation class MaRecherche
 */
@WebServlet("/MaRecherche")
public class MaRecherche extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MaRecherche() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Database.Connect();

		// Vérifier si l'utilisateur est connecté
		Integer userid = (Integer) request.getSession().getAttribute("userid");

		if (userid == null) {
			log("Attribut 'userid' absent dans la session");
		} else {
			log("Attribut 'userid' récupéré en session : " + userid);
			System.out.println("Attribut 'userid' récupéré en session (console) : " + userid);
		}



		String type = request.getParameter("type"); // Type de recherche (0: utilisateurs, 2: articles)
		String mot = request.getParameter("mot_cle");   // Mot-clé saisi


		int nombreResultats = 0;

		if (type != null && mot != null) {
			switch (type) {
			case "0":
				ArrayList<Utilisateur> utils = new UtilisateurDAO().RechercherUT(mot);

				request.setAttribute("utils", utils);
				nombreResultats = utils.size();
				break;

			case "1":
				ArrayList<Articles> arts = new ArticleDAO().RechercherART(mot);
				request.setAttribute("arts", arts);
				nombreResultats = arts.size();
				break;
			}
			if (userid != null && userid > 0) {
				Recherches r = new Recherches(mot,nombreResultats);
				r.setUtilisateur_id(userid);
				System.out.println("Insertion recherche : utilisateurId = " + userid + ", mot = " + mot + ", nombreResultats = " + nombreResultats); 
				new RechercheDAO().save(r);
			} else {
				System.out.println("Recherche non enregistrée : utilisateur non connecté ou id invalide");
			}

		}


		request.getRequestDispatcher("/maRecherche.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
