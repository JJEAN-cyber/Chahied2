package Controllers;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import Models.*;
//Annotation @WebServlet qui configure l’URL d’accès.
@WebServlet("/Chat4Bis")
public class Chat4Bis extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//connexion a la base de données
		Database.Connect();
		// recupération de l'id de lutilisateur ds la session
		Integer userid = (Integer) request.getSession().getAttribute("userid");
		if (userid == null) {
			response.sendRedirect("connexion.jsp");//ici on redirige ver la page connexion si userid est null et av le return on quitte la boucle pour pouvoir acceder a la messagerie en passant par l'inscription
			return;// quitter la methode et parfois on peut retourner une valeur
		}
		request.setAttribute("userId", userid);//permet de passer des résultats, des messages, des variables calculées, ou des objets du serveur à l’interface utilisateur pour affichage. 
		//setAttribute(nom, valeur) place une donnée dans l’objet request, avec une portée limitée à la requête courante.


		// Lecture paramètres
		String idConversation = request.getParameter("id");
		String articleIdStr = request.getParameter("article_id");
		String destIdStr = request.getParameter("destId");
		String destNom = request.getParameter("destNom");

		int destId = 0;
		int articleId = 0;


		//sert à convertir de manière sécurisée une chaîne de caractères (String) en entier (int), tout en évitant que le programme plante si la conversion échoue.
		try { if (destIdStr != null && !destIdStr.isEmpty()) destId = Integer.parseInt(destIdStr); } catch (Exception ignored) {}
		try { if (articleIdStr != null && !articleIdStr.isEmpty()) articleId = Integer.parseInt(articleIdStr); } catch (Exception ignored) {}

		// Conversations utilisateur
		ConversationDAO dao = new ConversationDAO();
		ArrayList<Conversation> listeConversations = dao.getConversationsWithArticle(userid);
		request.setAttribute("conv", listeConversations);

		// Charger article si possible
		if (articleId > 0) {
			ArticleDAO articleDAO = new ArticleDAO();
			Articles article = articleDAO.getById(articleId);
			request.setAttribute("art", article);
			request.setAttribute("titre", article != null ? article.getTitre() : "");
			request.setAttribute("prix", article != null ? article.getPrix() : "");

			// Charger photo principale
			Photo_articleDAO photoDAO = new Photo_articleDAO();
			ArrayList<Photo_article> photos = photoDAO.getAllByArt(articleId);
			String photoUrl = (photos != null && !photos.isEmpty()) ? "/uploads/" + photos.get(0).getChemin_fichier() : "";
			request.setAttribute("photo", photoUrl);
		}

		// Messages
		// creation objet message vide
		ArrayList<Message> messages = new ArrayList<>();
		//id conversation mis a zero
		int convId = 0;
		//tente de recuperer id conversation si c'est récupérer...
		if (idConversation != null && !idConversation.isEmpty()) {
			try {
				//Si la variable idConversation (souvent un paramètre reçu de la requête) est non nulle et non vide, on tente de la convertir en entier avec Integer.parseInt(idConversation).
				//Si la conversion réussit :On récupère les messages de cette conversation via MessageDAO().getMessagesByConversationId(convId).
				convId = Integer.parseInt(idConversation);
				messages = new MessageDAO().getMessagesByConversationId(convId);
			} catch (NumberFormatException ignored) {}//permet de recuperer les exception et de les ignorer pour ne pas faire planter.
		} else if (destId != 0 && articleId != 0) {
			//récupère ou crée une conversation liant ces trois entités.
			convId = dao.getOrCreateConversationId(userid, destId, articleId);
			if (convId > 0) {
				//Si un identifiant de conversation est obtenu (convId > 0), on récupère aussi les messages correspondants à cette conversation.
				messages = new MessageDAO().getMessagesByConversationId(convId);
			}
		}

		// Attributs
		request.setAttribute("messages", messages);
		request.setAttribute("idConversation", convId != 0 ? String.valueOf(convId) : null);
		request.setAttribute("destId", destId);
		request.setAttribute("article_id", articleId);
		request.setAttribute("destNom", destNom);

		request.getRequestDispatcher("/chat4.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Database.Connect();
		// recuperation de lid de lutilisateur emetteur pour envoyer message
		Integer expediteurId = (Integer) request.getSession().getAttribute("userid");
		if (expediteurId == null) {
			response.sendRedirect("connexion.jsp");
			return;
		}

		// recuperation des parametre envoyé par le client
		int articleId = Integer.parseInt(request.getParameter("article_id"));
		int destinataireId = Integer.parseInt(request.getParameter("destinataire_id"));
		String contenu = request.getParameter("contenu");
		//Cette méthode vérifie s’il existe une conversation entre l’expéditeur, le destinataire et pour cet article.Si elle n’existe pas, elle la crée.Elle retourne l’ID de la conversation.
		int conversationId = new ConversationDAO().getOrCreateConversationId(expediteurId, destinataireId, articleId);
		//Envoi du message si la requête contient le paramètre d’envoi
		if (request.getParameter("bmessage") != null && conversationId > 0) {
			//La méthode send_message_and_update_conversation ajoute le message et met à jour la conversation (par ex. date dernier message, statut, etc.).
			new MessageDAO().send_message_and_update_conversation(
					expediteurId,
					destinataireId,
					contenu,
					Timestamp.valueOf(LocalDateTime.now()),
					articleId,
					conversationId
					);
		}
		//Après l’envoi du message, on redirige vers la page de dialogue/chat en fournissant les paramètres nécessaires pour afficher la conversation correcte.
		// Redirection vers GET -> évite doublons et garde les attributs OK
		response.sendRedirect("Chat4Bis?id=" + conversationId + "&article_id=" + articleId + "&destId=" + destinataireId + "&destNom=" + request.getParameter("destNom"));
	}
}
