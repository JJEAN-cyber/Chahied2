package Controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.ArticleDAO;
import Models.Articles;
import Models.Database;
import Models.Photo_articleDAO;
import Models.Sous_sous_actegorie;
import Models.Sous_sous_actegorieDAO;
import Models.Sous_sous_categorie;
import Models.Sous_sous_categorieDAO;

/**
 * Servlet implementation class LaSous_sous_actegorie
 */
@WebServlet("/LaSous_sous_actegorie")
public class LaSous_sous_actegorie extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LaSous_sous_actegorie() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");


		Database.Connect();

		// Récupération de l'id passé en paramètre
		int actid = Integer.parseInt(request.getParameter("id"));

		// Récupération de la sous-sous-catégorie
		Sous_sous_actegorie c = new Sous_sous_actegorieDAO().getById(actid);
		System.out.println("sscat récupéré : " + c);
		if (c == null) {
			System.out.println("Attention : Sous_sous_actegorie introuvable pour id = " + actid);
		}


		// DAO pour récupérer photos et articles
		Photo_articleDAO photoDAO = new Photo_articleDAO();
		ArrayList<Articles> arts = new ArticleDAO().getAllByAct(actid); // Assure-toi que c'est bien filtré par sous-sous-catégorie

		// Création d'une HashMap pour stocker les images de chaque article
		HashMap<Integer, String> photos = new HashMap<>();
		for (Articles a : arts) {
			String images = photoDAO.getPhotosByIdArt(a.getId());
			photos.put(a.getId(), images);
		}

		// Passage des attributs à la JSP
		request.setAttribute("ssact", c);
		request.setAttribute("arts", arts);
		request.setAttribute("photos", photos);

		// Forward vers la JSP
		request.getRequestDispatcher("laSous_sous_actegorie.jsp").forward(request, response);
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
