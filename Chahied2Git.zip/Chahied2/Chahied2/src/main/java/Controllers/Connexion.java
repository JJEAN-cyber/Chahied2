package Controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import Models.Database;
import Models.Trace_connexion_user;
import Models.Trace_connexion_userDAO;
import Models.Utilisateur;
import Models.UtilisateurDAO;




@WebServlet("/Connexion")
public class Connexion extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Connexion() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
    	boolean messageInscriptionOk = false;
    	boolean messageConnexionNo = false;
    	boolean connected = false;

    	try {
    	    Database.Connect(); // On ouvre la connexion au début de la requête

    	    if (Database.connexion == null) {
    	        System.err.println("ERREUR : Connexion à la base non établie !");
    	        request.setAttribute("errorMessage", "Impossible de se connecter à la base.");
    	    } else {

    	        // Traitement inscription
    	        if (request.getParameter("binscription") != null) {
    	            String password = request.getParameter("ipassword");
    	            String nom = request.getParameter("inom");
    	            String email = request.getParameter("iemail");

    	            if (password == null || password.length() < 12) {
    	                request.setAttribute("errorMessage", "Le mot de passe doit contenir au moins 12 caractères.");
    	                messageInscriptionOk = false;
    	            } else {
    	                String hashedPassword = Util.PasswordHasher.hash(password);
    	                UtilisateurDAO utilisateurDao = new UtilisateurDAO();
    	                boolean isBanned = false;
    	                Utilisateur u = new Utilisateur(
    	                        nom,
    	                        email,
    	                        hashedPassword,
    	                        Timestamp.valueOf(LocalDateTime.now()),
    	                        null, null, null, null,
    	                        isBanned,
    	                        null
    	                );
    	                try {
    	                    utilisateurDao.save(u);
    	                    System.out.println("INSCRIPTION OK");
    	                    messageInscriptionOk = true;
    	                } catch (SQLException ex) {
    	                    System.err.println("ERREUR INSCRIPTION : " + ex.getMessage());
    	                    request.setAttribute("errorMessage", "Cet email existe déjà.");
    	                    messageInscriptionOk = false;
    	                }
    	            }
    	        }
    	        request.setAttribute("messageinscriptionok", messageInscriptionOk);

    	        // Traitement connexion
    	        if (request.getParameter("bconnexion") != null) {
    	            String email = request.getParameter("cemail");
    	            String password = request.getParameter("cpassword");
// ici j'appelle utilisateurdao car la methode que jappelle après est static.
    	            UtilisateurDAO utilisateurDao = new UtilisateurDAO();
    	            Utilisateur u = utilisateurDao.findByEmail(email);
    	            if (u == null || u.getIsBanned()) {
    	                System.out.println("CONNEXION REFUSÉE");
    	                messageConnexionNo = true;
    	            } else {
    	                String motDePasseStocke = u.getMot_de_passe();

    	                if (motDePasseStocke != null &&
    	                        (motDePasseStocke.startsWith("$2a$") || motDePasseStocke.startsWith("$2b$") || motDePasseStocke.startsWith("$2y$"))) {
    	                    // Mot de passe hashé
    	                    if (Util.PasswordHasher.verify(password, motDePasseStocke)) {
    	                        System.out.println("CONNEXION OK");
    	                        HttpSession session = request.getSession(true);
    	                        session.setAttribute("userid", u.getId());
    	                        session.setAttribute("isConnected", true);
    	                        session.setAttribute("Isbanned", u.getIsBanned());
// ici je creer un log de verification d'utilisateur qui se connect au sie et me permet d'avoir leur adresse ip
    	                        String userIp = request.getHeader("X-Forwarded-For");
    	                        if (userIp == null || userIp.isEmpty() || "unknown".equalsIgnoreCase(userIp)) {
    	                            userIp = request.getRemoteAddr();
    	                        }
    	                        String userAgent = request.getHeader("User-Agent");
    	                        Timestamp loginDate = Timestamp.valueOf(LocalDateTime.now());
    	                        Trace_connexion_user trace = new Trace_connexion_user(u.getId(), u.getId(), userIp, userAgent, loginDate);
    	                        Trace_connexion_userDAO traceDAO = new Trace_connexion_userDAO();
    	                        traceDAO.insertConnexion(trace);

    	                        connected = true;
    	                        response.sendRedirect("Index");
    	                        return;
    	                    } else {
    	                        System.out.println("Mot de passe incorrect.");
    	                        messageConnexionNo = true;
    	                    }
    	                } else {
    	                	//ici cela concerne mes utilisateurs qui se sont inscrit avant que je code avec jbcrypt et mettre a jour leur mot de passe  avec jbcrypt permettant le hashage du mot de basse jusuqen bae de données.
    	                    // Mot de passe en clair - migration vers hashage
    	                    if (password.equals(motDePasseStocke)) {
    	                        System.out.println("CONNEXION OK (Migration mot de passe en clair vers hashage)");
    	                        String hashedPassword = Util.PasswordHasher.hash(password);
    	                        u.setMot_de_passe(hashedPassword);
    	                        utilisateurDao.updateMotDePasse(u);

    	                        HttpSession session = request.getSession(true);
    	                        session.setAttribute("userid", u.getId());
    	                        session.setAttribute("isConnected", true);
    	                        session.setAttribute("Isbanned", u.getIsBanned());

    	                        String userIp = request.getHeader("X-Forwarded-For");
    	                        if (userIp == null || userIp.isEmpty() || "unknown".equalsIgnoreCase(userIp)) {
    	                            userIp = request.getRemoteAddr();
    	                        }
    	                        String userAgent = request.getHeader("User-Agent");
    	                        Timestamp loginDate = Timestamp.valueOf(LocalDateTime.now());
    	                        Trace_connexion_user trace = new Trace_connexion_user(u.getId(), u.getId(), userIp, userAgent, loginDate);
    	                        Trace_connexion_userDAO traceDAO = new Trace_connexion_userDAO();
    	                        traceDAO.insertConnexion(trace);

    	                        connected = true;
    	                        response.sendRedirect("Index");
    	                        return;
    	                    } else {
    	                        System.out.println("Mot de passe incorrect.");
    	                        messageConnexionNo = true;
    	                    }
    	                }
    	            }
    	        }
    	        request.setAttribute("messageconnexionno", messageConnexionNo);
    	    }
    	} catch (SQLException ex) {
    	    System.err.println("ERREUR BASE DE DONNÉES: " + ex.getMessage());
    	    request.setAttribute("errorMessage", "Problème technique, réessayez plus tard.");
    	} finally {
    	    Database.closeConnection(); // Fermeture garantie
    	}

    	if (!connected) {
    	    request.getRequestDispatcher("/connexion.jsp").forward(request, response);
    	}
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}
