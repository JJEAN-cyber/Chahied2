package Controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.ArticleDAO;
import Models.Articles;
import Models.Database;
import Models.FavoriDAO;
import Models.Photo_article;
import Models.Photo_articleDAO;

/**
 * Servlet implementation class Index
 */
@WebServlet("/Index")
public class Index extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Index() {
        super();
    }

    /**
     * Cette méthode doGet est appelée lors d'une requête GET vers /Index
     * Elle prépare les données à afficher côté JSP (articles, photos, favoris)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // On définit l'encodage pour la requête (formulaire) et la réponse (page HTML)
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        // Connexion à la base (assure-toi que ta classe Database.Connect() fonctionne bien)
        Database.Connect();

        // Récupération de l'id utilisateur stocké en session, ou null si non connecté
        Integer userid = (Integer) request.getSession().getAttribute("userid");
        // On met userid dans les attributs de la requête pour éventuellement l'afficher côté JSP
        request.setAttribute("userid", userid);

        // Récupération de la liste complète des articles depuis la base via le DAO ArticleDAO
        ArrayList<Articles> arts = new ArticleDAO().getAll();
        // On met cette liste dans la requête pour que la JSP puisse la parcourir et afficher les articles
        request.setAttribute("arts", arts);

        // Même chose pour la liste des photos d'articles
        ArrayList<Photo_article> pharts = new Photo_articleDAO().getAll();
        request.setAttribute("pharts", pharts);

        // Initialisation d'un ensemble pour contenir les IDs des favoris utilisateur
        Set<Integer> favorisIds = new HashSet<>();

        // Si utilisateur connecté (userid non null)
        if (userid != null) {
            FavoriDAO favoriDAO = new FavoriDAO();
            // On récupère les favoris de l'utilisateur depuis la base sous forme de Set (pas de doublon)
            Set<Integer> temp = favoriDAO.getFavorisIdsByUserId(userid);
            // Si temp n'est pas null, on remplace favorisIds par temp
            if (temp != null) {
                favorisIds = temp;
            }
            // Affichage debug dans la console serveur (optionnel, à retirer en production)
            System.out.println("Favoris trouvés pour userId " + userid + " : " + favorisIds);
        }

        // Passage de la collection favorisIds à la JSP via la requête
        request.setAttribute("favorisIds", favorisIds);

        // Clique ici tu peux rajouter d'autres traitements avant affichage ...

        // Log simple pour vérifier que la servlet est bien appelée
        System.out.println("Index Servlet appelée !");

        // Transfert de la requête et réponse vers la JSP index.jsp
        try {
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * La méthode doPost traite les requêtes POST (souvent formulaires)
     * Ici, elle sert à gérer l'ajout ou suppression d'un favori selon l'existence actuelle.
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Récupération de l'id utilisateur depuis la session
        Integer userid = (Integer) request.getSession().getAttribute("userid");

        // Récupération de l'identifiant de l'article depuis la requête POST
        String articleIdstr = request.getParameter("articleId");

        // Vérification que userid et articleIdstr ne sont pas null
        if (userid != null && articleIdstr != null) {
            int articleId = Integer.parseInt(articleIdstr); // conversion String -> int

            FavoriDAO favoriDAO = new FavoriDAO();
            // On récupère les favoris actuels de l'utilisateur
            Set<Integer> favorisIds = favoriDAO.getFavorisIdsByUserId(userid);
            if (favorisIds == null) {
                favorisIds = new HashSet<>();
            }

            // Si l'article est déjà dans la liste des favoris on supprime, sinon on ajoute
            if (favorisIds.contains(articleId)) {
                favoriDAO.supprimerFavori(userid, articleId);
                System.out.println("Article " + articleId + " retiré des favoris pour user " + userid);
            } else {
                favoriDAO.ajouterFavori(userid, articleId);
                System.out.println("Article " + articleId + " ajouté aux favoris pour user " + userid);
            }
        }

        // On rappelle doGet pour recharger la page index avec données à jour (favoris modifiés)
        doGet(request, response);
    }
}
