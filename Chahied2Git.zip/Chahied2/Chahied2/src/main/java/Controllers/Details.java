package Controllers;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.ArticleDAO;
import Models.Articles;
import Models.Database;
import Models.FavoriDAO;
import Models.Photo_article;
import Models.Photo_articleDAO;
import Models.Utilisateur;
import Models.UtilisateurDAO;

/**
 * Servlet implementation class Details
 */
@WebServlet("/Details")
public class Details extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Details() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//connexion a la bas de données permettre le flux 
		Database.Connect();
		//recuperation ds la session de l'utilisateur id
		Integer userid = (Integer) request.getSession().getAttribute("userid");
		//passage a la jsp de la valeur
		request.setAttribute("userid", userid);
		//recupration de l'id de l'article
		int artid=Integer.parseInt(request.getParameter("id"));
		// Incrémenter le nombre de vues
		ArticleDAO artdao = new ArticleDAO();
		int vues = artdao.incrementerEtGetNbreVues(artid);
		System.out.println("Nombre de vues à jour : " + vues);
		// Récupérer le nombre de vues pour affichage
		request.setAttribute("nbreVues", vues);

		//recuperer le nbre de favori pour l'article
		//creation objet vide de favoridao
		FavoriDAO favdao = new FavoriDAO();
		int fav = favdao.getNbreFavoris(artid);
		request.setAttribute("nbreFavoris", fav);
		//recuperation de l'objet article par son id par la methode getbyid
		Articles p = new ArticleDAO().getById(artid);
		request.setAttribute("art", p);
		// pour recuperer l'utilisateur de l'article pour la messagerie dans le bouton que je passe en parametre.
		int utilisateurId = p.getUtilisateur_id(); 
		
		Utilisateur utilisateur = new UtilisateurDAO().getById(utilisateurId); // récupère le vendeur de l'article
		request.setAttribute("utilisateur", utilisateur);
		
		ArrayList<Articles> arts = new ArticleDAO().getAll();
		request.setAttribute("arts", arts);

		ArrayList<Photo_article> pharts = new Photo_articleDAO().getAll();
		request.setAttribute("pharts",pharts);


		request.getRequestDispatcher("/details3.jsp").forward(request, response);
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
