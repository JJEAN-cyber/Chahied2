package Models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class RechercheDAO {
	public void save(Recherches r) {
	    String sql = "INSERT INTO recherche (utilisateur_id, mot_cle, nombre_resultats) VALUES (?, ?, ?)";
	    try (PreparedStatement preparedStatement = Database.connexion.prepareStatement(sql)) {
	        preparedStatement.setInt(1, r.getUtilisateur_id());
	        preparedStatement.setString(2, r.getMot_cle());
	        preparedStatement.setInt(3, r.getNombre_resultats());
	        preparedStatement.executeUpdate();

	        System.out.println("SAVED OK");
	    } catch (Exception ex) {
	        ex.printStackTrace();
	        System.out.println("SAVED NO");
	    }
	}

	 // Recherche les articles ou utilisateurs par mot clé
    public ArrayList<Articles> searchByKeyword(String motCle) throws Exception {
        ArrayList<Articles> results = new ArrayList<>();

        // Exemple de requête qui cherche dans les articles ou dans le nom utilisateur
        String sql = "SELECT a.* FROM articles a "
                   + "JOIN utilisateur u ON a.utilisateur_id = u.id "
                   + "WHERE a.titre LIKE ? OR u.nom LIKE ?";

        PreparedStatement ps = Database.connexion.prepareStatement(sql);
        String likeMotCle = "%" + motCle + "%";
        ps.setString(1, likeMotCle);
        ps.setString(2, likeMotCle);

        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Articles art = new Articles();
            art.setId(rs.getInt("id"));
            art.setTitre(rs.getString("titre"));
            art.setPrix(rs.getDouble("prix"));
            art.setUtilisateur_id(rs.getInt("utilisateur_id"));
            // récupérer d'autres champs nécessaires
            results.add(art);
        }
        return results;
    }

public Recherches getById(int id) {
	try {
	
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM recherche WHERE id=?");
			preparedStatement.setInt(1,id);
			
			ResultSet resultat=preparedStatement.executeQuery();
			
			Recherches u = new Recherches();
			if(resultat.next()) {
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt( "utilisateur_id" ));
				u.setMot_cle(resultat.getString( "mot_cle" ));
				u.setNombre_resultats(resultat.getInt( "nombre_resultats" ));
			
			}
			
			return u;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}


public ArrayList<Recherches> getAll() {
	ArrayList<Recherches> list = new ArrayList<Recherches>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM recherche");
			
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Recherches u = new Recherches();
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt( "utilisateur_id" ));
				u.setMot_cle(resultat.getString( "mot_cle" ));
				u.setNombre_resultats(resultat.getInt( "nombre_resultats" ));
			
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}



public void deleteById(int id) {
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM recherche WHERE id=?");
			preparedStatement.setInt(1,id);
			
			preparedStatement.executeUpdate();
			
			System.out.println("DELETED OK");
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	System.out.println("DELETED NO");
    }
}
}



