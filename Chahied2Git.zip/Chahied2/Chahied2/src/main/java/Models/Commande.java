package Models;

import java.time.LocalDateTime;

public class Commande {
	private int id;
	private int utilisateur_id;	
	private String adresse_livraison;
	private String option_livraison;
	private String telephone;
	private double montant_total;
	private LocalDateTime Date_commande;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUtilisateur_id() {
		return utilisateur_id;
	}
	public void setUtilisateur_id(int utilisateur_id) {
		this.utilisateur_id = utilisateur_id;
	}
	
	public String getAdresse_livraison() {
		return adresse_livraison;
	}
	public void setAdresse_livraison(String adresse_livraison) {
		this.adresse_livraison = adresse_livraison;
	}
	public String getOption_livraison() {
		return option_livraison;
	}
	public void setOption_livraison(String option_livraison) {
		this.option_livraison = option_livraison;
	}
	
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public double getMontant_total() {
		return montant_total;
	}
	public void setMontant_total(double montant_total) {
		this.montant_total = montant_total;
	}
	public LocalDateTime getDate_commande() {
		return Date_commande;
	}
	public void setDate_commande(LocalDateTime date_commande) {
		Date_commande = date_commande;
	}
	public Commande() {
		super();
	}
	public Commande(int utilisateur_id, String adresse_livraison, String option_livraison,String telephone, double montant_total, LocalDateTime date_commande) {
		super();
		this.utilisateur_id = utilisateur_id;
		
		this.adresse_livraison = adresse_livraison;
		this.option_livraison = option_livraison;
		
		this.telephone = telephone;
		this.montant_total = montant_total;
		Date_commande = date_commande;
	}
	public Commande(int id, int utilisateur_id, String adresse_livraison, String option_livraison, String telephone, double montant_total, LocalDateTime date_commande) {
		super();
		this.id = id;
		this.utilisateur_id = utilisateur_id;
		
		this.adresse_livraison = adresse_livraison;
		this.option_livraison = option_livraison;
		
		this.telephone = telephone;
		this.montant_total = montant_total;
		Date_commande = date_commande;
	}
	
	
}
