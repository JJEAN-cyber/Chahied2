package Models;

public class Photo_article {
	private int id;
	private int article_id;
	private String chemin_fichier;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getArticle_id() {
		return article_id;
	}
	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}
	public String getChemin_fichier() {
		return chemin_fichier;
	}
	public void setChemin_fichier(String chemin_fichier) {
		this.chemin_fichier = chemin_fichier;
	}
	public Photo_article() {
		super();
	}
	public Photo_article(int article_id, String chemin_fichier) {
		super();
		this.article_id = article_id;
		this.chemin_fichier = chemin_fichier;
	}
	public Photo_article(int id, int article_id, String chemin_fichier) {
		super();
		this.id = id;
		this.article_id = article_id;
		this.chemin_fichier = chemin_fichier;
	}
	
	
}
