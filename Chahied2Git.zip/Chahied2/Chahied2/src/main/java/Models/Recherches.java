package Models;

public class Recherches {
	private int id;
	private int utilisateur_id;
	private String mot_cle;
	private int nombre_resultats;

	public Recherches() {
	}
	
	public Recherches(String mot_cle, int nombre_resultats) {
		this.mot_cle = mot_cle;
		this.nombre_resultats= nombre_resultats;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUtilisateur_id() {
		return utilisateur_id;
	}

	public void setUtilisateur_id(int utilisateur_id) {
		this.utilisateur_id = utilisateur_id;
	}

	public String getMot_cle() {
		return mot_cle;
	}

	public void setMot_cle(String mot_cle) {
		this.mot_cle = mot_cle;
	}

	public int getNombre_resultats() {
		return nombre_resultats;
	}

	public void setNombre_resultats(int nombre_resultats) {
		this.nombre_resultats = nombre_resultats;
	}
	
	}
	