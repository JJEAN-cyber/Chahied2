package Models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Sous_sous_categorieDAO {
	public void save(Sous_sous_categorie obj) {
		
		try {
			
			if(obj.getId() != 0) {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("UPDATE sous_sous_categorie set titre=?,sous_categorie_id=? WHERE id=?");
				preparedStatement.setString(1,obj.getTitre());
				preparedStatement.setInt(2,obj.getSous_categorie_id());
				preparedStatement.setInt(3,obj.getId());
	            preparedStatement.executeUpdate();
			}else {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("INSERT INTO sous_sous_categorie (titre,sous_categorie_id) VALUES(?,?)");
				preparedStatement.setString(1,obj.getTitre());
				preparedStatement.setInt(2,obj.getSous_categorie_id());
				
	            preparedStatement.executeUpdate();
			}
			System.out.println("SAVED OK");
			
		} catch (Exception ex) {
        	ex.printStackTrace();
        	System.out.println("SAVED NO");
        }
	
}

	public Sous_sous_categorie getById(int id) {
		try {
		
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM sous_sous_categorie WHERE id=?");
				preparedStatement.setInt(1,id);
				
				ResultSet resultat=preparedStatement.executeQuery();
				
				Sous_sous_categorie u = new Sous_sous_categorie();
				while(resultat.next()) {
					u.setId(resultat.getInt( "id" ));
					u.setTitre(resultat.getString( "titre" ));
					u.setSous_categorie_id(resultat.getInt( "sous_categorie_id" ));
				}
				return u;
			
		} catch (Exception ex) {
	    	ex.printStackTrace();
	    	return null;
	    }
	}
	public int getCountArticlesByIdSSX2_Cat(int id) {
		try {
		
				PreparedStatement preparedStatement  = Database.connexion.
		prepareStatement("SELECT COUNT(*) as nbr FROM articles WHERE sous_sous_categorie_id=?");
				preparedStatement.setInt(1,id);
				
				ResultSet resultat=preparedStatement.executeQuery();
				resultat.next();

				int nbr = resultat.getInt( "nbr" );
				return nbr;
			
		} catch (Exception ex) {
	    	ex.printStackTrace();
	    	return 0;
	    }
	}
	public ArrayList<Sous_sous_categorie> getAll() {
		ArrayList<Sous_sous_categorie> list = new ArrayList<Sous_sous_categorie>();
		try {
			
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM sous_sous_categorie");
				
				ResultSet resultat=preparedStatement.executeQuery();

				while(resultat.next()) {
					Sous_sous_categorie o = new Sous_sous_categorie();
					o.setId(resultat.getInt( "id" ));
					o.setTitre(resultat.getString( "titre" ));
					list.add(o);
				}
				
				
				return list;
			
		} catch (Exception ex) {
	    	ex.printStackTrace();
	    	return null;
	    }
	}
	
	
	public ArrayList<Sous_sous_categorie> RechercherS2CAT(String mot) {
		ArrayList<Sous_sous_categorie> list = new ArrayList<Sous_sous_categorie>();
		try {
			
				PreparedStatement preparedStatement  = Database.connexion
						.prepareStatement("SELECT * FROM sous_sous_categorie WHERE titre like ?");
				preparedStatement.setString(1,"%"+mot+"%");
				ResultSet resultat=preparedStatement.executeQuery();

				while(resultat.next()) {
					Sous_sous_categorie u = new Sous_sous_categorie();
					u.setId(resultat.getInt( "id" ));
					u.setTitre(resultat.getString( "titre" ));
					u.setSous_categorie_id(resultat.getInt( "sous_categorie_id " ));
					list.add(u);
				}
				return list;
			
		} catch (Exception ex) {
	    	ex.printStackTrace();
	    	return null;
	    }
	}
	
	public ArrayList<Sous_sous_categorie> getAllByScat(int id){
		ArrayList<Sous_sous_categorie> list = new ArrayList<Sous_sous_categorie>();
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM sous_sous_categorie WHERE sous_categorie_id=?");
			preparedStatement.setInt(1,id);

			ResultSet resultat=preparedStatement.executeQuery();

			
			while(resultat.next()) {
				Sous_sous_categorie u = new Sous_sous_categorie();
				u.setId(resultat.getInt( "id" ));
				u.setTitre(resultat.getString( "titre" ));
				u.setSous_categorie_id(resultat.getInt( "sous_categorie_id" ));
				list.add(u);
			}
			return list;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
	public int getCountProduitsById(int id) {
		try {

			PreparedStatement preparedStatement  = Database.connexion.
					prepareStatement("SELECT COUNT(*) as nbr FROM articles WHERE sous_sous_categorie_id=?");
			preparedStatement.setInt(1,id);

			ResultSet resultat=preparedStatement.executeQuery();
			resultat.next();

			int nbr = resultat.getInt( "nbr" );
			return nbr;

		} catch (Exception ex) {
			ex.printStackTrace();
			return 0;
		}
	}
	
	public void deleteById(int id) {
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM sous_sous_categorie WHERE id=?");
			preparedStatement.setInt(1,id);

			preparedStatement.executeUpdate();

			System.out.println("DELETED OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("DELETED NO");
		}
	}


	}
