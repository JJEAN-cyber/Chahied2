package Models;

import java.util.ArrayList;

public class Sous_actegorie {
	private int id;
	private String titre;
	private int actegorie_id;
	private ArrayList<Sous_sous_actegorie> sous_sous_Actegories;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public int getActegorie_id() {
		return actegorie_id;
	}
	public void setActegorie_id(int actegorie_id) {
		this.actegorie_id = actegorie_id;
	}
		
	public ArrayList<Sous_sous_actegorie> getSous_sous_Actegories() {
		return sous_sous_Actegories;
	}
	public void setSous_sous_Actegories(ArrayList<Sous_sous_actegorie> sous_sous_Actegories) {
		this.sous_sous_Actegories = sous_sous_Actegories;
	}
	
	public Sous_actegorie() {
		super();
	}
	public Sous_actegorie(String titre, int actegorie_id) {
		super();
		this.titre = titre;
		this.actegorie_id = actegorie_id;
	}
	public Sous_actegorie(int id, String titre, int actegorie_id) {
		super();
		this.id = id;
		this.titre = titre;
		this.actegorie_id = actegorie_id;
	}
	
	
}
