package Models;

public class Sous_sous_actegorie {
	private int id;
	private String titre;
	private int sous_actegorie_id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public int getSous_actegorie_id() {
		return sous_actegorie_id;
	}
	public void setSous_actegorie_id(int sous_actegorie_id) {
		this.sous_actegorie_id = sous_actegorie_id;
	}
	public Sous_sous_actegorie() {
		super();
	}
	public Sous_sous_actegorie(String titre, int sous_actegorie_id) {
		super();
		this.titre = titre;
		this.sous_actegorie_id = sous_actegorie_id;
	}
	public Sous_sous_actegorie(int id, String titre, int sous_actegorie_id) {
		super();
		this.id = id;
		this.titre = titre;
		this.sous_actegorie_id = sous_actegorie_id;
	}
	
	
}
