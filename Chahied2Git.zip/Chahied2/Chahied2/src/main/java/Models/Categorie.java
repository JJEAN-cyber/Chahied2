package Models;

import java.util.ArrayList;

public class Categorie {
	private int id;
	private String titre;
	private ArrayList<Sous_categorie> sousCategories;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	
	public ArrayList<Sous_categorie> getSousCategories() {
		return sousCategories;
	}
	public void setSousCategories(ArrayList<Sous_categorie> sousCategories) {
		this.sousCategories = sousCategories;
	}
	public Categorie() {
		super();
	}
	public Categorie(int id, String titre) {
		super();
		this.id = id;
		this.titre = titre;
	}
	public Categorie(String titre) {
		super();
		this.titre = titre;
	}
	
	
}
