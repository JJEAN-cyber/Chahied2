package Models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Resume_commandeDAO {
	public void save(Resume_commande obj) {
		
		try {
			
			if(obj.getId() != 0) {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("UPDATE Resume_commande set commande_id=?,article_id=?,total_commande=?,frais_protection_acheteur=?,frais_port=?,total_frais_commande=? WHERE id=?");
				preparedStatement.setInt(1,obj.getCommande_id());
				preparedStatement.setInt(2,obj.getArticle_id());
				preparedStatement.setDouble(3,obj.getTotal_commande());
				preparedStatement.setDouble(4,obj.getFrais_protection_acheteur());
				preparedStatement.setDouble(5,obj.getFrais_port());
				preparedStatement.setDouble(6,obj.getTotal_frais_commande());
				preparedStatement.setInt(7,obj.getId());
	            preparedStatement.executeUpdate();
			}else {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("INSERT INTO Resume_commande (commande_id,article_id,total_commande,frais_protection_acheteur,frais_port,total_frais_commande) VALUES(?,?,?,?,?,?)");
				preparedStatement.setInt(1,obj.getCommande_id());
				preparedStatement.setInt(2,obj.getArticle_id());
				preparedStatement.setDouble(3,obj.getTotal_commande());
				preparedStatement.setDouble(4,obj.getFrais_protection_acheteur());
				preparedStatement.setDouble(5,obj.getFrais_port());
				preparedStatement.setDouble(6,obj.getTotal_frais_commande());
	            preparedStatement.executeUpdate();
			}
			System.out.println("SAVED OK");
			
		} catch (Exception ex) {
        	ex.printStackTrace();
        	System.out.println("SAVED NO");
        }
	
}

public Resume_commande getById(int id) {
	try {
	
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM resume_commande WHERE id=?");
			preparedStatement.setInt(1,id);
			
			ResultSet resultat=preparedStatement.executeQuery();
			
			Resume_commande u = new Resume_commande();
			while(resultat.next()) {
				u.setId(resultat.getInt( "id" ));
				u.setCommande_id(resultat.getInt( "commande_id" ));
				u.setArticle_id(resultat.getInt( "article_id" ));
				u.setTotal_commande(resultat.getDouble( "total_commande" ));
				u.setFrais_protection_acheteur(resultat.getDouble( "frais_protection_acheteur" ));
				u.setFrais_port(resultat.getDouble( "frais_port" ));
				u.setTotal_frais_commande(resultat.getDouble( "total_frais_commande" ));
			
			}
			return u;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}





public ArrayList<Resume_commande> getAllByCommande(int commandeid) {
	ArrayList<Resume_commande> list = new ArrayList<Resume_commande>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM resume_commande WHERE commande_id=?");
			preparedStatement.setInt(1,commandeid);
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Resume_commande u = new Resume_commande();
				u.setId(resultat.getInt( "id" ));
				u.setCommande_id(resultat.getInt( "commande_id" ));
				u.setArticle_id(resultat.getInt( "article_id" ));
				u.setTotal_commande(resultat.getDouble( "total_commande" ));
				u.setFrais_protection_acheteur(resultat.getDouble( "frais_protection_acheteur" ));
				u.setFrais_port(resultat.getDouble( "frais_port" ));
				u.setTotal_frais_commande(resultat.getDouble( "total_frais_commande" ));
			
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}



public void deleteById(int id) {
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM resume_commande WHERE id=?");
			preparedStatement.setInt(1,id);
			
			preparedStatement.executeUpdate();
			
			System.out.println("DELETED OK");
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	System.out.println("DELETED NO");
    }
}	
}


