package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CategorieDAO {
	public void save(Categorie obj) {

		try {

			if(obj.getId() != 0) {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("UPDATE categorie set titre=? WHERE id=?");
				preparedStatement.setString(1,obj.getTitre());
				preparedStatement.setInt(2,obj.getId());
				preparedStatement.executeUpdate();
			}else {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("INSERT INTO categorie (titre) VALUES(?)");
				preparedStatement.setString(1,obj.getTitre());
				preparedStatement.executeUpdate();
			}
			System.out.println("SAVED OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("SAVED NO");
		}

	}

	public Categorie getById(int id) {
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM categorie WHERE id=?");
			preparedStatement.setInt(1,id);

			ResultSet resultat=preparedStatement.executeQuery();

			Categorie u = new Categorie();
			while(resultat.next()) {
				u.setId(resultat.getInt( "id" ));
				u.setTitre(resultat.getString( "titre" ));
			}
			return u;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
	public int getCountArticlesByIdCat(int id) {
		try {

			PreparedStatement preparedStatement  = Database.connexion.
					prepareStatement("SELECT COUNT(*) as nbr FROM articles WHERE categorie_id=?");
			preparedStatement.setInt(1,id);

			ResultSet resultat=preparedStatement.executeQuery();
			resultat.next();

			int nbr = resultat.getInt( "nbr" );
			return nbr;

		} catch (Exception ex) {
			ex.printStackTrace();
			return 0;
		}
	}

	public ArrayList<Categorie> RechercherCAT(String mot) {
		ArrayList<Categorie> list = new ArrayList<Categorie>();
		try {

			PreparedStatement preparedStatement  = Database.connexion
					.prepareStatement("SELECT * FROM categorie WHERE titre like ?");
			preparedStatement.setString(1,"%"+mot+"%");
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Categorie u = new Categorie();
				u.setId(resultat.getInt( "id" ));
				u.setTitre(resultat.getString( "titre" ));
				list.add(u);
			}
			return list;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public ArrayList<Categorie> getAll() {
		ArrayList<Categorie> list = new ArrayList<Categorie>();
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM categorie");

			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Categorie o = new Categorie();
				o.setId(resultat.getInt( "id" ));
				o.setTitre(resultat.getString( "titre" ));
				list.add(o);
			}


			return list;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public void deleteById(int id) {
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM categorie WHERE id=?");
			preparedStatement.setInt(1,id);

			preparedStatement.executeUpdate();

			System.out.println("DELETED OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("DELETED NO");
		}
	}


	public int getCountProduitsById(int id) {
		try {

			PreparedStatement preparedStatement  = Database.connexion.
					prepareStatement("SELECT COUNT(*) as nbr FROM articles WHERE sous_sous_categorie_id=?");
			preparedStatement.setInt(1,id);

			ResultSet resultat=preparedStatement.executeQuery();
			resultat.next();

			int nbr = resultat.getInt( "nbr" );
			return nbr;

		} catch (Exception ex) {
			ex.printStackTrace();
			return 0;
		}
	}
	
	public static ArrayList<Categorie> getAllFullTree() {
	    ArrayList<Categorie> categories = new ArrayList<>();
	    String sqlCat = "SELECT id, titre FROM categorie";
	    String sqlSousCat = "SELECT id, titre FROM sous_categorie WHERE categorie_id = ?";
	    String sqlSousSousCat = "SELECT id, titre FROM sous_sous_categorie WHERE sous_categorie_id = ?";

	    try {
	        // Connection donnée par ta classe Database avec ton objet connexion statique
	        Connection conn = Database.connexion;

	        PreparedStatement psCat = conn.prepareStatement(sqlCat);
	        ResultSet rsCat = psCat.executeQuery();

	        while (rsCat.next()) {
	            Categorie cat = new Categorie();
	            cat.setId(rsCat.getInt("id"));
	            cat.setTitre(rsCat.getString("titre"));
	            cat.setSousCategories(new ArrayList<>());

	            PreparedStatement psSousCat = conn.prepareStatement(sqlSousCat);
	            psSousCat.setInt(1, cat.getId());
	            ResultSet rsSousCat = psSousCat.executeQuery();

	            while (rsSousCat.next()) {
	                Sous_categorie sc = new Sous_categorie();
	                sc.setId(rsSousCat.getInt("id"));
	                sc.setTitre(rsSousCat.getString("titre"));
	                sc.setCategorie_id(cat.getId());
	                sc.setSous_sous_Categories(new ArrayList<>());

	                PreparedStatement psSousSousCat = conn.prepareStatement(sqlSousSousCat);
	                psSousSousCat.setInt(1, sc.getId());
	                ResultSet rsSousSousCat = psSousSousCat.executeQuery();

	                while (rsSousSousCat.next()) {
	                    Sous_sous_categorie ssc = new Sous_sous_categorie();
	                    ssc.setId(rsSousSousCat.getInt("id"));
	                    ssc.setTitre(rsSousSousCat.getString("titre"));
	                    ssc.setSous_categorie_id(sc.getId());
	                    sc.getSous_sous_Categories().add(ssc);
	                }
	                rsSousSousCat.close();
	                psSousSousCat.close();

	                cat.getSousCategories().add(sc);
	            }
	            rsSousCat.close();
	            psSousCat.close();

	            categories.add(cat);
	        }

	        rsCat.close();
	        psCat.close();

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return categories;
	}

}

