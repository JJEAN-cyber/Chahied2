package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UtilisateurDAO {
	
	
	public boolean updateMotDePasse(Utilisateur utilisateur) {
	    String sql = "UPDATE utilisateur SET mot_de_passe = ? WHERE id = ?";
	    try (Connection con = Database.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {
	        
	        ps.setString(1, utilisateur.getMot_de_passe());
	        ps.setLong(2, utilisateur.getId());
	        
	        int lignes = ps.executeUpdate();
	        return lignes > 0; // true si au moins une ligne mise à jour
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false;
	    }
	}

	
	
	public Utilisateur findByEmail(String email) throws SQLException {
        Utilisateur u = null;
        String sql = "SELECT * FROM utilisateur WHERE email=?";
        try (Connection conn = Database.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            preparedStatement.setString(1, email);
            try (ResultSet resultat = preparedStatement.executeQuery()) {
                if (resultat.next()) {
                    u = new Utilisateur();
                    u.setId(resultat.getInt("id"));
                    u.setNom(resultat.getString("nom"));
                    u.setEmail(resultat.getString("email"));
                    u.setMot_de_passe(resultat.getString("mot_de_passe"));
                    u.setDate_inscription(resultat.getTimestamp("date_inscription"));
                    u.setDate_connexion(resultat.getTimestamp("date_connexion"));
                    u.setVille(resultat.getString("ville"));
                    u.setDescription(resultat.getString("description"));
                    u.setPhoto_profil(resultat.getString("photo_profil"));
                    u.setIsBanned(resultat.getBoolean("isBanned"));
                    u.setAdresse(resultat.getString("adresse"));
                }
            }
        }
        return u;
    }

	
	public void save(Utilisateur obj) throws SQLException {
	    if (obj.getId() != 0) {
	        PreparedStatement preparedStatement = Database.connexion.prepareStatement(
	            "UPDATE utilisateur set nom=?,email=?,mot_de_passe=?,date_inscription=?,date_connexion=?, ville=?, description=?, photo_profil=?, isBanned=?, adresse=? WHERE id=?");
	        preparedStatement.setString(1, obj.getNom());
	        preparedStatement.setString(2, obj.getEmail());
	        preparedStatement.setString(3, obj.getMot_de_passe());
	        preparedStatement.setTimestamp(4, obj.getDate_inscription());
	        preparedStatement.setTimestamp(5, obj.getDate_connexion());
	        preparedStatement.setString(6, obj.getVille());
	        preparedStatement.setString(7, obj.getDescription());
	        preparedStatement.setString(8, obj.getPhoto_profil());
	        preparedStatement.setBoolean(9, obj.getIsBanned());
	        preparedStatement.setString(10, obj.getAdresse());
	        preparedStatement.setInt(11, obj.getId());
	        preparedStatement.executeUpdate();
	    } else {
	        PreparedStatement preparedStatement = Database.connexion.prepareStatement(
	            "INSERT INTO utilisateur (nom,email,mot_de_passe,date_inscription,date_connexion,ville,description,photo_profil,isBanned,adresse) VALUES(?,?,?,?,?,?,?,?,?,?)");
	        preparedStatement.setString(1, obj.getNom());
	        preparedStatement.setString(2, obj.getEmail());
	        preparedStatement.setString(3, obj.getMot_de_passe());
	        preparedStatement.setTimestamp(4, obj.getDate_inscription());
	        preparedStatement.setTimestamp(5, obj.getDate_connexion());
	        preparedStatement.setString(6, obj.getVille());
	        preparedStatement.setString(7, obj.getDescription());
	        preparedStatement.setString(8, obj.getPhoto_profil());
	        preparedStatement.setBoolean(9, obj.getIsBanned());
	        preparedStatement.setString(10, obj.getAdresse());
	        preparedStatement.executeUpdate();
	    }
	    System.out.println("SAVED OK");
	}

	public Utilisateur getById(int id) {
	    try {
	        if (Database.connexion == null) {
	            throw new SQLException("Connexion à la base non initialisée !");
	        }
	        PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM utilisateur WHERE id=?");
	        preparedStatement.setInt(1,id);

	        ResultSet resultat=preparedStatement.executeQuery();

	        Utilisateur u = new Utilisateur();
	        while(resultat.next()) {
	            u.setId(resultat.getInt( "id" ));
	            u.setNom(resultat.getString( "nom" ));
	            u.setEmail(resultat.getString( "email" ));
	            u.setMot_de_passe(resultat.getString( "mot_de_passe" ));
	            u.setDate_inscription(resultat.getTimestamp("date_inscription"));
	            u.setDate_connexion(resultat.getTimestamp("date_connexion"));
	            u.setVille(resultat.getString("ville"));
	            u.setDescription(resultat.getString("description"));
	            u.setPhoto_profil(resultat.getString("photo_profil"));
	            u.setIsBanned(resultat.getBoolean( "isBanned" ));
	            u.setAdresse(resultat.getString("adresse"));
	        }
	        return u;

	    } catch (Exception ex) {
	        ex.printStackTrace();
	        return null;
	    }
	}

	public Utilisateur connexion(String email,String mot_de_passe, boolean isBanned) throws SQLException{
		try {
		
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM utilisateur WHERE email=? AND mot_de_passe=? AND isBanned=?");
				preparedStatement.setString(1,email);
				preparedStatement.setString(2,mot_de_passe);				
				preparedStatement.setBoolean(3, isBanned);
				ResultSet resultat=preparedStatement.executeQuery();
				Utilisateur u = new Utilisateur();
				if(resultat.next()) {
					u.setId(resultat.getInt( "id" ));
					u.setNom(resultat.getString( "nom" ));
					u.setEmail(resultat.getString( "email" ));
					u.setMot_de_passe(resultat.getString( "mot_de_passe" ));
					u.setDate_inscription(resultat.getTimestamp("date_inscription"));
					u.setDate_connexion(resultat.getTimestamp("date_connexion"));
					u.setVille(resultat.getString("ville"));
					u.setDescription(resultat.getString("description"));
					u.setPhoto_profil(resultat.getString("photo_profil"));
					u.setIsBanned(resultat.getBoolean( "isBanned" ));
					u.setAdresse(resultat.getString("adresse"));
					return u;
				}else {
					return null;
				}
		} catch (Exception ex) {
        	ex.printStackTrace();
        	return null;
        }
	}
	public ArrayList<Utilisateur> getAll() {
		ArrayList<Utilisateur> list = new ArrayList<Utilisateur>();
		try {
			
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM utilisateur");
				
				ResultSet resultat=preparedStatement.executeQuery();

				while(resultat.next()) {
					Utilisateur u = new Utilisateur();
					u.setId(resultat.getInt( "id" ));
					u.setNom(resultat.getString( "nom" ));
					u.setEmail(resultat.getString( "email" ));
					u.setMot_de_passe(resultat.getString( "mot_de_passe" ));
					u.setDate_inscription(resultat.getTimestamp("date_inscription"));
					u.setDate_connexion(resultat.getTimestamp("date_connexion"));
					u.setVille(resultat.getString("ville"));
					u.setDescription(resultat.getString("description"));
					u.setPhoto_profil(resultat.getString("photo_profil"));
					u.setIsBanned(resultat.getBoolean( "isBanned" ));
					u.setAdresse(resultat.getString("adresse"));
					
					list.add(u);
				}
				
				
				return list;
			
		} catch (Exception ex) {
	    	ex.printStackTrace();
	    	return null;
	    }
	}
	public void deleteById(int id) {
		try {
			
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM utilisateur WHERE id=?");
				preparedStatement.setInt(1,id);
				
				preparedStatement.executeUpdate();
				
				System.out.println("DELETED OK");
			
		} catch (Exception ex) {
	    	ex.printStackTrace();
	    	System.out.println("DELETED NO");
	    }
	}
	public boolean banUser(int id) {
		try {
				PreparedStatement preparedStatement = Database.connexion.prepareStatement("UPDATE utilisateur SET isBanned = TRUE WHERE id = ?");
				preparedStatement.setInt(1, id);
				
				 int rowsUpdated = preparedStatement.executeUpdate();
			        
			        // Retourne true si au moins une ligne a été mise à jour, sinon false
			        if (rowsUpdated > 0) {
			            System.out.println("UPDATE BANNED OK");
			            return true;
			        } else {
			            System.out.println("UPDATE BANNED NO - No rows affected");
			            return false;
			        }
			    } catch (Exception ex) {
			        ex.printStackTrace();
			        System.out.println("UPDATE BANNED NO - Exception occurred");
			        return false;
			    }
			}
	

public ArrayList<Utilisateur> RechercherUT(String mot) {
	ArrayList<Utilisateur> list = new ArrayList<Utilisateur>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion
					.prepareStatement("SELECT * FROM utilisateur WHERE nom like ?");
			preparedStatement.setString(1,"%"+mot+"%");
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Utilisateur u = new Utilisateur();
				u.setId(resultat.getInt( "id" ));
				u.setNom(resultat.getString( "nom" ));
				u.setEmail(resultat.getString( "email" ));
				u.setMot_de_passe(resultat.getString( "mot_de_passe" ));
				u.setDate_inscription(resultat.getTimestamp("date_inscription"));
				u.setDate_connexion(resultat.getTimestamp("date_connexion"));
				u.setVille(resultat.getString("ville"));
				u.setDescription(resultat.getString("description"));
				u.setPhoto_profil(resultat.getString("photo_profil"));
				u.setIsBanned(resultat.getBoolean( "isBanned" ));
				u.setAdresse(resultat.getString("adresse"));
				list.add(u);
			}
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}

}


