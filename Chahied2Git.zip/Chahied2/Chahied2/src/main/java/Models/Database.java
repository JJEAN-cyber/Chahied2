package Models;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
	private static String dburl = "jdbc:mysql://localhost:3306/chahiedd?useUnicode=true&characterEncoding=UTF-8";
	private static String dbuser="root";
	private static String dbpass="";
	public static Connection connexion=null;
	
	 // Méthode pour ouvrir une nouvelle connexion à chaque appel
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dburl, dbuser, dbpass);
    }

	public static void Connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			System.out.println("Driver OK");
			connexion=DriverManager.getConnection(dburl,dbuser,dbpass);

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("PROBLEME MYSQL DRIVER");
		}
	}
	public static void closeConnection() {
		if (connexion != null) {
			try {
				connexion.close();
				System.out.println("Connexion fermée proprement.");
			} catch (SQLException e) {
				System.err.println("Erreur lors de la fermeture de la connexion : " + e.getMessage());
				e.printStackTrace();
			} finally {
				connexion = null; // pour éviter de réutiliser une connexion fermée
			}
		}
	}
}

