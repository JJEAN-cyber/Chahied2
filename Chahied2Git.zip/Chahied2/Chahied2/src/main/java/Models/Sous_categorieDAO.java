package Models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Sous_categorieDAO {
	public void save(Sous_categorie obj) {

		try {

			if(obj.getId() != 0) {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("UPDATE sous_categorie set titre=?, categorie_id=? WHERE id=?");
				preparedStatement.setString(1,obj.getTitre());
				preparedStatement.setInt(2,obj.getCategorie_id());
				preparedStatement.setInt(3,obj.getId());
				preparedStatement.executeUpdate();
			}else {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("INSERT INTO sous_categorie (titre,categorie_id) VALUES(?,?)");
				preparedStatement.setString(1,obj.getTitre());
				preparedStatement.setInt(2,obj.getCategorie_id());

				preparedStatement.executeUpdate();
			}
			System.out.println("SAVED OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("SAVED NO");
		}

	}

	public Sous_categorie getById(int id) {
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM sous_categorie WHERE id=?");
			preparedStatement.setInt(1,id);

			ResultSet resultat=preparedStatement.executeQuery();

			Sous_categorie u = new Sous_categorie();
			while(resultat.next()) {
				u.setId(resultat.getInt( "id" ));
				u.setTitre(resultat.getString( "titre" ));
				u.setCategorie_id(resultat.getInt( "categorie_id" ));
			}
			return u;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
	public int getCountArticlesByIdSS_Cat(int id) {
		try {

			PreparedStatement preparedStatement  = Database.connexion.
					prepareStatement("SELECT COUNT(*) as nbr FROM articles WHERE sous_categorie_id=?");
			preparedStatement.setInt(1,id);

			ResultSet resultat=preparedStatement.executeQuery();
			resultat.next();

			int nbr = resultat.getInt( "nbr" );
			return nbr;

		} catch (Exception ex) {
			ex.printStackTrace();
			return 0;
		}
	}

	public ArrayList<Sous_categorie> RechercherSSCAT(String mot) {
		ArrayList<Sous_categorie> list = new ArrayList<Sous_categorie>();
		try {

			PreparedStatement preparedStatement  = Database.connexion
					.prepareStatement("SELECT * FROM sous_actegorie WHERE titre like ?");
			preparedStatement.setString(1,"%"+mot+"%");
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Sous_categorie u = new Sous_categorie();
				u.setId(resultat.getInt( "id" ));
				u.setTitre(resultat.getString( "titre" ));
				u.setCategorie_id(resultat.getInt( "categorie_id " ));
				list.add(u);
			}
			return list;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public ArrayList<Sous_categorie> getAllByCat(int id){
		ArrayList<Sous_categorie> list = new ArrayList<Sous_categorie>();
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM sous_categorie WHERE categorie_id=?");
			preparedStatement.setInt(1,id);

			ResultSet resultat=preparedStatement.executeQuery();

			
			while(resultat.next()) {
				Sous_categorie u = new Sous_categorie();
				u.setId(resultat.getInt( "id" ));
				u.setTitre(resultat.getString( "titre" ));
				u.setCategorie_id(resultat.getInt( "categorie_id" ));
				list.add(u);
			}
			return list;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
	
	public void deleteById(int id) {
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM sous_categorie WHERE id=?");
			preparedStatement.setInt(1,id);

			preparedStatement.executeUpdate();

			System.out.println("DELETED OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("DELETED NO");
		}
	}


}



