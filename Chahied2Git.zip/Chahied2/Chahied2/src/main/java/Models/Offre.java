package Models;

import java.time.LocalDateTime;

public class Offre {
	private int id;
	private int utilisateur_id;
	private int article_id;
	private double montant_offre;
	private LocalDateTime date_offre;
	private String statut;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUtilisateur_id() {
		return utilisateur_id;
	}
	public void setUtilisateur_id(int utilisateur_id) {
		this.utilisateur_id = utilisateur_id;
	}
	public int getArticle_id() {
		return article_id;
	}
	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}
	public double getMontant_offre() {
		return montant_offre;
	}
	public void setMontant_offre(double montant_offre) {
		this.montant_offre = montant_offre;
	}
	public LocalDateTime getDate_offre() {
		return date_offre;
	}
	public void setDate_offre(LocalDateTime date_offre) {
		this.date_offre = date_offre;
	}
	public String getStatut() {
		return statut;
	}
	public void setStatut(String statut) {
		this.statut = statut;
	}
	public Offre() {
		super();
	}
	public Offre(int utilisateur_id, int article_id, double montant_offre, LocalDateTime date_offre, String statut) {
		super();
		this.utilisateur_id = utilisateur_id;
		this.article_id = article_id;
		this.montant_offre = montant_offre;
		this.date_offre = date_offre;
		this.statut = statut;
	}
	public Offre(int id, int utilisateur_id, int article_id, double montant_offre, LocalDateTime date_offre,
			String statut) {
		super();
		this.id = id;
		this.utilisateur_id = utilisateur_id;
		this.article_id = article_id;
		this.montant_offre = montant_offre;
		this.date_offre = date_offre;
		this.statut = statut;
	}
	
	
}
