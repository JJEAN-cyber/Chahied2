package Models;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class MessageDAO {
	public void save(Message obj) {

		try {

			if(obj.getId() != 0) {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("UPDATE message set expediteur_id=?,destinataire_id=?,contenu=?,date_envoi=?,article_id=?,conversation_id, WHERE id=?");
				preparedStatement.setInt(1,obj.getExpediteur_id());
				preparedStatement.setInt(2,obj.getDestinataire_id());
				preparedStatement.setString(3,obj.getContenu());
				preparedStatement.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
				preparedStatement.setInt(5,obj.getArticle_id());
				preparedStatement.setInt(6, obj.getConversation_id());
				preparedStatement.setInt(7,obj.getId());
				preparedStatement.executeUpdate();
			}else {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("INSERT INTO message (expediteur_id,destinataire_id,contenu,date_envoi, article_id, conversation_id) VALUES(?,?,?,?,?,?)");
				preparedStatement.setInt(1,obj.getExpediteur_id());
				preparedStatement.setInt(2,obj.getDestinataire_id());
				preparedStatement.setString(3,obj.getContenu());
				preparedStatement.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
				preparedStatement.setInt(5,obj.getArticle_id());
				preparedStatement.setInt(6, obj.getConversation_id());
				preparedStatement.executeUpdate();
			}
			System.out.println("SAVED OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("SAVED NO");
		}

	}

	public void envoyerMessage(Message obj) {
		try {
			
			CallableStatement cs = Database.connexion.prepareCall("{CALL send_message_and_update_conversation(?,?,?,?,?,?)}");
			cs.setInt(1, obj.getExpediteur_id());
			cs.setInt(2, obj.getDestinataire_id());
			cs.setString(3,  obj.getContenu());
			cs.setTimestamp(4, Timestamp.valueOf(obj.getDate_envoi()));
			cs.setInt(5, obj.getArticle_id());
			cs.setInt(6, obj.getConversation_id());
			cs.executeUpdate();
			
		
		System.out.println("message saved and conversation updated");
	}
		catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("SAVED NO");
		}
	}

	
	public ArrayList<Message> getAll() {
		ArrayList<Message> list = new ArrayList<Message>();
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM message");

			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Message u = new Message();
				u.setId(resultat.getInt( "id" ));
				u.setExpediteur_id(resultat.getInt( "expediteur_id" ));
				u.setDestinataire_id(resultat.getInt( "destinataire_id" ));
				u.setContenu(resultat.getString( "contenu" ));
				u.setDate_envoi(resultat.getTimestamp("date_envoi").toLocalDateTime());
				u.setArticle_id(resultat.getInt( "article_id" ));
				u.setConversation_id(resultat.getInt("conversation_id"));

				list.add(u);
			}


			return list;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
	public void deleteById(int id) {
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM message WHERE id=?");
			preparedStatement.setInt(1,id);

			preparedStatement.executeUpdate();

			System.out.println("DELETED OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("DELETED NO");
		}
	}

	public static ArrayList<Message> getUserConversation(int expediteurId) {
		ArrayList<Message> list = new ArrayList<Message>();
		try {

			CallableStatement callStmt = Database.connexion.prepareCall("{CALL getUserConversation(?)}");
			callStmt.setInt(1, expediteurId);
			ResultSet rs = callStmt.executeQuery();
			while(rs.next()) {
				Message u = new Message();

				u.setExpediteur_id(rs.getInt("user1"));
				u.setDestinataire_id(rs.getInt("user2"));
				u.setContenu(rs.getString("dernier_message_contenu"));
				u.setDate_envoi(rs.getTimestamp("date_envoi_message").toLocalDateTime());
				list.add(u);			}


			return list;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
	
	public static ArrayList<Message> getListerConversationsByUser(int utilisateurId) {
		ArrayList<Message> list = new ArrayList<Message>();
		try {

			CallableStatement callStmt = Database.connexion.prepareCall("{CALL listerConversationsByUser(?)}");
			callStmt.setInt(1, utilisateurId);
			ResultSet rs = callStmt.executeQuery();
			while(rs.next()) {
				Message u = new Message();

				u.setExpediteur_id(rs.getInt("user1"));
				u.setDestinataire_id(rs.getInt("user2"));
				u.setContenu(rs.getString("dernier_message_contenu"));
				u.setDate_envoi(rs.getTimestamp("date_envoi_message").toLocalDateTime());
				list.add(u);			}


			return list;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
		
		public static ArrayList<ConversationInfo> getConversationsEntreUtilisateurs(int userid) {
		    ArrayList<ConversationInfo> result = new ArrayList<>();
		    String sql = "{CALL lister_conversations_utilisateur(?)}";
		    try (CallableStatement stmt = Database.connexion.prepareCall(sql)) {
		        stmt.setInt(1, userid);
		        

		        try (ResultSet rs = stmt.executeQuery()) {
		            while (rs.next()) {
		                ConversationInfo info = new ConversationInfo();
		                info.setNomUtilisateur(rs.getString("nom_utilisateur"));
		                info.setTitreArticle(rs.getString("titre_article"));
		                info.setPrixArticle(rs.getDouble("prix_article"));
		                result.add(info);
		            }
		        }
		    } catch (SQLException e) {
		        e.printStackTrace(); // À remplacer par une gestion d'erreur adaptée en prod
		    }
		    return result;
		}

		
		public void send_message_and_update_conversation(
			    int expediteurId,
			    int destinataireId,
			    String contenu,
			    Timestamp dateEnvoi,
			    int articleId,
			    int conversationId
			) {
			    String sql = "{CALL send_message_and_update_conversation(?, ?, ?, ?, ?, ?)}";
			    try (CallableStatement cs = Database.connexion.prepareCall(sql)) {
			        cs.setInt(1, expediteurId);
			        cs.setInt(2, destinataireId);
			        cs.setString(3, contenu);
			        cs.setTimestamp(4, dateEnvoi);
			        cs.setInt(5, articleId);
			        cs.setInt(6, conversationId);
			        cs.executeUpdate(); // Utilise executeUpdate() comme demandé
			    } catch (SQLException e) {
			        e.printStackTrace(); // Gère l'exception ici (log, affiche, etc.)
			        // Tu peux aussi logger dans un fichier ou afficher un message à l'utilisateur
			    }
			}
		public ArrayList<Message> getMessagesByConversationId(int conversationId) {
		    ArrayList<Message> messages = new ArrayList<>();
		    try {
		        CallableStatement cs = Database.connexion.prepareCall("{CALL getMessagesByConversationId(?)}");
		        cs.setInt(1, conversationId);
		        ResultSet rs = cs.executeQuery();

		        while(rs.next()) {
		            // Crée un nouvel objet Message à chaque tour de boucle
		            Message msg = new Message();
		            msg.setId(rs.getInt("id"));
		            msg.setExpediteur_id(rs.getInt("expediteur_id"));
		            // Récupère le nom de l'expéditeur (présent grâce à la jointure)
		            String expediteur_nom = rs.getString("expediteur_nom");
		            // Si tu veux stocker le nom de l'expéditeur dans l'objet Message, ajoute un setter ou une variable
		            msg.setDestinataire_id(rs.getInt("destinataire_id"));
		            // Récupère le nom du destinataire (présent grâce à la jointure)
		            String destinataire_nom = rs.getString("destinataire_nom");
		            msg.setContenu(rs.getString("contenu"));
		            msg.setDate_envoi(rs.getTimestamp("date_envoi").toLocalDateTime());
		            msg.setArticle_id(rs.getInt("article_id"));
		            msg.setConversation_id(rs.getInt("conversation_id"));

		            // Si tu veux stocker les noms dans l'objet Message, ajoute des setter ou des champs
		            // Par exemple : msg.setExpediteur_nom(expediteur_nom);

		            messages.add(msg);
		        }
		        return messages;

		    } catch (Exception ex) {
		        ex.printStackTrace();
		        return null;
		    }
		}

}
