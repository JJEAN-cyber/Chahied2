package Models;

import java.util.ArrayList;

public class Actegorie {
	private int id;
	private String titre;	
	private ArrayList<Sous_actegorie> sousActegories;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	
	public ArrayList<Sous_actegorie> getSousActegories() {
		return sousActegories;
	}
	public void setSousActegories(ArrayList<Sous_actegorie> sousActegories) {
		this.sousActegories = sousActegories;
	}
	public Actegorie() {
		super();
	}
	public Actegorie(String titre) {
		super();
		this.titre = titre;
	}
	public Actegorie(int id, String titre) {
		super();
		this.id = id;
		this.titre = titre;
	}
	
	
}
