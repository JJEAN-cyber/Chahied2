package Models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

public class EvaluationDAO {
public void save(Evaluation obj) {
		
		try {
			
			if(obj.getId() != 0) {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("UPDATE evaluation set evaluateur_id=?,evalue_id=?,note=?,commentaire=?,date_evaluation=? WHERE id=?");
				preparedStatement.setInt(1,obj.getEvaluateur_id());
				preparedStatement.setInt(2,obj.getEvalue_id());
				preparedStatement.setInt(3,obj.getNote());
				preparedStatement.setString(4,obj.getCommentaire());
				preparedStatement.setTimestamp(5,Timestamp.valueOf(obj.getDate_evaluation()));
				preparedStatement.setInt(6,obj.getId());
	            preparedStatement.executeUpdate();
			}else {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("INSERT INTO evaluation (evaluateur_id,evalue_id,note,commentaire,date_evaluation) VALUES(?,?,?,?,now())");
				preparedStatement.setInt(1,obj.getEvaluateur_id());
				preparedStatement.setInt(2,obj.getEvalue_id());
				preparedStatement.setInt(3,obj.getNote());
				preparedStatement.setString(4,obj.getCommentaire());
				preparedStatement.setTimestamp(5,Timestamp.valueOf(obj.getDate_evaluation()));	
	            preparedStatement.executeUpdate();
			}
			System.out.println("SAVED OK");
			
		} catch (Exception ex) {
        	ex.printStackTrace();
        	System.out.println("SAVED NO");
        }
	
}
public Evaluation getById(int id) {
	try {
	
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM evaluation WHERE id=?");
			preparedStatement.setInt(1,id);
			
			ResultSet resultat=preparedStatement.executeQuery();
			
			Evaluation u = new Evaluation();
			while(resultat.next()) {
				u.setId(resultat.getInt( "id" ));
				u.setEvaluateur_id(resultat.getInt("evaluateur_id"));
				u.setEvalue_id(resultat.getInt( "evalue_id" ));
				u.setNote(resultat.getInt( "note" ));
				u.setCommentaire(resultat.getString("commentaire"));
				u.setDate_evaluation(resultat.getTimestamp("date_evaluation").toLocalDateTime());
								
			}
			return u;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}
public ArrayList<Evaluation> getAll() {
	ArrayList<Evaluation> list = new ArrayList<Evaluation>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM evaluation");
			
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Evaluation u = new Evaluation();
				u.setId(resultat.getInt( "id" ));
				u.setEvaluateur_id(resultat.getInt("evaluateur_id"));
				u.setEvalue_id(resultat.getInt( "evalue_id" ));
				u.setNote(resultat.getInt( "note" ));
				u.setCommentaire(resultat.getString("commentaire"));
				u.setDate_evaluation(resultat.getTimestamp("date_evaluation").toLocalDateTime());
						
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}
public ArrayList<Evaluation> getAllByEvalue(int evalue_id) {
	ArrayList<Evaluation> list = new ArrayList<Evaluation>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM evaluation WHERE evalue_id=?");
			preparedStatement.setInt(1,evalue_id);
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Evaluation u = new Evaluation();
				u.setId(resultat.getInt( "id" ));
				u.setEvaluateur_id(resultat.getInt("evaluateur_id"));
				u.setEvalue_id(resultat.getInt( "evalue_id" ));
				u.setNote(resultat.getInt( "note" ));
				u.setCommentaire(resultat.getString("commentaire"));
				u.setDate_evaluation(resultat.getTimestamp("date_evaluation").toLocalDateTime());
						
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}

public ArrayList<Evaluation> getAllByEvaluateur(int evaluateur_id) {
	ArrayList<Evaluation> list = new ArrayList<Evaluation>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM evaluation WHERE evaluateur_id=?");
			preparedStatement.setInt(1,evaluateur_id);
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Evaluation u = new Evaluation();
				u.setId(resultat.getInt( "id" ));
				u.setId(resultat.getInt( "id" ));
				u.setEvaluateur_id(resultat.getInt("evaluateur_id"));
				u.setEvalue_id(resultat.getInt( "evalue_id" ));
				u.setNote(resultat.getInt( "note" ));
				u.setCommentaire(resultat.getString("commentaire"));
				u.setDate_evaluation(resultat.getTimestamp("date_evaluation").toLocalDateTime());
						
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}

public void deleteById(int id) {
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM evaluation WHERE id=?");
			preparedStatement.setInt(1,id);
			
			preparedStatement.executeUpdate();
			
			System.out.println("DELETED OK");
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	System.out.println("DELETED NO");
    }
}
}


