package Models;

import java.time.LocalDateTime;

public class Evaluation {
	private int id;
	private int evaluateur_id;
	private int evalue_id;
	private int note;
	private String commentaire;
	private LocalDateTime date_evaluation;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getEvaluateur_id() {
		return evaluateur_id;
	}
	public void setEvaluateur_id(int evaluateur_id) {
		this.evaluateur_id = evaluateur_id;
	}
	public int getEvalue_id() {
		return evalue_id;
	}
	public void setEvalue_id(int evalue_id) {
		this.evalue_id = evalue_id;
	}
	public int getNote() {
		return note;
	}
	public void setNote(int note) {
		this.note = note;
	}
	public String getCommentaire() {
		return commentaire;
	}
	public void setCommentaire(String commentaire) {
		this.commentaire = commentaire;
	}
	public LocalDateTime getDate_evaluation() {
		return date_evaluation;
	}
	public void setDate_evaluation(LocalDateTime date_evaluation) {
		this.date_evaluation = date_evaluation;
	}
	public Evaluation() {
		super();
	}
	public Evaluation(int evaluateur_id, int evalue_id, int note, String commentaire, LocalDateTime date_evaluation) {
		super();
		this.evaluateur_id = evaluateur_id;
		this.evalue_id = evalue_id;
		this.note = note;
		this.commentaire = commentaire;
		this.date_evaluation = date_evaluation;
	}
	public Evaluation(int id, int evaluateur_id, int evalue_id, int note, String commentaire,
			LocalDateTime date_evaluation) {
		super();
		this.id = id;
		this.evaluateur_id = evaluateur_id;
		this.evalue_id = evalue_id;
		this.note = note;
		this.commentaire = commentaire;
		this.date_evaluation = date_evaluation;
	}
	
	
}
