package Models;

import java.sql.Timestamp;

public class Trace_connexion_user {
	private int id;
	private int user_id;
	private String user_ip;
	private String browser;
	private java.sql.Timestamp login_date;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getUser_ip() {
		return user_ip;
	}
	public void setUser_ip(String user_ip) {
		this.user_ip = user_ip;
	}
	public String getBrowser() {
		return browser;
	}
	public void setBrowser(String browser) {
		this.browser = browser;
	}
	public java.sql.Timestamp getLogin_date() {
		return login_date;
	}
	public void setLogin_date(java.sql.Timestamp login_date) {
		this.login_date = login_date;
	}
	public Trace_connexion_user() {
	}
	public Trace_connexion_user(int user_id, String user_ip, String browser, Timestamp login_date) {
		this.user_id = user_id;
		this.user_ip = user_ip;
		this.browser = browser;
		this.login_date = login_date;
	}
	public Trace_connexion_user(int id, int user_id, String user_ip, String browser, Timestamp login_date) {
		this.id = id;
		this.user_id = user_id;
		this.user_ip = user_ip;
		this.browser = browser;
		this.login_date = login_date;
	}
	
	
	
}


