package Models;

public class ConversationInfo {
	private int id;
	private String nomUtilisateur;
    private String titreArticle;
    private double prixArticle;
    
    
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNomUtilisateur() {
		return nomUtilisateur;
	}
	public void setNomUtilisateur(String nomUtilisateur) {
		this.nomUtilisateur = nomUtilisateur;
	}
	public String getTitreArticle() {
		return titreArticle;
	}
	public void setTitreArticle(String titreArticle) {
		this.titreArticle = titreArticle;
	}
	public double getPrixArticle() {
		return prixArticle;
	}
	public void setPrixArticle(double prixArticle) {
		this.prixArticle = prixArticle;
	}
	public ConversationInfo() {
		super();
	}
	public ConversationInfo(String nomUtilisateur, String titreArticle, double prixArticle) {
		super();
		this.nomUtilisateur = nomUtilisateur;
		this.titreArticle = titreArticle;
		this.prixArticle = prixArticle;
	}
	public ConversationInfo(int id, String nomUtilisateur, String titreArticle, double prixArticle) {
		super();
		this.id = id;
		this.nomUtilisateur = nomUtilisateur;
		this.titreArticle = titreArticle;
		this.prixArticle = prixArticle;
	}
	@Override
	public String toString() {
		return "ConversationInfo [nomUtilisateur=" + nomUtilisateur + ", titreArticle=" + titreArticle
				+ ", prixArticle=" + prixArticle + "]";
	}
    
    

}
