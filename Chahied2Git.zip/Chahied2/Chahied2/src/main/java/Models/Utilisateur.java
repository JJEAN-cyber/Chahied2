package Models;


import java.sql.Timestamp;

public class Utilisateur {
	private int id;
	private String nom;
	private String email;
	private String mot_de_passe;
	private Timestamp date_inscription;
	private Timestamp date_connexion;
	private String ville;
	private String description;
	private String photo_profil;
	private boolean isBanned;
	private String adresse;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMot_de_passe() {
		return mot_de_passe;
	}
	public void setMot_de_passe(String mot_de_passe) {
		this.mot_de_passe = mot_de_passe;
	}
	public Timestamp getDate_inscription() {
		return date_inscription;
	}
	public void setDate_inscription(Timestamp date_inscription) {
		this.date_inscription = date_inscription;
	}
	public Timestamp getDate_connexion() {
		return date_connexion;
	}
	public void setDate_connexion(Timestamp date_connexion) {
		this.date_connexion = date_connexion;
	}
	public String getVille() {
		return ville;
	}
	public void setVille(String ville) {
		this.ville = ville;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPhoto_profil() {
		return photo_profil;
	}
	public void setPhoto_profil(String photo_profil) {
		this.photo_profil = photo_profil;
	}
	public boolean getIsBanned() {
		return isBanned;
	}
	public void setIsBanned(boolean isBanned) {
		this.isBanned = isBanned;
	}
		
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public Utilisateur() {
		super();
	}
	public Utilisateur(int id, String nom, String email, String mot_de_passe, Timestamp date_inscription,
			Timestamp date_connexion, String ville, String description, String photo_profil, boolean isBanned,
			String adresse) {
		super();
		this.id = id;
		this.nom = nom;
		this.email = email;
		this.mot_de_passe = mot_de_passe;
		this.date_inscription = date_inscription;
		this.date_connexion = date_connexion;
		this.ville = ville;
		this.description = description;
		this.photo_profil = photo_profil;
		this.isBanned = isBanned;
		this.adresse = adresse;
	}
	public Utilisateur(String nom, String email, String mot_de_passe, Timestamp date_inscription,
			Timestamp date_connexion, String ville, String description, String photo_profil, boolean isBanned,
			String adresse) {
		super();
		this.nom = nom;
		this.email = email;
		this.mot_de_passe = mot_de_passe;
		this.date_inscription = date_inscription;
		this.date_connexion = date_connexion;
		this.ville = ville;
		this.description = description;
		this.photo_profil = photo_profil;
		this.isBanned = isBanned;
		this.adresse = adresse;
	}
	
	
	
	
}
