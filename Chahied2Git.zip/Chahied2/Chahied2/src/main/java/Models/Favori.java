package Models;

public class Favori {
	private int id;
	private int utilisateur_id;
	private int article_id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUtilisateur_id() {
		return utilisateur_id;
	}
	public void setUtilisateur_id(int utilisateur_id) {
		this.utilisateur_id = utilisateur_id;
	}
	public int getArticle_id() {
		return article_id;
	}
	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}
	public Favori() {
		super();
	}
	public Favori(int utilisateur_id, int article_id) {
		super();
		this.utilisateur_id = utilisateur_id;
		this.article_id = article_id;
	}
	public Favori(int id, int utilisateur_id, int article_id) {
		super();
		this.id = id;
		this.utilisateur_id = utilisateur_id;
		this.article_id = article_id;
	}
	
	
}
