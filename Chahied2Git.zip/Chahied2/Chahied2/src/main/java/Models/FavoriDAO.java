package Models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class FavoriDAO {
public void save(Favori obj) {
		
		try {
			
			if(obj.getId() != 0) {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("UPDATE favori set utilisateur_id=?,article_id=? WHERE id=?");
				preparedStatement.setInt(1,obj.getUtilisateur_id());
				preparedStatement.setInt(2,obj.getArticle_id());				
				preparedStatement.setInt(3,obj.getId());
	            preparedStatement.executeUpdate();
			}else {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("INSERT INTO favori (utilisateur_id,article_id) VALUES(?,?)");
				preparedStatement.setInt(1,obj.getUtilisateur_id());
				preparedStatement.setInt(2,obj.getArticle_id());				
	            preparedStatement.executeUpdate();
			}
			System.out.println("SAVED OK");
			
		} catch (Exception ex) {
        	ex.printStackTrace();
        	System.out.println("SAVED NO");
        }
	
}
public Set<Integer> getFavorisIdsByUserId(int userId) {
    Set<Integer> favorisIds = new HashSet<>();
    String sql = "SELECT article_id FROM favori WHERE utilisateur_id = ?";
    try (PreparedStatement ps = Database.connexion.prepareStatement(sql)) {
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            favorisIds.add(rs.getInt("article_id"));
        }
    } catch (Exception ex) {
        ex.printStackTrace();
        System.out.println(" NO NO n'a pas selecté");
    }
    System.out.println("Favoris trouvés pour userId " + userId + " : " + favorisIds);
    return favorisIds;
}

public ArrayList<Favori> getAll() {
	ArrayList<Favori> list = new ArrayList<Favori>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM favori");
			
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Favori u = new Favori();
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt( "utilisateur_id" ));
				u.setArticle_id(resultat.getInt( "article_id" ));
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}
public void deleteById(int id) {
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM favori WHERE id=?");
			preparedStatement.setInt(1,id);
			
			preparedStatement.executeUpdate();
			
			System.out.println("DELETED OK");
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	System.out.println("DELETED NO");
    }
}
public void supprimerFavori(int userId, int articleId) {
    String sql = "DELETE FROM favori WHERE utilisateur_id = ? AND article_id = ?";
    try (PreparedStatement ps = Database.connexion.prepareStatement(sql)) {
        ps.setInt(1, userId);
        ps.setInt(2, articleId);
        ps.executeUpdate();
    	System.out.println("DELETED OK");
		
    	} catch (Exception ex) {
        	ex.printStackTrace();
        	System.out.println("DELETED NO");
        }
    }

public void ajouterFavori(int userId, int articleId) {
    String sql = "INSERT INTO favori (utilisateur_id, article_id) VALUES (?, ?)";
    try (PreparedStatement ps = Database.connexion.prepareStatement(sql)) {
        ps.setInt(1, userId);
        ps.setInt(2, articleId);
        ps.executeUpdate();
        System.out.println("SAVED OK");
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	System.out.println("SAVED NO");
    }
}

public int getNbreFavoris(int articleId) {
    int nbFavoris = 0;
    try {
        PreparedStatement stmt = Database.connexion.prepareStatement(
            "SELECT get_nbre_favoris(?) AS nb"
        );
        stmt.setInt(1, articleId);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            nbFavoris = rs.getInt("nb");
        }
        rs.close();
        stmt.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return nbFavoris;
}

public ArrayList<Integer> getListArticlesByFavoriIdsByUserId(int userId) {
    ArrayList<Integer> favorisIds = new ArrayList<>();
    String sql = "SELECT article_id FROM favori WHERE utilisateur_id = ?";
    try (PreparedStatement ps = Database.connexion.prepareStatement(sql)) {
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            favorisIds.add(rs.getInt("article_id"));
        }
    } catch (Exception ex) {
        ex.printStackTrace();
        System.out.println("Erreur lors de la récupération des favoris");
    }
    System.out.println("Favoris trouvés pour userId " + userId + " : " + favorisIds);
    return favorisIds;
}

}
