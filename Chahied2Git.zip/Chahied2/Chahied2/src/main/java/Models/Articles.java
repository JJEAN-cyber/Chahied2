package Models;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;

public class Articles {
	private int id;
	private int utilisateur_id;
	private String titre;
	private String description;
	private int sous_sous_categorie_id;
	private int sous_sous_actegorie_id;
	private String etat;
	private double prix;
	private String format_envoi;
	private LocalDateTime date_publication; // parfait pour DATETIME
	private String couleur;
	private String matiere;
	private String taille;
	private String marque;
	private int nbre_vues;
	private boolean disponible;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUtilisateur_id() {
		return utilisateur_id;
	}
	public void setUtilisateur_id(int utilisateur_id) {
		this.utilisateur_id = utilisateur_id;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getSous_sous_categorie_id() {
		return sous_sous_categorie_id;
	}
	public void setSous_sous_categorie_id(int sous_sous_categorie_id) {
		this.sous_sous_categorie_id = sous_sous_categorie_id;
	}
	public int getSous_sous_actegorie_id() {
		return sous_sous_actegorie_id;
	}
	public void setSous_sous_actegorie_id(int sous_sous_actegorie_id) {
		this.sous_sous_actegorie_id = sous_sous_actegorie_id;
	}
	public String getEtat() {
		return etat;
	}
	public void setEtat(String etat) {
		this.etat = etat;
	}
	public double getPrix() {
		return prix;
	}
	public void setPrix(double prix) {
		this.prix = prix;
	}
	public String getFormat_envoi() {
		return format_envoi;
	}
	public void setFormat_envoi(String format_envoi) {
		this.format_envoi = format_envoi;
	}


	public LocalDateTime getDate_publication() {
		return date_publication;
	}
	public void setDate_publication(LocalDateTime date_publication) {
		this.date_publication = date_publication;
	}


	public String getCouleur() {
		return this.couleur;
	}

	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}

	public String getMatiere() {
		return this.matiere;
	}

	public void setMatiere(String matiere) {
		this.matiere = matiere;
	}

	// Méthodes utilitaires pour la logique métier (ArrayList)
	public ArrayList<String> getCouleurList() {
		return (couleur != null && !couleur.isEmpty()) ? 
				new ArrayList<>(Arrays.asList(couleur.split(";"))) : 
					new ArrayList<>();
	}

	public void setCouleurList(ArrayList<String> couleurs) {
		this.couleur = (couleurs != null) ? 
				String.join(";", couleurs) : 
					"";
	}

	// Idem pour matiere
	public ArrayList<String> getMatiereList() {
		return (matiere != null && !matiere.isEmpty()) ? 
				new ArrayList<>(Arrays.asList(matiere.split(";"))) : 
					new ArrayList<>();
	}

	public void setMatiereList(ArrayList<String> matieres) {
		this.matiere = (matieres != null) ? 
				String.join(";", matieres) : 
					"";
	}


	public String getTaille() {
		return taille;
	}
	public void setTaille(String taille) {
		this.taille = taille;
	}

	public String getMarque() {
		return marque;
	}
	public void setMarque(String marque) {
		this.marque = marque;
	}
	
	public int getNbre_vues() {
		return nbre_vues;
	}
	public void setNbre_vues(int nbre_vues) {
		this.nbre_vues = nbre_vues;
	}
	
	public boolean getDisponible() {
		return disponible;
	}
	public void setDisponible(boolean disponible) {
		this.disponible = disponible;
	}
	public Articles() {
		super();
	}
	public Articles(int utilisateur_id, String titre, String description, int sous_sous_categorie_id,
			int sous_sous_actegorie_id, String etat, double prix, String format_envoi, LocalDateTime date_publication,
			String couleur, String matiere, String taille, String marque, int nbre_vues, boolean disponible) {
		super();
		this.utilisateur_id = utilisateur_id;
		this.titre = titre;
		this.description = description;
		this.sous_sous_categorie_id = sous_sous_categorie_id;
		this.sous_sous_actegorie_id = sous_sous_actegorie_id;
		this.etat = etat;
		this.prix = prix;
		this.format_envoi = format_envoi;
		this.date_publication = date_publication;
		this.couleur = couleur;
		this.matiere = matiere;
		this.taille = taille;
		this.marque = marque;
		this.nbre_vues = nbre_vues;
		this.disponible = disponible;
	}
	public Articles(int id, int utilisateur_id, String titre, String description, int sous_sous_categorie_id,
			int sous_sous_actegorie_id, String etat, double prix, String format_envoi, LocalDateTime date_publication,
			String couleur, String matiere, String taille, String marque, int nbre_vues, boolean disponible) {
		super();
		this.id = id;
		this.utilisateur_id = utilisateur_id;
		this.titre = titre;
		this.description = description;
		this.sous_sous_categorie_id = sous_sous_categorie_id;
		this.sous_sous_actegorie_id = sous_sous_actegorie_id;
		this.etat = etat;
		this.prix = prix;
		this.format_envoi = format_envoi;
		this.date_publication = date_publication;
		this.couleur = couleur;
		this.matiere = matiere;
		this.taille = taille;
		this.marque = marque;
		this.nbre_vues = nbre_vues;
		this.disponible = disponible;
	}
	
}
