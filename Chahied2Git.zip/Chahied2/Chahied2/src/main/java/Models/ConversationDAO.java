package Models;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class ConversationDAO {
    public int getOrCreateConversationId(int expediteurId, int destinataireId, int articleId) {
        int user1 = Math.min(expediteurId, destinataireId);
        int user2 = Math.max(expediteurId, destinataireId);
        int conversationId = 0;

        // 1. Essaie de récupérer l'id de la conversation existante
        String selectSql = "SELECT id FROM conversation WHERE participant1_id = ? AND participant2_id = ? AND article_id = ?";
        try (PreparedStatement ps = Database.connexion.prepareStatement(selectSql)) {
            ps.setInt(1, user1);
            ps.setInt(2, user2);
            ps.setInt(3, articleId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    conversationId = rs.getInt("id");
                    return conversationId;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }

        // 2. Si la conversation n'existe pas, la créer
        String insertSql = "INSERT INTO conversation (participant1_id, participant2_id, last_updated, article_id) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = Database.connexion.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, user1);
            ps.setInt(2, user2);
            ps.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now())); // <-- ici
            ps.setInt(4, articleId);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    conversationId = rs.getInt(1);
                    return conversationId;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
        return -1;
    }

    public ArrayList<Conversation> getConversationsWithArticle(int userId) {
        ArrayList<Conversation> conversations = new ArrayList<>();
        String sql = "CALL list_conversations_with_article(?)";
        try (CallableStatement cs = Database.connexion.prepareCall(sql)) {
            cs.setInt(1, userId);
            try (ResultSet rs = cs.executeQuery()) {
                while (rs.next()) {
                    Conversation conv = new Conversation();
                    conv.setId(rs.getInt("conversation_id"));
                    conv.setParticipant1_id(rs.getInt("participant1_id"));
                    conv.setParticipant2_id(rs.getInt("participant2_id"));
                    conv.setLast_message_snippet(rs.getString("last_message_snippet"));
                    conv.setLast_updated(rs.getTimestamp("last_updated").toLocalDateTime());                    
                    conv.setArticle_id(rs.getInt("article_id"));
                    conv.setArticle_nom(rs.getString("article_nom"));
                    conv.setParticipant1_nom(rs.getString("participant1_nom"));
                    conv.setParticipant2_nom(rs.getString("participant2_nom"));

                    conversations.add(conv);
                }
            }
        }  catch (SQLException e) {
            // Tu peux logger l'erreur ici, ou retourner une liste vide, selon ton besoin
            e.printStackTrace();
            System.out.println("pas de liste ");
        }
        return conversations;
    }
    
    
    public Conversation getById(int id) {
        try {
            CallableStatement cs = Database.connexion.prepareCall("{CALL getConversationWithNames(?)}");
            cs.setInt(1, id);
            ResultSet rs = cs.executeQuery();
            if (rs.next()) {
                Conversation u = new Conversation();
                u.setId(rs.getInt("id"));
                u.setParticipant1_id(rs.getInt("participant1_id"));
                u.setParticipant2_id(rs.getInt("participant2_id"));
                u.setLast_message_snippet(rs.getString("last_message_snippet"));
                u.setLast_updated(rs.getTimestamp("last_updated").toLocalDateTime());
                u.setArticle_id(rs.getInt("article_id"));
                u.setParticipant1_nom(rs.getString("participant1_nom"));
                u.setParticipant2_nom(rs.getString("participant2_nom"));
                return u;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

}
