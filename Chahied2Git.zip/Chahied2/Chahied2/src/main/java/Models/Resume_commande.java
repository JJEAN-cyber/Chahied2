package Models;

public class Resume_commande {
	private int id;
	private int commande_id;
	private int article_id;
	private double total_commande;
	private double frais_protection_acheteur;
	private double frais_port;
	private double total_frais_commande;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCommande_id() {
		return commande_id;
	}
	public void setCommande_id(int commande_id) {
		this.commande_id = commande_id;
	}
	
	public int getArticle_id() {
		return article_id;
	}
	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}
	public double getTotal_commande() {
		return total_commande;
	}
	public void setTotal_commande(double total_commande) {
		this.total_commande = total_commande;
	}
	public double getFrais_protection_acheteur() {
		return frais_protection_acheteur;
	}
	public void setFrais_protection_acheteur(double frais_protection_acheteur) {
		this.frais_protection_acheteur = frais_protection_acheteur;
	}
	public double getFrais_port() {
		return frais_port;
	}
	public void setFrais_port(double frais_port) {
		this.frais_port = frais_port;
	}
	public double getTotal_frais_commande() {
		return total_frais_commande;
	}
	public void setTotal_frais_commande(double total_frais_commande) {
		this.total_frais_commande = total_frais_commande;
	}
	
	public Resume_commande() {
		super();
	}
	public Resume_commande(int id, int commande_id, int article_id, double total_commande,
			double frais_protection_acheteur, double frais_port, double total_frais_commande) {
		super();
		this.id = id;
		this.commande_id = commande_id;
		this.article_id = article_id;
		this.total_commande = total_commande;
		this.frais_protection_acheteur = frais_protection_acheteur;
		this.frais_port = frais_port;
		this.total_frais_commande = total_frais_commande;
	}
	public Resume_commande(int commande_id, int article_id, double total_commande, double frais_protection_acheteur,
			double frais_port, double total_frais_commande) {
		super();
		this.commande_id = commande_id;
		this.article_id = article_id;
		this.total_commande = total_commande;
		this.frais_protection_acheteur = frais_protection_acheteur;
		this.frais_port = frais_port;
		this.total_frais_commande = total_frais_commande;
	}
	@Override
	public String toString() {
		return "Resume_commande [id=" + id + ", commande_id=" + commande_id + ", article_id=" + article_id
				+ ", total_commande=" + total_commande + ", frais_protection_acheteur=" + frais_protection_acheteur
				+ ", frais_port=" + frais_port + ", total_frais_commande=" + total_frais_commande + "]";
	}
	
}