package Models;

import java.time.LocalDateTime;

public class Message {
	private int id;
	private int expediteur_id;
	private int destinataire_id;
	private String contenu;
	private LocalDateTime date_envoi;
	private int article_id;
	private int conversation_id;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getExpediteur_id() {
		return expediteur_id;
	}
	public void setExpediteur_id(int expediteur_id) {
		this.expediteur_id = expediteur_id;
	}
	public int getDestinataire_id() {
		return destinataire_id;
	}
	public void setDestinataire_id(int destinataire_id) {
		this.destinataire_id = destinataire_id;
	}
	public String getContenu() {
		return contenu;
	}
	public void setContenu(String contenu) {
		this.contenu = contenu;
	}
	public LocalDateTime getDate_envoi() {
		return date_envoi;
	}
	public void setDate_envoi(LocalDateTime date_envoi) {
		this.date_envoi = date_envoi;
	}
	
	
	public int getArticle_id() {
		return article_id;
	}
	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}
	
	public int getConversation_id() {
		return conversation_id;
	}
	public void setConversation_id(int conversation_id) {
		this.conversation_id = conversation_id;
	}
	public Message() {
		super();
	}
	public Message(int id, int expediteur_id, int destinataire_id, String contenu, LocalDateTime date_envoi,
			int article_id, int conversation_id) {
		super();
		this.id = id;
		this.expediteur_id = expediteur_id;
		this.destinataire_id = destinataire_id;
		this.contenu = contenu;
		this.date_envoi = date_envoi;
		this.article_id = article_id;
		this.conversation_id = conversation_id;
	}
	public Message(int expediteur_id, int destinataire_id, String contenu, LocalDateTime date_envoi, int article_id,
			int conversation_id) {
		super();
		this.expediteur_id = expediteur_id;
		this.destinataire_id = destinataire_id;
		this.contenu = contenu;
		this.date_envoi = date_envoi;
		this.article_id = article_id;
		this.conversation_id = conversation_id;
	}
	
}
	
