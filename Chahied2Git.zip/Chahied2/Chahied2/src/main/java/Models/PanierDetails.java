package Models;

public class PanierDetails {
	private Articles articles;

	
	public PanierDetails() {
	}
	public PanierDetails(Articles articles) {
		super();
		this.articles = articles;
		
	}
	
	public Articles getArticles() {
		return articles;
	}
	public void setArticles(Articles articles) {
		this.articles = articles;
	}
	@Override
	public String toString() {
		return "PanierDetails [articles=" + articles + "]";
	}
	
	
	}


