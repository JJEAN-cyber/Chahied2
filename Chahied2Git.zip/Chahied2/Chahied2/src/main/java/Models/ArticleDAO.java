package Models;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;

public class ArticleDAO {
public int save(Articles obj) {
		int newid=-1;// preference -1 que 0 pour la stabiliter du sgbd car 0 peut etre interpreter comme 1
		try {
			
			if(obj.getId() != 0) {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("UPDATE articles set utilisateur_id=?, titre=?, description=?, sous_sous_categorie_id=?, sous_sous_actegorie_id=?, etat=?, prix=?, format_envoi=?, date_publication=?, couleur=?, matiere=?, taille=?, marque=?, nbre_vues=?, disponible=? WHERE id=?");
				preparedStatement.setInt(1,obj.getUtilisateur_id());
				preparedStatement.setString(2,obj.getTitre());
				preparedStatement.setString(3,obj.getDescription());
				preparedStatement.setInt(4,obj.getSous_sous_categorie_id());
				preparedStatement.setInt(5,obj.getSous_sous_actegorie_id());
				preparedStatement.setString(6,obj.getEtat());
				preparedStatement.setDouble(7,obj.getPrix());
				preparedStatement.setString(8,obj.getFormat_envoi());
				preparedStatement.setTimestamp(9, Timestamp.valueOf(obj.getDate_publication()));	
				preparedStatement.setString(10,obj.getCouleur());
				preparedStatement.setString(11,obj.getMatiere());
				preparedStatement.setString(12,obj.getTaille());
				preparedStatement.setString(13,obj.getMarque());
				preparedStatement.setInt(14,obj.getNbre_vues());
				preparedStatement.setBoolean(15,obj.getDisponible());
				preparedStatement.setInt(16,obj.getId());
				
	            preparedStatement.executeUpdate();
	            newid=obj.getUtilisateur_id();
			}else {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("INSERT INTO articles (utilisateur_id,titre,description,sous_sous_categorie_id,sous_sous_actegorie_id,etat,prix,format_envoi,date_publication,couleur,matiere, taille, marque, nbre_vues, disponible) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
				preparedStatement.setInt(1,obj.getUtilisateur_id());
				preparedStatement.setString(2,obj.getTitre());
				preparedStatement.setString(3,obj.getDescription());
				preparedStatement.setInt(4,obj.getSous_sous_categorie_id());
				preparedStatement.setInt(5,obj.getSous_sous_actegorie_id());
				preparedStatement.setString(6,obj.getEtat());
				preparedStatement.setDouble(7,obj.getPrix());
				preparedStatement.setString(8,obj.getFormat_envoi());
				preparedStatement.setTimestamp(9, Timestamp.valueOf(obj.getDate_publication()));	
				preparedStatement.setString(10,obj.getCouleur());
				preparedStatement.setString(11,obj.getMatiere());
				preparedStatement.setString(12,obj.getTaille());
				preparedStatement.setString(13,obj.getMarque());
				preparedStatement.setInt(14,obj.getNbre_vues());
				preparedStatement.setBoolean(15,obj.getDisponible());				
				
	            preparedStatement.executeUpdate();
	            
	            ResultSet resultat = preparedStatement.getGeneratedKeys();
	            resultat.next();
	            newid= resultat.getInt(1);
			}
			System.out.println("SAVED OK");
			
		} catch (Exception ex) {
        	ex.printStackTrace();
        	System.out.println("SAVED NO");
        }
	return newid;
}
public Articles getById(int id) {
	try {
	
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM articles WHERE id=?");
			preparedStatement.setInt(1,id);
			
			ResultSet resultat=preparedStatement.executeQuery();
			
			Articles u = new Articles();
			while(resultat.next()) {
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt("utilisateur_id"));
				u.setTitre(resultat.getString( "titre" ));
				u.setDescription(resultat.getString( "description" ));
				u.setSous_sous_categorie_id(resultat.getInt("sous_sous_categorie_id"));
				u.setSous_sous_actegorie_id(resultat.getInt("sous_sous_actegorie_id"));
				u.setEtat(resultat.getString("etat"));
				u.setPrix(resultat.getDouble( "prix" ));
				u.setFormat_envoi(resultat.getString("format_envoi"));
				u.setDate_publication(resultat.getTimestamp("date_publication").toLocalDateTime());
				u.setCouleur(resultat.getString("couleur"));
				u.setMatiere(resultat.getString("matiere"));
				u.setTaille(resultat.getString("taille"));
				u.setMarque(resultat.getString("marque"));
				u.setNbre_vues(resultat.getInt("nbre_vues"));
				u.setDisponible(resultat.getBoolean("disponible"));
			}
			return u;
			}
	 catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}
public ArrayList<Articles> getAll() {
	ArrayList<Articles> list = new ArrayList<Articles>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM articles WHERE disponible = 1");
			
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Articles u = new Articles();
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt("utilisateur_id"));
				u.setTitre(resultat.getString( "titre" ));
				u.setDescription(resultat.getString( "description" ));
				u.setSous_sous_categorie_id(resultat.getInt("sous_sous_categorie_id"));
				u.setSous_sous_actegorie_id(resultat.getInt("sous_sous_actegorie_id"));
				u.setEtat(resultat.getString("etat"));
				u.setPrix(resultat.getDouble( "prix" ));
				u.setFormat_envoi(resultat.getString("format_envoi"));
				u.setDate_publication(resultat.getTimestamp("date_publication").toLocalDateTime());
				u.setCouleur(resultat.getString("couleur"));
				u.setMatiere(resultat.getString("matiere"));
				u.setTaille(resultat.getString("taille"));
				u.setMarque(resultat.getString("marque"));
				u.setNbre_vues(resultat.getInt("nbre_vues"));
				u.setDisponible(resultat.getBoolean("disponible"));
			
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}
public ArrayList<Articles> getAllByCat(int catid) {
	ArrayList<Articles> list = new ArrayList<Articles>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM articles WHERE sous_sous_categorie_id=?");
			preparedStatement.setInt(1,catid);
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Articles u = new Articles();
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt("utilisateur_id"));
				u.setTitre(resultat.getString( "titre" ));
				u.setDescription(resultat.getString( "description" ));
				u.setSous_sous_categorie_id(resultat.getInt("sous_sous_categorie_id"));
				u.setSous_sous_actegorie_id(resultat.getInt("sous_sous_actegorie_id"));
				u.setEtat(resultat.getString("etat"));
				u.setPrix(resultat.getDouble( "prix" ));
				u.setFormat_envoi(resultat.getString("format_envoi"));
				u.setDate_publication(resultat.getTimestamp("date_publication").toLocalDateTime());
				u.setCouleur(resultat.getString("couleur"));
				u.setMatiere(resultat.getString("matiere"));
				u.setTaille(resultat.getString("taille"));
				u.setMarque(resultat.getString("marque"));
				u.setNbre_vues(resultat.getInt("nbre_vues"));
				u.setDisponible(resultat.getBoolean("disponible"));
			
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}
public ArrayList<Articles> getAllByScat(int catid) {
	ArrayList<Articles> list = new ArrayList<Articles>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM articles WHERE sous_sous_categorie_id IN ( " +
	                 "SELECT id FROM sous_sous_categorie WHERE sous_categorie_id = ? )");
			preparedStatement.setInt(1,catid);
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Articles u = new Articles();
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt("utilisateur_id"));
				u.setTitre(resultat.getString( "titre" ));
				u.setDescription(resultat.getString( "description" ));
				u.setSous_sous_categorie_id(resultat.getInt("sous_sous_categorie_id"));
				u.setSous_sous_actegorie_id(resultat.getInt("sous_sous_actegorie_id"));
				u.setEtat(resultat.getString("etat"));
				u.setPrix(resultat.getDouble( "prix" ));
				u.setFormat_envoi(resultat.getString("format_envoi"));
				u.setDate_publication(resultat.getTimestamp("date_publication").toLocalDateTime());
				u.setCouleur(resultat.getString("couleur"));
				u.setMatiere(resultat.getString("matiere"));
				u.setTaille(resultat.getString("taille"));
				u.setMarque(resultat.getString("marque"));
				u.setNbre_vues(resultat.getInt("nbre_vues"));
				u.setDisponible(resultat.getBoolean("disponible"));
			
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}
public ArrayList<Articles> getAllByfCat(int catid) {
	ArrayList<Articles> list = new ArrayList<Articles>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM articles " +
			        "WHERE sous_sous_categorie_id IN ( " +
			        "    SELECT id FROM sous_sous_categorie WHERE sous_categorie_id IN ( " +
			        "        SELECT id FROM sous_categorie WHERE categorie_id = ? " +
			        "    ) " +
			        ")");
			preparedStatement.setInt(1,catid);
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Articles u = new Articles();
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt("utilisateur_id"));
				u.setTitre(resultat.getString( "titre" ));
				u.setDescription(resultat.getString( "description" ));
				u.setSous_sous_categorie_id(resultat.getInt("sous_sous_categorie_id"));
				u.setSous_sous_actegorie_id(resultat.getInt("sous_sous_actegorie_id"));
				u.setEtat(resultat.getString("etat"));
				u.setPrix(resultat.getDouble( "prix" ));
				u.setFormat_envoi(resultat.getString("format_envoi"));
				u.setDate_publication(resultat.getTimestamp("date_publication").toLocalDateTime());
				u.setCouleur(resultat.getString("couleur"));
				u.setMatiere(resultat.getString("matiere"));
				u.setTaille(resultat.getString("taille"));
				u.setMarque(resultat.getString("marque"));
				u.setNbre_vues(resultat.getInt("nbre_vues"));
				u.setDisponible(resultat.getBoolean("disponible"));
			
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}

public ArrayList<Articles> getAllByAct(int actid) {
	ArrayList<Articles> list = new ArrayList<Articles>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM articles WHERE sous_sous_actegorie_id=?");
			preparedStatement.setInt(1,actid);
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Articles u = new Articles();
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt("utilisateur_id"));
				u.setTitre(resultat.getString( "titre" ));
				u.setDescription(resultat.getString( "description" ));
				u.setSous_sous_categorie_id(resultat.getInt("sous_sous_categorie_id"));
				u.setSous_sous_actegorie_id(resultat.getInt("sous_sous_actegorie_id"));
				u.setEtat(resultat.getString("etat"));
				u.setPrix(resultat.getDouble( "prix" ));
				u.setFormat_envoi(resultat.getString("format_envoi"));
				u.setDate_publication(resultat.getTimestamp("date_publication").toLocalDateTime());
				u.setCouleur(resultat.getString("couleur"));
				u.setMatiere(resultat.getString("matiere"));
				u.setTaille(resultat.getString("taille"));
				u.setMarque(resultat.getString("marque"));
				u.setNbre_vues(resultat.getInt("nbre_vues"));
				u.setDisponible(resultat.getBoolean("disponible"));
			
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}
public ArrayList<Articles> getAllBySact(int actid) {
	ArrayList<Articles> list = new ArrayList<Articles>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM articles WHERE sous_sous_categorie_id IN ( " +
	                 "SELECT id FROM sous_sous_categorie WHERE sous_categorie_id = ? )");
			preparedStatement.setInt(1,actid);
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Articles u = new Articles();
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt("utilisateur_id"));
				u.setTitre(resultat.getString( "titre" ));
				u.setDescription(resultat.getString( "description" ));
				u.setSous_sous_categorie_id(resultat.getInt("sous_sous_categorie_id"));
				u.setSous_sous_actegorie_id(resultat.getInt("sous_sous_actegorie_id"));
				u.setEtat(resultat.getString("etat"));
				u.setPrix(resultat.getDouble( "prix" ));
				u.setFormat_envoi(resultat.getString("format_envoi"));
				u.setDate_publication(resultat.getTimestamp("date_publication").toLocalDateTime());
				u.setCouleur(resultat.getString("couleur"));
				u.setMatiere(resultat.getString("matiere"));
				u.setTaille(resultat.getString("taille"));
				u.setMarque(resultat.getString("marque"));
				u.setNbre_vues(resultat.getInt("nbre_vues"));
				u.setDisponible(resultat.getBoolean("disponible"));
			
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
	
}
public ArrayList<Articles> getAllByfAct(int actid) {
	ArrayList<Articles> list = new ArrayList<Articles>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM articles " +
			        "WHERE sous_sous_actegorie_id IN ( " +
			        "    SELECT id FROM sous_sous_actegorie WHERE sous_actegorie_id IN ( " +
			        "        SELECT id FROM sous_actegorie WHERE actegorie_id = ? " +
			        "    ) " +
			        ")");
			preparedStatement.setInt(1,actid);
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Articles u = new Articles();
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt("utilisateur_id"));
				u.setTitre(resultat.getString( "titre" ));
				u.setDescription(resultat.getString( "description" ));
				u.setSous_sous_categorie_id(resultat.getInt("sous_sous_categorie_id"));
				u.setSous_sous_actegorie_id(resultat.getInt("sous_sous_actegorie_id"));
				u.setEtat(resultat.getString("etat"));
				u.setPrix(resultat.getDouble( "prix" ));
				u.setFormat_envoi(resultat.getString("format_envoi"));
				u.setDate_publication(resultat.getTimestamp("date_publication").toLocalDateTime());
				u.setCouleur(resultat.getString("couleur"));
				u.setMatiere(resultat.getString("matiere"));
				u.setTaille(resultat.getString("taille"));
				u.setMarque(resultat.getString("marque"));
				u.setNbre_vues(resultat.getInt("nbre_vues"));
				u.setDisponible(resultat.getBoolean("disponible"));
			
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}
public ArrayList<Articles> RechercherART(String mot) {
	ArrayList<Articles> list = new ArrayList<Articles>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion
					.prepareStatement("SELECT * FROM articles WHERE titre like ?");
			preparedStatement.setString(1,"%"+mot+"%");
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Articles u = new Articles();
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt("utilisateur_id"));
				u.setTitre(resultat.getString( "titre" ));
				u.setDescription(resultat.getString( "description" ));
				u.setSous_sous_categorie_id(resultat.getInt("sous_sous_categorie_id"));
				u.setSous_sous_actegorie_id(resultat.getInt("sous_sous_actegorie_id"));
				u.setEtat(resultat.getString("etat"));
				u.setPrix(resultat.getDouble( "prix" ));
				u.setFormat_envoi(resultat.getString("format_envoi"));
				u.setDate_publication(resultat.getTimestamp("date_publication").toLocalDateTime());
				u.setCouleur(resultat.getString("couleur"));
				u.setMatiere(resultat.getString("matiere"));
				u.setTaille(resultat.getString("taille"));
				u.setMarque(resultat.getString("marque"));
				u.setNbre_vues(resultat.getInt("nbre_vues"));
				u.setDisponible(resultat.getBoolean("disponible"));
			
				list.add(u);
			}
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}

public void deleteById(int id) {
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM articles WHERE id=?");
			preparedStatement.setInt(1,id);
			
			preparedStatement.executeUpdate();
			
			System.out.println("DELETED OK");
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	System.out.println("DELETED NO");
    }
}
public int incrementerEtGetNbreVues(int articleId) {
    int vues = 0;
    try {
        // Appel de la procédure stockée pour incrémenter
        CallableStatement callStmt = Database.connexion.prepareCall("{CALL incrementer_vue(?)}");
        callStmt.setInt(1, articleId);
        callStmt.execute();
        callStmt.close();

        // Lecture du nombre de vues à jour
        PreparedStatement selectStmt = Database.connexion.prepareStatement(
            "SELECT nbre_vues FROM articles WHERE id = ?"
        );
        selectStmt.setInt(1, articleId);
        ResultSet rs = selectStmt.executeQuery();
        if (rs.next()) {
            vues = rs.getInt("nbre_vues");
        }
        rs.close();
        selectStmt.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return vues;
}

public void setIndisponible(int articleId) {
    try {
        PreparedStatement ps = Database.connexion.prepareStatement(
            "UPDATE articles SET disponible = 0 WHERE id = ?"
        );
        ps.setInt(1, articleId);
        ps.executeUpdate();
        System.out.println("Article " + articleId + " marqué comme indisponible");
    } catch (Exception e) {
        e.printStackTrace();
    }
}
public int getOwnerId(int articleId) {
    int ownerId = 0;
    try {
        PreparedStatement ps = Database.connexion.prepareStatement(
            "SELECT utilisateur_id FROM articles WHERE id = ?"
        );
        ps.setInt(1, articleId);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            ownerId = rs.getInt("utilisateur_id"); // supposé que c'est ce champ qui contient le propriétaire
        }
        rs.close();
        ps.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return ownerId;
}

}
