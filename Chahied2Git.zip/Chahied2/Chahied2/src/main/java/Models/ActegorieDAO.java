package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ActegorieDAO {
public void save(Actegorie obj) {
		
		try {
			
			if(obj.getId() != 0) {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("UPDATE actegorie set titre=? WHERE id=?");
				preparedStatement.setString(1,obj.getTitre());
				preparedStatement.setInt(2,obj.getId());
	            preparedStatement.executeUpdate();
			}else {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("INSERT INTO actegorie (titre) VALUES(?)");
				preparedStatement.setString(1,obj.getTitre());
	            preparedStatement.executeUpdate();
			}
			System.out.println("SAVED OK");
			
		} catch (Exception ex) {
        	ex.printStackTrace();
        	System.out.println("SAVED NO");
        }
	
}

	public Actegorie getById(int id) {
		try {
		
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM actegorie WHERE id=?");
				preparedStatement.setInt(1,id);
				
				ResultSet resultat=preparedStatement.executeQuery();
				
				Actegorie u = new Actegorie();
				while(resultat.next()) {
					u.setId(resultat.getInt( "id" ));
					u.setTitre(resultat.getString( "titre" ));
				}
				return u;
			
		} catch (Exception ex) {
	    	ex.printStackTrace();
	    	return null;
	    }
	}
	public int getCountArticlesByIdAct(int id) {
		try {
		
				PreparedStatement preparedStatement  = Database.connexion.
		prepareStatement("SELECT COUNT(*) as nbr FROM articles WHERE actegorie_id=?");
				preparedStatement.setInt(1,id);
				
				ResultSet resultat=preparedStatement.executeQuery();
				resultat.next();

				int nbr = resultat.getInt( "nbr" );
				return nbr;
			
		} catch (Exception ex) {
	    	ex.printStackTrace();
	    	return 0;
	    }
	}
	
	public ArrayList<Actegorie> RechercherACT(String mot) {
		ArrayList<Actegorie> list = new ArrayList<Actegorie>();
		try {
			
				PreparedStatement preparedStatement  = Database.connexion
						.prepareStatement("SELECT * FROM actegorie WHERE titre like ?");
				preparedStatement.setString(1,"%"+mot+"%");
				ResultSet resultat=preparedStatement.executeQuery();

				while(resultat.next()) {
					Actegorie u = new Actegorie();
					u.setId(resultat.getInt( "id" ));
					u.setTitre(resultat.getString( "titre" ));
					list.add(u);
				}
				return list;
			
		} catch (Exception ex) {
	    	ex.printStackTrace();
	    	return null;
	    }
	}
	
	public ArrayList<Actegorie> getAll() {
		ArrayList<Actegorie> list = new ArrayList<Actegorie>();
		try {
			
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM actegorie");
				
				ResultSet resultat=preparedStatement.executeQuery();

				while(resultat.next()) {
					Actegorie o = new Actegorie();
					o.setId(resultat.getInt( "id" ));
					o.setTitre(resultat.getString( "titre" ));
					list.add(o);
				}
				
				
				return list;
			
		} catch (Exception ex) {
	    	ex.printStackTrace();
	    	return null;
	    }
	}
	
	public void deleteById(int id) {
		try {
			
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM actegorie WHERE id=?");
				preparedStatement.setInt(1,id);
				
				preparedStatement.executeUpdate();
				
				System.out.println("DELETED OK");
			
		} catch (Exception ex) {
	    	ex.printStackTrace();
	    	System.out.println("DELETED NO");
	    }
	}

	
	public int getCountProduitsById(int id) {
		try {
		
				PreparedStatement preparedStatement  = Database.connexion.
						prepareStatement("SELECT COUNT(*) as nbr FROM articles WHERE sous_sous_actegorie_id=?");
				preparedStatement.setInt(1,id);
				
				ResultSet resultat=preparedStatement.executeQuery();
				resultat.next();

				int nbr = resultat.getInt( "nbr" );
				return nbr;
			
		} catch (Exception ex) {
	    	ex.printStackTrace();
	    	return 0;
	    }
	}
	
	public static ArrayList<Actegorie> getAllFullTree() {
	    ArrayList<Actegorie> actegories = new ArrayList<>();
	    String sqlAct = "SELECT id, titre FROM actegorie";
	    String sqlSousAct = "SELECT id, titre FROM sous_actegorie WHERE actegorie_id = ?";
	    String sqlSousSousAct = "SELECT id, titre FROM sous_sous_actegorie WHERE sous_actegorie_id = ?";

	    try {
	        // Connection donnée par ta classe Database avec ton objet connexion statique
	        Connection conn = Database.connexion;

	        PreparedStatement psAct = conn.prepareStatement(sqlAct);
	        ResultSet rsAct = psAct.executeQuery();

	        while (rsAct.next()) {
	            Actegorie cat = new Actegorie();
	            cat.setId(rsAct.getInt("id"));
	            cat.setTitre(rsAct.getString("titre"));
	            cat.setSousActegories(new ArrayList<>());

	            PreparedStatement psSousAct = conn.prepareStatement(sqlSousAct);
	            psSousAct.setInt(1, cat.getId());
	            ResultSet rsSousAct = psSousAct.executeQuery();

	            while (rsSousAct.next()) {
	                Sous_actegorie sc = new Sous_actegorie();
	                sc.setId(rsSousAct.getInt("id"));
	                sc.setTitre(rsSousAct.getString("titre"));
	                sc.setActegorie_id(cat.getId());
	                sc.setSous_sous_Actegories(new ArrayList<>());

	                PreparedStatement psSousSousAct = conn.prepareStatement(sqlSousSousAct);
	                psSousSousAct.setInt(1, sc.getId());
	                ResultSet rsSousSousAct = psSousSousAct.executeQuery();

	                while (rsSousSousAct.next()) {
	                    Sous_sous_actegorie ssc = new Sous_sous_actegorie();
	                    ssc.setId(rsSousSousAct.getInt("id"));
	                    ssc.setTitre(rsSousSousAct.getString("titre"));
	                    ssc.setSous_actegorie_id(sc.getId());
	                    sc.getSous_sous_Actegories().add(ssc);
	                }
	                rsSousSousAct.close();
	                psSousSousAct.close();

	                cat.getSousActegories().add(sc);
	            }
	            rsSousAct.close();
	            psSousAct.close();

	            actegories.add(cat);
	        }

	        rsAct.close();
	        psAct.close();

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return actegories;
	}

}
	



	

