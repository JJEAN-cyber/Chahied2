package Models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class CommandeDAO {
	public int save(Commande obj) {
		int newid=0;
		try {

			if(obj.getId() != 0) {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("UPDATE commande set utilisateur_id=?,adresse_livraison=?,option_livraison=?,telephone=?,montant_total=?,date_commande=? WHERE id=?");
				preparedStatement.setInt(1,obj.getUtilisateur_id());
			
				preparedStatement.setString(2,obj.getAdresse_livraison());
				preparedStatement.setString(3,obj.getOption_livraison());
				preparedStatement.setString(4,obj.getTelephone());
				preparedStatement.setDouble(5,obj.getMontant_total());
				preparedStatement.setObject(6,obj.getDate_commande());
				preparedStatement.setInt(7,obj.getId());
				preparedStatement.executeUpdate();
				newid=obj.getUtilisateur_id();
			}else {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("INSERT INTO commande (utilisateur_id,adresse_livraison,option_livraison,telephone,montant_total,date_commande) VALUES(?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
				preparedStatement.setInt(1,obj.getUtilisateur_id());
				
				preparedStatement.setString(2,obj.getAdresse_livraison());
				preparedStatement.setString(3,obj.getOption_livraison());
				preparedStatement.setString(4,obj.getTelephone());
				preparedStatement.setDouble(5,obj.getMontant_total());
				preparedStatement.setTimestamp(6,Timestamp.valueOf(obj.getDate_commande()));
				preparedStatement.executeUpdate();

				ResultSet resultat = preparedStatement.getGeneratedKeys();
				resultat.next();
				newid= resultat.getInt(1) ;



			}
			System.out.println("SAVED OK");
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("SAVED NO");
		}
		return newid;

	}

	public Commande getById(int id) {
		try {
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM commande WHERE id=?");
			preparedStatement.setInt(1,id);

			ResultSet resultat=preparedStatement.executeQuery();

			Commande u = new Commande();
			while(resultat.next()) {
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt( "utilisateur_id" ));
				
				u.setAdresse_livraison(resultat.getString( "adresse_livraison" ));
				u.setOption_livraison(resultat.getString( "option_livraison" ));
				u.setTelephone(resultat.getString( "telephone" ));
				u.setMontant_total(resultat.getDouble( "montant_total" ));
				u.setDate_commande(resultat.getTimestamp("date_commande").toLocalDateTime());
			}
			return u;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}


	public ArrayList<Commande> getAll() {
		ArrayList<Commande> list = new ArrayList<Commande>();
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM commande");

			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Commande u = new Commande();
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt( "utilisateur_id" ));
				
				u.setAdresse_livraison(resultat.getString( "adresse_livraison" ));
				u.setOption_livraison(resultat.getString( "option_livraison" ));
				u.setTelephone(resultat.getString( "telephone" ));
				u.setMontant_total(resultat.getDouble( "montant_total" ));
				u.setDate_commande(resultat.getTimestamp("date_commande").toLocalDateTime());
				list.add(u);
			}


			return list;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public ArrayList<Commande> getAllByUtilisateur(int utilisateur_id) {
		ArrayList<Commande> list = new ArrayList<Commande>();
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM commande WHERE utilisateur_id=?");
			preparedStatement.setInt(1,utilisateur_id);
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Commande u = new Commande();
				u.setId(resultat.getInt( "id" ));
				u.setUtilisateur_id(resultat.getInt( "utilisateur_id" ));
				
				u.setAdresse_livraison(resultat.getString( "adresse_livraison" ));
				u.setOption_livraison(resultat.getString( "option_livraison" ));
				u.setTelephone(resultat.getString( "telephone" ));
				u.setMontant_total(resultat.getDouble( "montant_total" ));
				u.setDate_commande(resultat.getTimestamp("date_commande").toLocalDateTime());
				list.add(u);
			}


			return list;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}




	public void deleteById(int id) {


		try {

			PreparedStatement preparedStatement2  = Database.connexion.prepareStatement("DELETE FROM resume_commande WHERE commande_id=?");
			preparedStatement2.setInt(1,id);

			preparedStatement2.executeUpdate();

			System.out.println("DELETED OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("DELETED NO");
		}
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM commande WHERE id=?");
			preparedStatement.setInt(1,id);

			preparedStatement.executeUpdate();

			System.out.println("DELETED OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("DELETED NO");
		}
	}	


}
