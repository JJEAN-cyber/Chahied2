package Models;

import java.time.LocalDateTime;

public class Conversation {
	private int id;
	private int participant1_id;
	private int participant2_id;
	private String last_message_snippet;
	private LocalDateTime last_updated;
	private int article_id;
	private String article_nom;
	private String participant1_nom;
	private String participant2_nom;

	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getParticipant1_id() {
		return participant1_id;
	}
	public void setParticipant1_id(int participant1_id) {
		this.participant1_id = participant1_id;
	}
	public int getParticipant2_id() {
		return participant2_id;
	}
	public void setParticipant2_id(int participant2_id) {
		this.participant2_id = participant2_id;
	}
	public String getLast_message_snippet() {
		return last_message_snippet;
	}
	public void setLast_message_snippet(String last_message_snippet) {
		this.last_message_snippet = last_message_snippet;
	}
	public LocalDateTime getLast_updated() {
		return last_updated;
	}
	public void setLast_updated(LocalDateTime last_updated) {
		this.last_updated = last_updated;
	}
	
	
	public int getArticle_id() {
		return article_id;
	}
	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}
	
	
	public String getArticle_nom() {
		return article_nom;
	}
	public void setArticle_nom(String article_nom) {
		this.article_nom = article_nom;
	}
	
	public String getParticipant1_nom() {
		return participant1_nom;
	}
	public void setParticipant1_nom(String participant1_nom) {
		this.participant1_nom = participant1_nom;
	}
	public String getParticipant2_nom() {
		return participant2_nom;
	}
	public void setParticipant2_nom(String participant2_nom) {
		this.participant2_nom = participant2_nom;
	}
	public Conversation() {
		super();
	}
	public Conversation(int id, int participant1_id, int participant2_id, String last_message_snippet,
			LocalDateTime last_updated, int article_id, String article_nom, String participant1_nom,
			String participant2_nom) {
		super();
		this.id = id;
		this.participant1_id = participant1_id;
		this.participant2_id = participant2_id;
		this.last_message_snippet = last_message_snippet;
		this.last_updated = last_updated;
		this.article_id = article_id;
		this.article_nom = article_nom;
		this.participant1_nom = participant1_nom;
		this.participant2_nom = participant2_nom;
	}
	public Conversation(int participant1_id, int participant2_id, String last_message_snippet,
			LocalDateTime last_updated, int article_id, String article_nom, String participant1_nom,
			String participant2_nom) {
		super();
		this.participant1_id = participant1_id;
		this.participant2_id = participant2_id;
		this.last_message_snippet = last_message_snippet;
		this.last_updated = last_updated;
		this.article_id = article_id;
		this.article_nom = article_nom;
		this.participant1_nom = participant1_nom;
		this.participant2_nom = participant2_nom;
	}
	
}
