package Models;

import java.util.ArrayList;

public class Sous_categorie {
	private int id;
	private String titre;
	private int categorie_id;
	private ArrayList<Sous_sous_categorie> sous_sous_Categories;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public int getCategorie_id() {
		return categorie_id;
	}
	public void setCategorie_id(int categorie_id) {
		this.categorie_id = categorie_id;
	}
		
	public ArrayList<Sous_sous_categorie> getSous_sous_Categories() {
		return sous_sous_Categories;
	}
	public void setSous_sous_Categories(ArrayList<Sous_sous_categorie> sous_sous_Categories) {
		this.sous_sous_Categories = sous_sous_Categories;
	}
	public Sous_categorie() {
		super();
	}
	public Sous_categorie(String titre, int categorie_id) {
		super();
		this.titre = titre;
		this.categorie_id = categorie_id;
	}
	public Sous_categorie(int id, String titre, int categorie_id) {
		super();
		this.id = id;
		this.titre = titre;
		this.categorie_id = categorie_id;
	}
	
	
}
