package Models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;

public class OffreDAO {		    
	public int save(Offre obj) {
		int newid=0;
					try {
						
						if(obj.getId() != 0) {
							PreparedStatement preparedStatement  = Database.connexion.prepareStatement("UPDATE offre set utilisateur_id=?,article_id=?,montant_offre=?,date_offre=?,statut=? WHERE id=?");
							preparedStatement.setInt(1,obj.getUtilisateur_id());
							preparedStatement.setInt(2,obj.getArticle_id());
							preparedStatement.setDouble(3,obj.getMontant_offre());
							preparedStatement.setTimestamp(4,Timestamp.valueOf(obj.getDate_offre()));
							preparedStatement.setString(5,obj.getStatut());
							preparedStatement.setInt(6,obj.getId());
				            preparedStatement.executeUpdate();
				            newid=obj.getUtilisateur_id();
						}else {
							PreparedStatement preparedStatement  = Database.connexion.prepareStatement("INSERT INTO offre (utilisateur_id,article_id,montant_offre,date_offre,statut) VALUES(?,?,?,now(),?)", Statement.RETURN_GENERATED_KEYS);
							preparedStatement.setInt(1,obj.getUtilisateur_id());
							preparedStatement.setInt(2,obj.getArticle_id());
							preparedStatement.setDouble(3,obj.getMontant_offre());
							preparedStatement.setTimestamp(4,Timestamp.valueOf(obj.getDate_offre()));
							preparedStatement.setString(5,obj.getStatut());
				            preparedStatement.executeUpdate();
				            
				            ResultSet resultat = preparedStatement.getGeneratedKeys();
				            resultat.next();
				            newid= resultat.getInt(1) ;
				            
				            
				            
						}
						System.out.println("SAVED OK");
					} catch (Exception ex) {
			        	ex.printStackTrace();
			        	System.out.println("SAVED NO");
			        }
					return newid;
				
			}
			
			public Offre getById(int id) {
				try {
					PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM offre WHERE id=?");
						preparedStatement.setInt(1,id);
						
						ResultSet resultat=preparedStatement.executeQuery();
						
						Offre u = new Offre();
						while(resultat.next()) {
							u.setId(resultat.getInt( "id" ));
							u.setUtilisateur_id(resultat.getInt( "utilisateur_id" ));
							u.setArticle_id(resultat.getInt( "article_id" ));
							u.setMontant_offre(resultat.getDouble( "montant_offre" ));
							u.setDate_offre(resultat.getTimestamp( "date_offre" ).toLocalDateTime());
							u.setStatut(resultat.getString( "statut" ));
						}
						return u;
					
				} catch (Exception ex) {
			    	ex.printStackTrace();
			    	return null;
			    }
			}
			
			
			public ArrayList<Offre> getAll() {
				ArrayList<Offre> list = new ArrayList<Offre>();
				try {
					
						PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM offre");
						
						ResultSet resultat=preparedStatement.executeQuery();
			
						while(resultat.next()) {
							Offre u = new Offre();
							u.setId(resultat.getInt( "id" ));
							u.setUtilisateur_id(resultat.getInt( "utilisateur_id" ));
							u.setArticle_id(resultat.getInt( "article_id" ));
							u.setMontant_offre(resultat.getDouble( "montant_offre" ));
							u.setDate_offre(resultat.getTimestamp( "date_offre" ).toLocalDateTime());
							u.setStatut(resultat.getString( "statut" ));
							list.add(u);
						}
						
						
						return list;
					
				} catch (Exception ex) {
			    	ex.printStackTrace();
			    	return null;
			    }
			}
			
			public ArrayList<Offre> getAllByUtilisateur(int utilisateur_id) {
				ArrayList<Offre> list = new ArrayList<Offre>();
				try {
					
						PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM offre WHERE utilisateur_id=?");
						preparedStatement.setInt(1,utilisateur_id);
						ResultSet resultat=preparedStatement.executeQuery();
			
						while(resultat.next()) {
							Offre u = new Offre();
							u.setId(resultat.getInt( "id" ));
							u.setUtilisateur_id(resultat.getInt( "utilisateur_id" ));
							u.setArticle_id(resultat.getInt( "article_id" ));
							u.setMontant_offre(resultat.getDouble( "montant_offre" ));
							u.setDate_offre(resultat.getTimestamp( "date_offre" ).toLocalDateTime());
							u.setStatut(resultat.getString( "statut" ));
							list.add(u);
						}
						
						
						return list;
					
				} catch (Exception ex) {
			    	ex.printStackTrace();
			    	return null;
			    }
			}
			
			

			
			public void deleteById(int id) {
				
				try {
					
						PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM offre WHERE id=?");
						preparedStatement.setInt(1,id);
						
						preparedStatement.executeUpdate();
						
						System.out.println("DELETED OK");
					
				} catch (Exception ex) {
			    	ex.printStackTrace();
			    	System.out.println("DELETED NO");
			    }
			}	
			
			

			


			public void passerEnValide(int id) {
			    try {
			        // Préparation de la requête SQL pour mettre à jour l'état de l'offre
			        String sql = "UPDATE offre SET statut = 'validée' WHERE id = ? AND etat = 'en attente'";
			        PreparedStatement preparedStatement = Database.connexion.prepareStatement(sql);
			        
			        // Définir l'ID de l'offre à mettre à jour
			        preparedStatement.setInt(1, id);
			        
			        // Exécuter la mise à jour
			        int rowsAffected = preparedStatement.executeUpdate();
			        
			        // Vérification du résultat de la mise à jour
			        if (rowsAffected > 0) {
			            System.out.println("Offre validée avec succès.");
			        } else {
			            System.out.println("Aucune offre n'a été validée. Vérifiez que l'état est bien 'en attente'.");
			        }
			    } catch (SQLException e) {
			        e.printStackTrace(); // Gestion des exceptions SQL
			    }
			}
			
			public void refuserOffre(int id) {
			    try {
			        // Préparation de la requête SQL pour refuser l'offre
			        String sql = "UPDATE offre SET statut = 'refusée' WHERE id = ? AND etat = 'en attente'";
			        PreparedStatement preparedStatement = Database.connexion.prepareStatement(sql);
			        
			        // Définir l'ID de l'offre à mettre à jour
			        preparedStatement.setInt(1, id);
			        
			        // Exécuter la mise à jour
			        int rowsAffected = preparedStatement.executeUpdate();
			        
			        // Vérification du résultat de la mise à jour
			        if (rowsAffected > 0) {
			            System.out.println("Offre refusée avec succès.");
			        } else {
			            System.out.println("Aucune offre n'a été refusée. Vérifiez que l'état est bien 'en attente'.");
			        }
			    } catch (SQLException e) {
			        e.printStackTrace(); // Gestion des exceptions SQL
			    }
			}

}
