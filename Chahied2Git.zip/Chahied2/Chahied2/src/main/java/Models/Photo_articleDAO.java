package Models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Photo_articleDAO {
public void save(Photo_article obj) {
		
		try {
			
			if(obj.getId() != 0) {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("UPDATE photo_article set article_id=?,chemin_fichier=? WHERE id=?");
				preparedStatement.setInt(1,obj.getArticle_id());
				preparedStatement.setString(2,obj.getChemin_fichier());				
				preparedStatement.setInt(3,obj.getId());
	            preparedStatement.executeUpdate();
			}else {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("INSERT INTO photo_article (article_id,chemin_fichier) VALUES(?,?)");
				preparedStatement.setInt(1,obj.getArticle_id());
				preparedStatement.setString(2,obj.getChemin_fichier());				
	            preparedStatement.executeUpdate();
			}
			System.out.println("SAVED OK");
			
		} catch (Exception ex) {
        	ex.printStackTrace();
        	System.out.println("SAVED NO");
        }
	
}
public ArrayList<Photo_article> getAll() {
	ArrayList<Photo_article> list = new ArrayList<Photo_article>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM photo_article");
			
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Photo_article u = new Photo_article();
				u.setId(resultat.getInt( "id" ));
				u.setArticle_id(resultat.getInt( "article_id" ));
				u.setChemin_fichier(resultat.getString( "chemin_fichier" ));
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}

public ArrayList<Photo_article> getAllByArt(int article_id) {
	ArrayList<Photo_article> list = new ArrayList<Photo_article>();
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT chemin_fichier FROM photo_article WHERE article_id=? LIMIT 1");
			preparedStatement.setInt(1, article_id);
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Photo_article u = new Photo_article();
				
				u.setChemin_fichier(resultat.getString( "chemin_fichier" ));
				list.add(u);
			}
			
			
			return list;
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	return null;
    }
}
public String getPhotosByIdArt(int id) {
    StringBuilder chemins = new StringBuilder();
    try {
        PreparedStatement preparedStatement = Database.connexion.prepareStatement(
            "SELECT chemin_fichier FROM photo_article WHERE article_id=?"
        );
        preparedStatement.setInt(1, id);
        
        ResultSet resultat = preparedStatement.executeQuery();

        while (resultat.next()) {
            if (chemins.length() > 0) {
                chemins.append(","); // Séparateur entre les chemins (utile si plusieurs images)
            }
            chemins.append(resultat.getString("chemin_fichier"));
        }

        resultat.close();
        preparedStatement.close();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return chemins.toString(); // Retourne tous les chemins séparés par une virgule
}

public void deleteById(int id) {
	try {
		
			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM photo_article WHERE id=?");
			preparedStatement.setInt(1,id);
			
			preparedStatement.executeUpdate();
			
			System.out.println("DELETED OK");
		
	} catch (Exception ex) {
    	ex.printStackTrace();
    	System.out.println("DELETED NO");
    }
}
public ArrayList<Photo_article> getAllByArts(int article_id) {
    ArrayList<Photo_article> list = new ArrayList<>();
    String sql = "SELECT id, article_id, chemin_fichier FROM photo_article WHERE article_id = ? LIMIT 1";
    try (PreparedStatement preparedStatement = Database.connexion.prepareStatement(sql)) {
        preparedStatement.setInt(1, article_id);
        ResultSet resultat = preparedStatement.executeQuery();

        while (resultat.next()) {
            Photo_article photo = new Photo_article();
            photo.setId(resultat.getInt("id"));
            photo.setArticle_id(resultat.getInt("article_id"));
            photo.setChemin_fichier(resultat.getString("chemin_fichier"));
            list.add(photo);
        }
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return list;
}

}
