package Models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Sous_sous_actegorieDAO {
	public void save(Sous_sous_actegorie obj) {

		try {

			if(obj.getId() != 0) {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("UPDATE sous_sous_actegorie set titre=?, sous_actegorie_id=? WHERE id=?");
				preparedStatement.setString(1,obj.getTitre());
				preparedStatement.setInt(2,obj.getSous_actegorie_id());
				preparedStatement.setInt(3,obj.getId());
				preparedStatement.executeUpdate();
			}else {
				PreparedStatement preparedStatement  = Database.connexion.prepareStatement("INSERT INTO sous_sous_actegorie (titre,sous_actegorie_id) VALUES(?,?)");
				preparedStatement.setString(1,obj.getTitre());
				preparedStatement.setInt(2,obj.getSous_actegorie_id());

				preparedStatement.executeUpdate();
			}
			System.out.println("SAVED OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("SAVED NO");
		}

	}

	public Sous_sous_actegorie getById(int id) {
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM sous_sous_actegorie WHERE id=?");
			preparedStatement.setInt(1,id);

			ResultSet resultat=preparedStatement.executeQuery();

			Sous_sous_actegorie u = new Sous_sous_actegorie();
			while(resultat.next()) {
				u.setId(resultat.getInt( "id" ));
				u.setTitre(resultat.getString( "titre" ));
				u.setSous_actegorie_id(resultat.getInt( "sous_actegorie_id" ));
			}
			return u;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
	public int getCountArticlesByIdSSX2_Act(int id) {
		try {

			PreparedStatement preparedStatement  = Database.connexion.
					prepareStatement("SELECT COUNT(*) as nbr FROM articles WHERE sous_sous_actegorie_id=?");
			preparedStatement.setInt(1,id);

			ResultSet resultat=preparedStatement.executeQuery();
			resultat.next();

			int nbr = resultat.getInt( "nbr" );
			return nbr;

		} catch (Exception ex) {
			ex.printStackTrace();
			return 0;
		}
	}
	public ArrayList<Sous_sous_actegorie> RechercherS2ACT(String mot) {
		ArrayList<Sous_sous_actegorie> list = new ArrayList<Sous_sous_actegorie>();
		try {

			PreparedStatement preparedStatement  = Database.connexion
					.prepareStatement("SELECT * FROM sous_sous_actegorie WHERE titre like ?");
			preparedStatement.setString(1,"%"+mot+"%");
			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Sous_sous_actegorie u = new Sous_sous_actegorie();
				u.setId(resultat.getInt( "id" ));
				u.setTitre(resultat.getString( "titre" ));
				u.setSous_actegorie_id(resultat.getInt( "sous_actegorie_id " ));
				list.add(u);
			}
			return list;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public ArrayList<Sous_sous_actegorie> getAllBySact(int id){
		ArrayList<Sous_sous_actegorie> list = new ArrayList<Sous_sous_actegorie>();
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM sous_sous_actegorie WHERE sous_actegorie_id=?");
			preparedStatement.setInt(1,id);

			ResultSet resultat=preparedStatement.executeQuery();


			while(resultat.next()) {
				Sous_sous_actegorie u = new Sous_sous_actegorie();
				u.setId(resultat.getInt( "id" ));
				u.setTitre(resultat.getString( "titre" ));
				u.setSous_actegorie_id(resultat.getInt( "sous_actegorie_id" ));
				list.add(u);
			}
			return list;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public ArrayList<Sous_sous_actegorie> getAll() {
		ArrayList<Sous_sous_actegorie> list = new ArrayList<Sous_sous_actegorie>();
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("SELECT * FROM sous_sous_actegorie");

			ResultSet resultat=preparedStatement.executeQuery();

			while(resultat.next()) {
				Sous_sous_actegorie o = new Sous_sous_actegorie();
				o.setId(resultat.getInt( "id" ));
				o.setTitre(resultat.getString( "titre" ));
				list.add(o);
			}


			return list;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public int getCountProduitsById(int id) {
		try {

			PreparedStatement preparedStatement  = Database.connexion.
					prepareStatement("SELECT COUNT(*) as nbr FROM articles WHERE sous_sous_actegorie_id=?");
			preparedStatement.setInt(1,id);

			ResultSet resultat=preparedStatement.executeQuery();
			resultat.next();

			int nbr = resultat.getInt( "nbr" );
			return nbr;

		} catch (Exception ex) {
			ex.printStackTrace();
			return 0;
		}
	}
	public void deleteById(int id) {
		try {

			PreparedStatement preparedStatement  = Database.connexion.prepareStatement("DELETE FROM sous_sous_actegorie WHERE id=?");
			preparedStatement.setInt(1,id);

			preparedStatement.executeUpdate();

			System.out.println("DELETED OK");

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("DELETED NO");
		}
	}


}






