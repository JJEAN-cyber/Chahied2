package Models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Trace_connexion_userDAO {
	public void insertConnexion(Trace_connexion_user obj) {
		try{
		PreparedStatement preparedStatement = Database.connexion.prepareStatement("INSERT INTO trace_connexion_user (user_id,user_ip,browser,login_date) VALUES (?,?,?,now())");
		preparedStatement.setInt(1,obj.getUser_id());
		preparedStatement.setString(2,obj.getUser_ip());
		preparedStatement.setString(3,obj.getBrowser());
		
		preparedStatement.executeUpdate();
	
	System.out.println("SAVED OK");
	
} catch (Exception ex) {
	ex.printStackTrace();
	System.out.println("SAVED NO");
}



	}
	public ArrayList<Trace_connexion_user>getAll(){
		ArrayList<Trace_connexion_user> list = new ArrayList<Trace_connexion_user>();
		try {
			PreparedStatement preparedStatement = Database.connexion.prepareStatement("SELECT * FROM trace_connexion_user ORDER BY login_date DESC");
			ResultSet resultat = preparedStatement.executeQuery();
			while(resultat.next()) {
			Trace_connexion_user tcu = new Trace_connexion_user();
			tcu.setId(resultat.getInt("id"));
			tcu.setUser_id(resultat.getInt("user_id"));
			tcu.setUser_ip(resultat.getString("user_ip"));
			tcu.setBrowser(resultat.getString("browser"));
			tcu.setLogin_date(resultat.getTimestamp("login_date"));
			list.add(tcu);
			}
			return list;
			
			} catch (Exception ex) {
		    	ex.printStackTrace();
		    	return null;
		    }
			
		}
	}



