package Models;

public class Sous_sous_categorie {
	private int id;
	private String titre;
	private int sous_categorie_id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public int getSous_categorie_id() {
		return sous_categorie_id;
	}
	public void setSous_categorie_id(int sous_categorie_id) {
		this.sous_categorie_id = sous_categorie_id;
	}
	public Sous_sous_categorie() {
		super();
	}
	public Sous_sous_categorie(String titre, int sous_categorie_id) {
		super();
		this.titre = titre;
		this.sous_categorie_id = sous_categorie_id;
	}
	public Sous_sous_categorie(int id, String titre, int sous_categorie_id) {
		super();
		this.id = id;
		this.titre = titre;
		this.sous_categorie_id = sous_categorie_id;
	}
	
	
}
