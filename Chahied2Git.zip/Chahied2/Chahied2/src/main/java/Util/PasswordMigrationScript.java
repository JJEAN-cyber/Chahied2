package Util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Models.Database;

public class PasswordMigrationScript {

    public static void main(String[] args) {
        // 1. Ouvre la connexion à la base
        Database.Connect();
        Connection conn = Database.connexion;

        if (conn == null) {
            System.err.println("Impossible d'obtenir une connexion à la base de données !");
            return;
        }

        try {
            System.out.println("Connexion à la base de données réussie.");

            // 2. Sélectionner tous les utilisateurs
            String selectSql = "SELECT id_utilisateur, mot_de_passe FROM utilisateur";
            String updateSql = "UPDATE utilisateur SET mot_de_passe = ? WHERE id_utilisateur = ?";

            try (Statement selectStmt = conn.createStatement();
                 ResultSet rs = selectStmt.executeQuery(selectSql);
                 PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {

                conn.setAutoCommit(false);

                while (rs.next()) {
                    long userId = rs.getLong("id_utilisateur");
                    String currentPassword = rs.getString("mot_de_passe");

                    // 3. Vérifier le format du mot de passe
                    if (currentPassword == null || currentPassword.startsWith("$2a$")) {
                        System.out.println("L'utilisateur " + userId + " a déjà un mot de passe haché. Ignoré.");
                        continue;
                    }

                    // 4. Hachage avec PasswordHasher (package util)
                    String hashedPassword = PasswordHasher.hash(currentPassword);
                    System.out.println("Hachage du mot de passe pour l'utilisateur : " + userId);

                    // 5. Préparer la mise à jour
                    updateStmt.setString(1, hashedPassword);
                    updateStmt.setLong(2, userId);
                    updateStmt.addBatch();
                }

                updateStmt.executeBatch();
                conn.commit();
                System.out.println("Migration des mots de passe terminée avec succès.");
            }
        } catch (SQLException e) {
            System.err.println("Erreur de base de données : " + e.getMessage());
            e.printStackTrace();
        } finally {
            // 6. On ferme la connexion proprement
            Database.closeConnection();
        }
    }
}
