package Util;

import org.mindrot.jbcrypt.BCrypt;

/**
 * Classe utilitaire pour le hachage et la vérification des mots de passe.
 * Utilise l'algorithme BCrypt.
 */
public class PasswordHasher {
    // Coût de hachage (plus la valeur est élevée, plus c'est sécurisé, mais plus c'est lent)
    private static final int HASHING_ROUNDS = 12;

    /**
     * Hache un mot de passe en clair.
     * @param password Le mot de passe en clair.
     * @return Le mot de passe haché.
     */
    public static String hash(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt(HASHING_ROUNDS));
    }

    /**
     * Vérifie si un mot de passe en clair correspond à un mot de passe haché.
     * @param password Le mot de passe en clair à vérifier.
     * @param hashedPassword Le mot de passe haché stocké.
     * @return Vrai si les mots de passe correspondent, sinon Faux.
     */
    public static boolean verify(String password, String hashedPassword) {
        return BCrypt.checkpw(password, hashedPassword);
    }
}
