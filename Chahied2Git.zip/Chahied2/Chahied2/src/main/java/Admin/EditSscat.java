package Admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.Database;
import Models.Sous_categorie;
import Models.Sous_categorieDAO;
import Models.Sous_sous_categorie;
import Models.Sous_sous_categorieDAO;

/**
 * Servlet implementation class EditSscat
 */
@WebServlet("/EditSscat")
public class EditSscat extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EditSscat() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");



		Database.Connect();
		String idParam = request.getParameter("id");
		if (idParam != null && !idParam.trim().isEmpty()) {
			try {
				int sscatid = Integer.parseInt(idParam);
				Sous_sous_categorie ssc = new Sous_sous_categorieDAO().getById(sscatid);
				if (ssc != null) {
					request.setAttribute("sscat", ssc);
					if (request.getParameter("titre") != null) {
						ssc.setTitre(request.getParameter("titre"));
						new Sous_sous_categorieDAO().save(ssc);
						response.sendRedirect("Categories_admin_aj");
						return; // Arrête ici après redirection
					} else {
						request.getRequestDispatcher("editSscat.jsp").forward(request, response);
						return; // Arrête après forward
					}
				} else {
					response.sendError(HttpServletResponse.SC_NOT_FOUND, "Sous-sous-catégorie introuvable");
				}
			} catch (NumberFormatException e) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID invalide");
			}
		} else {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Paramètre id manquant");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");



		Database.Connect();
		String idParam = request.getParameter("id");
		if (idParam != null && !idParam.trim().isEmpty()) {
			try {
				int sscatid = Integer.parseInt(idParam);
				Sous_sous_categorie ssc = new Sous_sous_categorieDAO().getById(sscatid);
				if (ssc != null) {
					request.setAttribute("sscat", ssc);
					if (request.getParameter("titre") != null) {
						ssc.setTitre(request.getParameter("titre"));
						new Sous_sous_categorieDAO().save(ssc);
						response.sendRedirect("Categories_admin_aj");
						return; // Arrête ici après redirection
					} else {
						request.getRequestDispatcher("editSscat.jsp").forward(request, response);
						return; // Arrête après forward
					}
				} else {
					response.sendError(HttpServletResponse.SC_NOT_FOUND, "Sous-sous-catégorie introuvable");
				}
			} catch (NumberFormatException e) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID invalide");
			}
		} else {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Paramètre id manquant");
		}
	}

}
