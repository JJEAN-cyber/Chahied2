package Admin;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.Actegorie;
import Models.ActegorieDAO;
import Models.Categorie;
import Models.CategorieDAO;
import Models.Database;
import Models.Sous_sous_actegorie;
import Models.Sous_sous_actegorieDAO;
import Models.Sous_sous_categorie;
import Models.Sous_sous_categorieDAO;

/**
 * Servlet implementation class Admini
 */
@WebServlet("/Admini")
public class Admini extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Admini() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				Database.Connect();
				
				/*
				 * ArrayList<Recherches> colrecherches = new RechercheDAO().getAll();
				 * request.setAttribute("colrecherches", colrecherches);
				 */
				Sous_sous_categorieDAO catdao = new Sous_sous_categorieDAO();		
				ArrayList<Sous_sous_categorie>cats=catdao.getAll();		
				request.setAttribute("cats", cats);	
				
				Sous_sous_actegorieDAO platdao = new Sous_sous_actegorieDAO();		
				ArrayList<Sous_sous_actegorie>plats=platdao.getAll();		
				request.setAttribute("plats", plats);
				
				  ArrayList<Integer> nbProds = new ArrayList<>();
		          for (Sous_sous_categorie cat : cats) {
		              int count = catdao.getCountProduitsById(cat.getId());
		              nbProds.add(count);
		          }
		          ArrayList<Integer> nbProds2 = new ArrayList<>();
		          for (Sous_sous_actegorie plat : plats) {
		              int count = platdao.getCountProduitsById(plat.getId());
		              nbProds2.add(count);
		          }
		          
		          request.setAttribute("nbProds", nbProds);
		        
		          request.setAttribute("nbProds2", nbProds2);

		         
			
				request.getRequestDispatcher("admin.jsp").forward(request, response);
			}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
