package Admin;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.Actegorie;
import Models.ActegorieDAO;

import Models.Database;
import Models.Sous_actegorie;
import Models.Sous_actegorieDAO;

import Models.Sous_sous_actegorie;
import Models.Sous_sous_actegorieDAO;


/**
 * Servlet implementation class Actegories_admin_aj
 */
@WebServlet("/Actegories_admin_aj")
public class Actegories_admin_aj extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Actegories_admin_aj() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 Database.Connect();
		    
		 ArrayList<Actegorie> acts = new ActegorieDAO().getAll();
			request.setAttribute("acts", acts);
			
			if(request.getParameter("del")!=null) {
				int actid = Integer.parseInt(request.getParameter("del"));
				new ActegorieDAO().deleteById(actid);
				response.sendRedirect("Actegories_admin_aj");
				return;
			}
			if(request.getParameter("delsa")!=null) {
				int sactid = Integer.parseInt(request.getParameter("delsa"));
				new Sous_actegorieDAO().deleteById(sactid);
				response.sendRedirect("Actegories_admin_aj");
				return;
			}
			if(request.getParameter("delssa")!=null) {
				int ssactid = Integer.parseInt(request.getParameter("delssa"));
				new Sous_sous_actegorieDAO().deleteById(ssactid);
				response.sendRedirect("Actegories_admin_aj");
				return;
			}
			
		// Charger l'arborescence complète
	        ArrayList<Actegorie> actegories = ActegorieDAO.getAllFullTree();
	        request.setAttribute("actegories", actegories);
	        request.getRequestDispatcher("/act_adm_aj.jsp").forward(request, response);
	    }

	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	    	String action = request.getParameter("action");

	        if ("addActegorie".equals(action)) {
	            // Créer un objet Categorie avec le titre fourni
	            Actegorie cat = new Actegorie();
	            cat.setTitre(request.getParameter("titre_actegorie"));

	            // Appeler la méthode save (non statique) sur DAO
	            new ActegorieDAO().save(cat);

	            request.setAttribute("result", "Actégorie ajoutée !");
	        } 
	        else if ("addSousActegorie".equals(action)) {
	            Sous_actegorie scat = new Sous_actegorie();
	            scat.setTitre(request.getParameter("titre_sous_actegorie"));
	            
	            // Récupération de l'id de la catégorie parente
	            int actId = Integer.parseInt(request.getParameter("actegorie_id"));
	            scat.setActegorie_id(actId);

	            // Appeler la méthode save sur SousCategorieDAO
	            new Sous_actegorieDAO().save(scat);

	            request.setAttribute("result", "Sous-actégorie ajoutée !");
	        } 
	        else if ("addSousSousActegorie".equals(action)) {
	            Sous_sous_actegorie ssact = new Sous_sous_actegorie();
	            ssact.setTitre(request.getParameter("titre_sous_sous_actegorie"));

	            int sousActId = Integer.parseInt(request.getParameter("sous_actegorie_id"));
	            ssact.setSous_actegorie_id(sousActId);

	            new Sous_sous_actegorieDAO().save(ssact);

	            request.setAttribute("result", "Sous-sous-actégorie ajoutée !");
	        }

	        // Réaffiche la page (avec message ou arborescence mise à jour)
	        doGet(request, response);
	    }
}