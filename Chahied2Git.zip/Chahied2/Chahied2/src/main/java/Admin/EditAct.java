package Admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.Actegorie;
import Models.ActegorieDAO;
import Models.Categorie;
import Models.CategorieDAO;
import Models.Database;

/**
 * Servlet implementation class EditAct
 */
@WebServlet("/EditAct")
public class EditAct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditAct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Database.Connect();
		int actid = Integer.parseInt(request.getParameter("id"));
		Actegorie c = new ActegorieDAO().getById(actid);
		request.setAttribute("act", c);
		
		if(request.getParameter("titre")!=null) {
			c.setTitre(request.getParameter("titre"));
			new ActegorieDAO().save(c);
			response.sendRedirect("Actegories_admin_aj");
		}else {
			request.getRequestDispatcher("editAct.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
