package Admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.Categorie;
import Models.CategorieDAO;
import Models.Database;

/**
 * Servlet implementation class EditCat
 */
@WebServlet("/EditCat")
public class EditCat extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditCat() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Database.Connect();
		int catid = Integer.parseInt(request.getParameter("id"));
		Categorie c = new CategorieDAO().getById(catid);
		request.setAttribute("cat", c);
		
		if(request.getParameter("titre")!=null) {
			c.setTitre(request.getParameter("titre"));
			new CategorieDAO().save(c);
			response.sendRedirect("Categories_admin_aj");
		}else {
			request.getRequestDispatcher("editCat.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
