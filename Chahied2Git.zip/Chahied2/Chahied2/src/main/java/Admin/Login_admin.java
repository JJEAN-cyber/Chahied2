package Admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.Administrateur;
import Models.AdministrateurDAO;
import Models.Database;

/**
 * Servlet implementation class Login_admin
 */
@WebServlet("/Login_admin")
public class Login_admin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login_admin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Database.Connect();
		boolean connected=false;
		boolean messageconnexionno=false;
		if(request.getParameter("dconnexion")!=null) {
			String email=request.getParameter("demail");
			String password=request.getParameter("dpassword");
			
			AdministrateurDAO utilisateurdao= new AdministrateurDAO();
			Administrateur u= utilisateurdao.connexion(email, password);
			if(u==null) {
				System.out.println("CONNEXION NO");
				messageconnexionno=true;
			}else {
				System.out.println("CONNEXION OK");
				HttpSession session = request.getSession(true);
				session.setAttribute("adminid", u.getId());
				session.setAttribute("adminnom", u.getNom());
				connected=true;
				response.sendRedirect("Admini");
				
			}
			
		}
		request.setAttribute("messageconnexionno", messageconnexionno);
		if(connected==false) {
			request.getRequestDispatcher("/connexion2.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
