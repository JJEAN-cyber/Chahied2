package Admin;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.Database;
import Models.Utilisateur;
import Models.UtilisateurDAO;

/**
 * Servlet implementation class GestionUtil
 */
@WebServlet("/GestionUtil")
public class GestionUtil extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GestionUtil() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Database.Connect();

		 ArrayList<Utilisateur> uti = new UtilisateurDAO().getAll();
		    request.setAttribute("uti", uti);

		    if (request.getParameter("ban") != null) {
		        int banid = Integer.parseInt(request.getParameter("ban"));
		        new UtilisateurDAO().banUser(banid);
		        response.sendRedirect("GestionUtil");
		        return;  // Pour s'assurer que la méthode se termine après la redirection.
		    }

		    if (request.getParameter("del") != null) {
		        int delid = Integer.parseInt(request.getParameter("del"));
		        new UtilisateurDAO().deleteById(delid);
		        response.sendRedirect("GestionUtil");
		        return;  // Pour s'assurer que la méthode se termine après la redirection.
		    }

		    // Dispatcher si aucun paramètre 'ban' ou 'del' n'est présent.
		    request.getRequestDispatcher("gestionUtil.jsp").forward(request, response);
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
