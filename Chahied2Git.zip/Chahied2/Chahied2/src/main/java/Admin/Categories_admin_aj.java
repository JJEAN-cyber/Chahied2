package Admin;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.Categorie;
import Models.CategorieDAO;
import Models.Database;
import Models.Sous_categorie;
import Models.Sous_categorieDAO;
import Models.Sous_sous_categorie;
import Models.Sous_sous_categorieDAO;

/**
 * Servlet implementation class Categories_admin_aj
 */
@WebServlet("/Categories_admin_aj")
public class Categories_admin_aj extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Categories_admin_aj() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 Database.Connect();
		    
		 ArrayList<Categorie> cats = new CategorieDAO().getAll();
			request.setAttribute("cats", cats);
			if(request.getParameter("del")!=null) {
				int catid = Integer.parseInt(request.getParameter("del"));
				new CategorieDAO().deleteById(catid);
				response.sendRedirect("Categories_admin_aj");
				return;
			}
			if(request.getParameter("delsc")!=null) {
				int scatid = Integer.parseInt(request.getParameter("delsc"));
				new Sous_categorieDAO().deleteById(scatid);
				response.sendRedirect("Categories_admin_aj");
				return;
			}
			if(request.getParameter("delssc")!=null) {
				int sscatid = Integer.parseInt(request.getParameter("delssc"));
				new Sous_sous_categorieDAO().deleteById(sscatid);
				response.sendRedirect("Categories_admin_aj");
				return;
			}
			
		// Charger l'arborescence complète
	        ArrayList<Categorie> categories = CategorieDAO.getAllFullTree();
	        request.setAttribute("categories", categories);
	        request.getRequestDispatcher("/cat_adm_aj.jsp").forward(request, response);
	    }

	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	    	String action = request.getParameter("action");

	        if ("addCategorie".equals(action)) {
	            // Créer un objet Categorie avec le titre fourni
	            Categorie cat = new Categorie();
	            cat.setTitre(request.getParameter("titre_categorie"));

	            // Appeler la méthode save (non statique) sur DAO
	            new CategorieDAO().save(cat);

	            request.setAttribute("result", "Catégorie ajoutée !");
	        } 
	        else if ("addSousCategorie".equals(action)) {
	            Sous_categorie scat = new Sous_categorie();
	            scat.setTitre(request.getParameter("titre_sous_categorie"));
	            
	            // Récupération de l'id de la catégorie parente
	            int catId = Integer.parseInt(request.getParameter("categorie_id"));
	            scat.setCategorie_id(catId);

	            // Appeler la méthode save sur SousCategorieDAO
	            new Sous_categorieDAO().save(scat);

	            request.setAttribute("result", "Sous-catégorie ajoutée !");
	        } 
	        else if ("addSousSousCategorie".equals(action)) {
	            Sous_sous_categorie sscat = new Sous_sous_categorie();
	            sscat.setTitre(request.getParameter("titre_sous_sous_categorie"));

	            int sousCatId = Integer.parseInt(request.getParameter("sous_categorie_id"));
	            sscat.setSous_categorie_id(sousCatId);

	            new Sous_sous_categorieDAO().save(sscat);

	            request.setAttribute("result", "Sous-sous-catégorie ajoutée !");
	        }

	        // Réaffiche la page (avec message ou arborescence mise à jour)
	        doGet(request, response);
	    }
}