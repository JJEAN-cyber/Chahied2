-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 27 oct. 2025 à 11:03
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `chahiedd`
--

DELIMITER $$
--
-- Procédures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `getConversationWithNames` (IN `p_id` INT)   BEGIN
    SELECT 
        c.*,
        u1.nom AS participant1_nom,
        u2.nom AS participant2_nom
    FROM 
        conversation c
    LEFT JOIN 
        utilisateur u1 ON c.participant1_id = u1.id
    LEFT JOIN 
        utilisateur u2 ON c.participant2_id = u2.id
    WHERE 
        c.id = p_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMessagesByConversationId` (IN `p_conversation_id` INT)   BEGIN
    SELECT
        m.id,
        m.expediteur_id,
        u1.nom AS expediteur_nom,
        m.destinataire_id,
        u2.nom AS destinataire_nom,
        m.contenu,
        m.date_envoi,
        m.article_id,
        m.conversation_id
    FROM message m
    LEFT JOIN utilisateur u1 ON m.expediteur_id = u1.id
    LEFT JOIN utilisateur u2 ON m.destinataire_id = u2.id
    WHERE m.conversation_id = p_conversation_id
    ORDER BY m.date_envoi ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOrCreateConversationId` (IN `p_expediteur_id` INT, IN `p_destinataire_id` INT, IN `p_article_id` INT, OUT `p_conversation_id` INT)   BEGIN
DECLARE user1_id INT;
DECLARE user2_id INT;
DECLARE existing_id INT;
IF p_expediteur_id < p_destinataire_id THEN
SET user1_id = p_expediteur_id;
SET user2_id = p_destinataire_id;
ELSE
SET user1_id = p_destinataire_id;
SET user2_id = p_expediteur_id;
END IF;
SELECT id INTO existing_id
FROM  conversation
WHERE participant1_id = user1_id AND participant2_id = user2_id AND article_id = p_article_id
LIMIT 1;
IF existing_id IS NOT NULL THEN
SET p_conversation_id = existing_id;
ELSE
INSERT INTO conversation (participant1_id, participant2_id, last_updated, article_id)
VALUES (user1_id, user2_id, NOW(), p_article_id);
SET p_conversation_id = LAST_INSERT_ID();
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetUserConversation` (IN `expediteurId` INT)   BEGIN
SELECT
t.user1,
t.user2,
m.contenu AS dernier_message_contenu,
m.date_envoi AS date_envoi_message
FROM(
SELECT
LEAST(expediteur_id, destinataire_id) AS user1,
GREATEST(expediteur_id, destinataire_id) AS user2,
MAX(id) AS dernier_message_id
FROM message
WHERE expediteur_id = expediteurId OR destinataire_id = expediteurId
GROUP BY user1, user2
) t
JOIN message m ON m.id = t.dernier_message_id
ORDER BY m.date_envoi DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `incrementer_vue` (IN `p_article_id` INT)   BEGIN
    UPDATE articles
    SET nbre_vues = nbre_vues + 1
    WHERE id = p_article_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `lister_conversations_utilisateur` (IN `p_user_id` INT)   BEGIN
    SELECT 
        CASE 
            WHEN m.expediteur_id = p_user_id THEN u2.nom
            WHEN m.destinataire_id = p_user_id THEN u1.nom
        END AS nom_autre_utilisateur,
        a.titre AS titre_article,
        a.prix AS prix_article,
        a.id AS article_id,
        CASE 
            WHEN m.expediteur_id = p_user_id THEN m.destinataire_id
            WHEN m.destinataire_id = p_user_id THEN m.expediteur_id
        END AS autre_utilisateur_id
    FROM 
        message m
    JOIN 
        utilisateur u1 ON m.expediteur_id = u1.id
    JOIN 
        utilisateur u2 ON m.destinataire_id = u2.id
    JOIN 
        article a ON m.article_id = a.id
    WHERE 
        m.expediteur_id = p_user_id OR m.destinataire_id = p_user_id
    GROUP BY
        CASE 
            WHEN m.expediteur_id = p_user_id THEN m.destinataire_id
            WHEN m.destinataire_id = p_user_id THEN m.expediteur_id
        END,
        a.id, a.titre, a.prix, u1.nom, u2.nom;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `list_conversations_with_article` (IN `p_user_id` INT)   BEGIN
    SELECT 
        c.id AS conversation_id,
        c.participant1_id,
        u1.nom AS participant1_nom,
        c.participant2_id,
        u2.nom AS participant2_nom,
        c.last_message_snippet,
        c.last_updated,
        c.article_id,
        a.titre AS article_nom
    FROM conversation c
    LEFT JOIN utilisateur u1 ON c.participant1_id = u1.id
    LEFT JOIN utilisateur u2 ON c.participant2_id = u2.id
    LEFT JOIN articles a ON c.article_id = a.id
    WHERE c.participant1_id = p_user_id OR c.participant2_id = p_user_id
    ORDER BY c.last_updated DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `send_message_and_update_conversation` (IN `p_expediteur_id` INT, IN `p_destinataire_id` INT, IN `p_contenu` VARCHAR(1000), IN `p_date_envoi` DATETIME, IN `p_article_id` INT, IN `p_conversation_id` INT)   BEGIN
INSERT INTO message (expediteur_id, destinataire_id, contenu, date_envoi, article_id, conversation_id) VALUES ( p_expediteur_id, p_destinataire_id, p_contenu, p_date_envoi, p_article_id, p_conversation_id); 
UPDATE conversation
SET last_message_snippet = LEFT(p_contenu, 255),
last_updated = NOW()
WHERE id = p_conversation_id;
END$$

--
-- Fonctions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `get_nbre_favoris` (`p_article_id` INT) RETURNS INT(11)  BEGIN
    DECLARE nb INT;
    SELECT COUNT(*) INTO nb FROM favori WHERE article_id = p_article_id;
    RETURN nb;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `actegorie`
--

CREATE TABLE `actegorie` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `actegorie`
--

INSERT INTO `actegorie` (`id`, `titre`) VALUES
(1, 'Europe'),
(2, 'Amérique du nord'),
(3, 'Amérique du sud'),
(4, 'Asie'),
(5, 'Afrique'),
(6, 'Moyen-Orient');

-- --------------------------------------------------------

--
-- Structure de la table `administrateur`
--

CREATE TABLE `administrateur` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `administrateur`
--

INSERT INTO `administrateur` (`id`, `nom`, `email`, `mot_de_passe`) VALUES
(1, 'Zak', 'zak@zak', '123');

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `utilisateur_id` int(11) DEFAULT NULL,
  `titre` varchar(255) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `sous_sous_categorie_id` int(11) DEFAULT NULL,
  `sous_sous_actegorie_id` int(11) DEFAULT NULL,
  `etat` varchar(255) DEFAULT NULL,
  `prix` double DEFAULT NULL,
  `format_envoi` varchar(255) DEFAULT NULL,
  `date_publication` datetime DEFAULT NULL,
  `couleur` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `taille` varchar(255) NOT NULL,
  `marque` varchar(255) DEFAULT NULL,
  `nbre_vues` int(11) NOT NULL,
  `disponible` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `articles`
--

INSERT INTO `articles` (`id`, `utilisateur_id`, `titre`, `description`, `sous_sous_categorie_id`, `sous_sous_actegorie_id`, `etat`, `prix`, `format_envoi`, `date_publication`, `couleur`, `matiere`, `taille`, `marque`, `nbre_vues`, `disponible`) VALUES
(11, 1, 'Robe ', 'Robe blanche a fleur', 2, 10, 'Satisfaisant', 15, 'moyen', '2025-05-12 14:10:55', 'Bleu;Vert', 'Coton', 'S', 'Anaïs-Anaïs', 159, 1),
(12, 1, 'Jean', 'Jean bleu a paillettes', 11, 15, 'BON état', 7.5, 'moyen', '2025-05-12 15:15:48', 'Bleu', 'Coton', 'XS - 36', 'Levis', 39, 0),
(13, 1, 't-shirt a papillon', 'blanc avec motif', 3, 62, 'Neuf sans étiquette', 4.2, 'moyen', '2025-05-12 15:47:39', 'Vert', 'Coton', 'XS ', 'RUNNI', 13, 1),
(14, 1, 'T SHIRT ', 'T SHIRT BLANC AVEC OISEAU', 3, 214, 'Neuf sans étiquette', 5.4, 'petit', '2025-05-12 15:49:05', 'Noir', 'Coton', 'S', 'CALVIN KLEIN', 15, 0),
(15, 1, 't-shirt champion', 't shirt de couleurs', 3, 11, 'Neuf avec etiquette', 4.9, 'petit', '2025-05-12 15:52:01', 'Rose;Marron', 'Coton', 'L', 'champion', 7, 1),
(16, 4, 'Robe noir', 'Robe moulante de soirée', 2, 9, 'Neuf avec etiquette', 26.9, 'petit', '2025-08-13 10:02:33', 'Noir', 'Soie', 'S', 'cacharel', 2, 0),
(17, 4, 'Tailleur dentelle noir', 'Tailleur dentelle noir', 9, 15, 'Satisfaisant', 34.2, 'petit', '2025-08-13 10:11:36', 'Noir', 'Laine', 'L', 'dior', 8, 0),
(18, 4, 'soutien gorge', 'noir dentelle', 6, 11, 'Neuf avec etiquette', 13.4, 'petit', '2025-08-13 10:18:40', 'Noir', 'Coton', 'XS - 36', 'cabanna', 3, 0),
(19, 4, 'maillot de foot', 'maillot bleu', 150, 13, 'Satisfaisant', 3.8, 'petit', '2025-08-13 10:24:02', 'Bleu', 'Coton', 'S', 'goaal', 1, 0),
(20, 4, 'maillot de bain', 'une pièce', 13, 38, 'Neuf sans étiquette', 12.8, 'petit', '2025-08-18 15:40:46', 'Orange', 'Polyester', 'M', 'berlean', 5, 0),
(21, 4, 'veste', 'veste daim en marron', 74, 74, 'BON Ã©tat', 29.9, 'grand', '2025-08-18 16:31:00', 'Marron', 'Acier', 'XL', 'hugo tross', 4, 1),
(22, 4, 'pull coll roulÃ©', 'taupe tortue hiver', 1, 1, 'Satisfaisant', 14.5, 'moyen', '2025-08-19 11:28:37', 'Marron', 'Laine', 'M', 'kalo', 10, 1),
(23, 4, 'pull noël', 'avec flocon de neige', 81, 81, 'BON état', 8.4, 'moyen', '2025-08-19 11:45:43', 'Rouge', 'Laine', 'L', 'alsac', 3, 1),
(24, 7, 'lOGO  EN LAINE HTML', 'PETIT LOGO A ENFIL2', 45, 45, 'Satisfaisant', 1.4, 'petit', '2025-10-08 17:37:43', 'Bleu', 'Laine', 'XS ', 'HTML', 1, 1),
(25, 4, 'Robe rouge', 'robe cstumé', 2, 2, 'Très bon état', 300, 'grand', '2025-10-22 00:42:55', 'Rouge', 'Soie', 'M', 'Cendrillon', 0, 1),
(26, 4, 'Robe noir', 'robe moulante', 2, 2, 'Satisfaisant', 4.2, 'grand', '2025-10-22 13:50:33', 'Noir', 'Coton', 'L', 'chanel', 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id`, `titre`) VALUES
(1, 'Femmes'),
(2, 'Hommes'),
(4, 'Article de créateurs'),
(5, 'Enfants'),
(6, 'Maison');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `id` int(11) NOT NULL,
  `utilisateur_id` int(11) DEFAULT NULL,
  `adresse_livraison` varchar(255) DEFAULT NULL,
  `option_livraison` varchar(255) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `montant_total` double DEFAULT NULL,
  `date_commande` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`id`, `utilisateur_id`, `adresse_livraison`, `option_livraison`, `telephone`, `montant_total`, `date_commande`) VALUES
(2, 3, 'FGERG', 'domicile', '07653328823', 7.5, '2025-08-12 14:55:45'),
(3, 1, '<QC', 'domicile', '34344', 7.5, '2025-08-12 14:57:41'),
(4, 3, 'RUE DE LA PAUME', 'domicile', '7888839399', 7.5, '2025-08-12 15:13:28'),
(5, 3, '16 allee platane Paris 13', 'point_relais', '06456636366', 5.4, '2025-08-12 20:55:03'),
(6, 3, 'Place du quai', 'domicile', '076543344334', 4.9, '2025-08-12 21:05:01'),
(7, 3, 'rue de la faune', 'domicile', '07636363636', 4.2, '2025-08-12 21:16:26'),
(8, 3, '12 rue de la foire', 'domicile', '0987477488', 15, '2025-08-12 21:33:43'),
(10, 1, '15 rue bichat 75010', 'domicile', '0765544524', 5.4, '2025-09-02 15:37:07'),
(11, 4, 'ADSD', 'domicile', '23', 34.2, '2025-10-22 00:36:09'),
(12, 4, 'SDV', 'domicile', '45', 13.4, '2025-10-22 00:36:50'),
(13, 4, 'F', 'domicile', '35', 3.8, '2025-10-22 00:37:26'),
(14, 4, 'DV', 'point_relais', '4657', 12.8, '2025-10-22 00:38:06'),
(15, 8, 'AZR', 'domicile', '12', 7.5, '2025-10-22 13:45:10');

-- --------------------------------------------------------

--
-- Structure de la table `conversation`
--

CREATE TABLE `conversation` (
  `id` int(11) NOT NULL,
  `participant1_id` int(11) NOT NULL,
  `participant2_id` int(11) NOT NULL,
  `last_message_snippet` varchar(500) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `article_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `conversation`
--

INSERT INTO `conversation` (`id`, `participant1_id`, `participant2_id`, `last_message_snippet`, `last_updated`, `article_id`) VALUES
(2, 1, 3, 'SALUT', '2025-07-15 10:32:47', 12),
(3, 1, 3, 'vous etes lÃ ?\r\n', '2025-07-03 11:10:04', 13),
(4, 1, 3, 'NON RENTRE CHEZ TOI', '2025-09-02 15:36:23', 11),
(5, 1, 3, 'HEY', '2025-07-15 10:33:27', 15),
(6, 1, 3, 'WESH', '2025-07-28 10:57:38', 14),
(7, 1, 1, NULL, '2025-09-02 15:37:07', 14),
(8, 1, 4, 'SALUT', '2025-09-29 13:52:23', 21),
(9, 4, 4, NULL, '2025-10-22 00:36:09', 17),
(10, 4, 4, NULL, '2025-10-22 00:36:50', 18),
(11, 4, 4, NULL, '2025-10-22 00:37:26', 19),
(12, 4, 4, NULL, '2025-10-22 00:38:06', 20),
(13, 1, 8, NULL, '2025-10-22 13:45:10', 12),
(14, 4, 8, 'SALUT DIDIER\r\n', '2025-10-22 13:47:10', 22);

-- --------------------------------------------------------

--
-- Structure de la table `evaluation`
--

CREATE TABLE `evaluation` (
  `id` int(11) NOT NULL,
  `evaluateur_id` int(11) DEFAULT NULL,
  `evalue_id` int(11) DEFAULT NULL,
  `note` int(11) DEFAULT NULL,
  `commentaire` varchar(1000) DEFAULT NULL,
  `date_evaluation` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `favori`
--

CREATE TABLE `favori` (
  `id` int(11) NOT NULL,
  `utilisateur_id` int(11) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `favori`
--

INSERT INTO `favori` (`id`, `utilisateur_id`, `article_id`) VALUES
(15, 1, 15),
(17, 1, 13),
(30, 4, 17),
(34, 3, 22),
(38, 3, 13),
(39, 3, 11),
(40, 3, 12),
(41, 1, 12),
(42, 8, 11);

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `expediteur_id` int(11) DEFAULT NULL,
  `destinataire_id` int(11) DEFAULT NULL,
  `contenu` varchar(1000) DEFAULT NULL,
  `date_envoi` datetime DEFAULT NULL,
  `article_id` int(11) NOT NULL,
  `conversation_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `message`
--

INSERT INTO `message` (`id`, `expediteur_id`, `destinataire_id`, `contenu`, `date_envoi`, `article_id`, `conversation_id`) VALUES
(9, 3, 1, 'koli up', '2025-06-23 11:31:04', 13, 3),
(10, 3, 1, 'salut', '2025-06-27 11:50:48', 11, 4),
(11, 1, 3, 'bienvenue sur ma page', '2025-06-30 11:55:25', 11, 4),
(12, 3, 1, 'est ce que je peux vous acheter ce produit?\r\n', '2025-06-30 12:36:33', 11, 4),
(13, 3, 1, 'JE SOUHAITERZAI ACHETER CE PRODUIT', '2025-06-30 13:50:22', 12, 2),
(14, 3, 1, 'vous etes lÃ ?\r\n', '2025-07-03 11:10:04', 13, 3),
(15, 3, 1, 'SALUT', '2025-07-15 10:32:47', 12, 2),
(16, 3, 1, 'HEY', '2025-07-15 10:33:27', 15, 5),
(17, 3, 1, 'WESH', '2025-07-28 10:57:38', 14, 6),
(20, 3, 1, 'Bonjour, votre article \'t-shirt a papillon\' a été acheté !', '2025-08-12 21:16:26', 13, 3),
(21, 3, 1, 'Bonjour, votre article \'Robe \' a été acheté !', '2025-08-12 21:33:43', 11, 4),
(22, 3, 1, 'RHGG', '2025-08-21 23:51:21', 11, 4),
(23, 3, 1, 'Bonjour, votre article \'T SHIRT \' a été acheté !', '2025-09-01 10:06:25', 14, 6),
(24, 1, 3, 'NON RENTRE CHEZ TOI', '2025-09-02 15:36:23', 11, 4),
(25, 1, 1, 'Bonjour, votre article \'T SHIRT \' a été acheté !', '2025-09-02 15:37:07', 14, 7),
(26, 1, 4, 'SALUT', '2025-09-29 13:52:23', 21, 8),
(27, 4, 4, 'Bonjour, votre article \'Tailleur dentelle noir\' a été acheté !', '2025-10-22 00:36:09', 17, 9),
(28, 4, 4, 'Bonjour, votre article \'soutien gorge\' a été acheté !', '2025-10-22 00:36:50', 18, 10),
(29, 4, 4, 'Bonjour, votre article \'maillot de foot\' a été acheté !', '2025-10-22 00:37:26', 19, 11),
(30, 4, 4, 'Bonjour, votre article \'maillot de bain\' a été acheté !', '2025-10-22 00:38:06', 20, 12),
(31, 8, 1, 'Bonjour, votre article \'Jean\' a été acheté !', '2025-10-22 13:45:10', 12, 13),
(32, 8, 4, 'SALUT DIDIER\r\n', '2025-10-22 13:47:10', 22, 14);

-- --------------------------------------------------------

--
-- Structure de la table `offre`
--

CREATE TABLE `offre` (
  `id` int(11) NOT NULL,
  `utilisateur_id` int(11) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL,
  `montant_offre` double DEFAULT NULL,
  `date_offre` datetime DEFAULT NULL,
  `statut` varchar(255) DEFAULT 'en attente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `photo_article`
--

CREATE TABLE `photo_article` (
  `id` int(11) NOT NULL,
  `article_id` int(11) DEFAULT NULL,
  `chemin_fichier` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `photo_article`
--

INSERT INTO `photo_article` (`id`, `article_id`, `chemin_fichier`) VALUES
(11, 11, '87f33029-b2a4-4bca-9c83-8917e6a61ce4_201911301411414012862.jpg'),
(12, 12, '62c4d521-d6b1-4c64-a5cb-49b8b1524777_paillettes-jeans-avec-strass-femmes-lady.jpg'),
(13, 13, 'c044931e-6068-4cf5-b8f2-a772d5a4c558_9860d0c0-d734-4eb8-b500-2e1d242e43dc.f19714e6668f2ae4ea10427c237f9d69.webp'),
(14, 14, '6f0ab3a5-bd14-4e81-bfc6-7209e6f67e11_calvin-klein_190061_J20J212586_BAE_20190725T161706_01.webp'),
(15, 15, '354ec88c-c4b8-4963-87e2-c1fd657e20ca_champion_196264_110992_VS050_20190910T135136_01.webp'),
(17, 16, '164bbc432dab4bb8958ae224e682ecb7.webp'),
(18, 17, '240b349f-beda-4eb9-90c9-0e034127de93_maison-close-inspiration-divine.jpg'),
(19, 18, '94a8793b-58e7-4157-af9e-f5d2f78ef40c_SAVAGE-NOT-SORRY-UNLINED-LACE-BALCONETTE-BRA-BA2042992-3156-LAYDOWN-1200x1600.webp'),
(20, 19, 'b1709dec-a41d-4c4b-ab43-3074df9dd2ad_maillot-domicile-junior-24-25.webp'),
(21, 20, 'f553c022-f7ce-4c19-aa7f-d8f8383bee04_vue-laterale-de-la-nageuse-organisant-ses-cheveux-avant-de-nager.jpg'),
(22, 21, '019abc3d-db7d-41a6-94fc-8cbca269588d_veste-brandit-m-65-classique-kaki.jpg'),
(23, 22, '425626cd-40b5-4585-aa0b-5798860be697_beau-pull-cou-tortue-hiver-isole-fond-transparent_927015-8661.jpg'),
(24, 23, '9821a206-463c-43b8-a5d0-34bd086b6d2c_istockphoto-614735348-1024x1024.jpg'),
(25, 24, '1471264e-74e1-41c4-b97a-5a4f91e2aad9_free-logo-html-5-free-png.webp'),
(26, 25, 'e628a9e7-87ba-41fa-bac2-72b50ffbc596_Heff99d4be6834bafae40f99a13dfb532x_800x800.webp'),
(27, 26, '3d3647a7-b8f0-4441-9156-5959066db70a_Heff99d4be6834bafae40f99a13dfb532x_800x800.webp');

-- --------------------------------------------------------

--
-- Structure de la table `recherche`
--

CREATE TABLE `recherche` (
  `id` int(11) NOT NULL,
  `utilisateur_id` int(11) DEFAULT NULL,
  `mot_cle` varchar(255) DEFAULT NULL,
  `nombre_resultats` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `recherche`
--

INSERT INTO `recherche` (`id`, `utilisateur_id`, `mot_cle`, `nombre_resultats`) VALUES
(29, 3, 'test', 1),
(33, 3, 'J', 1),
(34, 3, 'J', 1),
(35, 3, 'R', 0),
(36, 3, 'ANAIS', 0),
(37, 3, 'A', 0),
(38, 3, 'R', 0),
(39, 3, 'robe', 0),
(40, 3, 'T', 0),
(41, 3, 'Robe', 0),
(42, 3, 'J', 1),
(43, 3, 'S', 1),
(44, 3, 'J', 0),
(45, 3, 'Robe', 0),
(46, 3, 'robe', 0),
(47, 3, 'Robe', 0),
(48, 3, 'R', 0),
(49, 3, 'R', 0),
(50, 3, 'R', 8),
(51, 3, 'j', 1),
(52, 3, 'j', 1),
(53, 3, 'j', 1),
(54, 3, 'j', 1),
(55, 3, 'j', 1),
(56, 3, 'j', 1),
(57, 3, 'j', 1),
(58, 3, 'j', 1),
(59, 3, 'j', 1),
(60, 3, 'R', 8),
(61, 3, 'R', 8),
(62, 1, 'J', 1),
(63, 3, 's', 1),
(64, 3, 's', 5),
(65, 1, 'J', 1),
(66, 1, 'a', 1),
(67, 4, 'a', 8),
(68, 8, 'a', 5),
(69, 8, 'a', 8);

-- --------------------------------------------------------

--
-- Structure de la table `resume_commande`
--

CREATE TABLE `resume_commande` (
  `id` int(11) NOT NULL,
  `commande_id` int(11) DEFAULT NULL,
  `article_id` int(11) NOT NULL,
  `total_commande` double DEFAULT NULL,
  `frais_protection_acheteur` double DEFAULT NULL,
  `frais_port` double DEFAULT NULL,
  `total_frais_commande` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `resume_commande`
--

INSERT INTO `resume_commande` (`id`, `commande_id`, `article_id`, `total_commande`, `frais_protection_acheteur`, `frais_port`, `total_frais_commande`) VALUES
(7, 2, 12, 7.5, 1.125, 1.5, 10.125),
(8, 3, 12, 7.5, 1.125, 1.5, 10.125),
(9, 4, 12, 7.5, 1.125, 1.5, 10.125),
(10, 5, 14, 5.4, 0.81, 1.08, 7.290000000000001),
(11, 6, 15, 4.9, 0.735, 0.9800000000000001, 6.615000000000001),
(12, 7, 13, 4.2, 0.63, 0.8400000000000001, 5.67),
(13, 8, 11, 15, 2.25, 3, 20.25),
(15, 10, 14, 5.4, 0.81, 1.08, 7.290000000000001),
(16, 11, 17, 34.2, 3.4200000000000004, 6.840000000000001, 44.46000000000001),
(17, 12, 18, 13.4, 1.34, 2.68, 17.42),
(18, 13, 19, 3.8, 0.38, 0.76, 4.9399999999999995),
(19, 14, 20, 12.8, 1.2800000000000002, 2.5600000000000005, 16.64),
(20, 15, 12, 7.5, 0.75, 1.5, 9.75);

--
-- Déclencheurs `resume_commande`
--
DELIMITER $$
CREATE TRIGGER `calculer_frais_resume_update` BEFORE UPDATE ON `resume_commande` FOR EACH ROW BEGIN
  SET NEW.frais_protection_acheteur = NEW.total_commande * 0.10;
  SET NEW.frais_port = NEW.total_commande * 0.20;
  SET NEW.total_frais_commande = NEW.total_commande + NEW.frais_protection_acheteur + NEW.frais_port;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `sous_actegorie`
--

CREATE TABLE `sous_actegorie` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) DEFAULT NULL,
  `actegorie_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `sous_actegorie`
--

INSERT INTO `sous_actegorie` (`id`, `titre`, `actegorie_id`) VALUES
(1, 'Allemagne', 1),
(2, 'Royaume-uni', 1),
(3, 'France', 1),
(4, 'Espagne', 1),
(5, 'Italie', 1),
(6, 'Etats-Unis', 2),
(7, 'Canada', 2),
(8, 'Brésil', 3),
(9, 'Chili', 3),
(10, 'Mexique', 3),
(11, 'Chine', 4),
(12, 'Japon', 4),
(13, 'Thaïlande', 4),
(14, 'Inde', 4),
(15, 'Australie', 4),
(16, 'Cameroun', 5),
(17, 'Mali', 5),
(18, 'Sénégal', 5),
(19, 'Arabie Saoudite', 6),
(20, 'Grèce', 6),
(21, 'Egypte', 6),
(22, 'Turquie', 6);

-- --------------------------------------------------------

--
-- Structure de la table `sous_categorie`
--

CREATE TABLE `sous_categorie` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) DEFAULT NULL,
  `categorie_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `sous_categorie`
--

INSERT INTO `sous_categorie` (`id`, `titre`, `categorie_id`) VALUES
(1, 'Vêtements', 1),
(2, 'chaussures', 1),
(3, 'sacs', 1),
(4, 'accessoires', 1),
(5, 'body and care', 1),
(6, 'vêtements', 2),
(7, 'Chaussures', 2),
(8, 'Accessoires', 2),
(9, 'Soins', 2),
(10, 'Articles de créateurs pour femmes', 4),
(11, 'Articles de créateurs pour hommes', 4),
(12, 'Filles', 5),
(13, 'Garçons', 5),
(14, 'Jouets', 5),
(15, 'Soins bébé', 5),
(16, 'Poussettes', 5),
(17, 'Porteurs & trotteurs et jouets à bascule', 5),
(18, 'Chaises hautes et sièges auto', 5),
(19, 'Mobilier enfant', 5),
(20, 'Fournitures scolaires', 5),
(23, 'Textiles', 6),
(24, 'Décoration', 6),
(25, 'Arts de la table', 6),
(26, 'Célébrations et fêtes', 6);

-- --------------------------------------------------------

--
-- Structure de la table `sous_sous_actegorie`
--

CREATE TABLE `sous_sous_actegorie` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) DEFAULT NULL,
  `sous_actegorie_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `sous_sous_actegorie`
--

INSERT INTO `sous_sous_actegorie` (`id`, `titre`, `sous_actegorie_id`) VALUES
(1, 'Jour de l\'an', 1),
(2, 'Epiphanie', 1),
(3, 'Journée internationale des femmes', 1),
(4, 'Vendredi saint', 1),
(5, 'Lundi de Pâques', 1),
(6, 'Fête du travail', 1),
(7, 'Ascension', 1),
(8, 'Lundi de Pentecôte', 1),
(9, 'Fete-Dieu', 1),
(10, 'Assomption', 1),
(11, 'Journée de l\'enfance', 1),
(12, 'Jour de l\'Unite allemande', 1),
(13, 'Fête de la réformation', 1),
(14, 'Toussaint', 1),
(15, 'Jour de pénitence et de prières', 1),
(16, 'Noël', 1),
(17, 'Lendemain de Noël', 1),
(18, 'Nouvel an', 2),
(19, '2 Janvier', 2),
(20, 'Fête de la Saint-Patrick', 2),
(21, 'Vendredi saint', 2),
(22, 'Lundi de Pâques', 2),
(23, 'Fêtes de mai', 2),
(24, 'Fêtes de printemps', 2),
(25, 'Bataille de la Boyne', 2),
(26, 'Fête d\'été', 2),
(27, 'Fête de la Saint-André', 2),
(28, 'Noël', 2),
(29, 'Fête de la Saint-Etienne', 2),
(30, 'Jour de l\'an', 3),
(31, 'Vendredi saint', 3),
(32, 'Lundi de Pâques', 3),
(33, 'Abolition de l\'esclavage', 3),
(34, 'Saint-Pierre Chanel', 3),
(35, 'Fête du travail', 3),
(36, 'Fête de la victoire', 3),
(37, 'Jeudi de l\'ascension', 3),
(38, 'Lundi de Pentecôte', 3),
(39, 'fête de l\'autonomie', 3),
(40, 'fête nationale', 3),
(41, 'fête de Victor Schoelcher', 3),
(42, 'fête du territoire', 3),
(43, 'Assomption', 3),
(44, 'Fête de la citoyenneté', 3),
(45, 'Toussaint', 3),
(46, 'Armistice de 1918', 3),
(47, 'Noël', 3),
(48, 'Saint-Etienne', 3),
(49, 'Jour de l\'an', 4),
(50, 'Epiphanie', 4),
(51, 'Jour de l\'Andalousie', 4),
(52, 'Saint-valentin', 3),
(53, 'Fête de la musique', 3),
(54, 'Jour des îles Baléares', 4),
(55, 'Saint Joseph', 4),
(56, 'Jeudi saint', 4),
(57, 'Lundi de Pâques', 4),
(58, 'Saint Jordi', 4),
(59, 'Jour de Castille-et-Leon', 4),
(60, 'Fête du travail', 4),
(61, 'Jour de la communauté', 4),
(62, 'Jour de la croix', 4),
(63, 'Journée des lettres galiciennes', 4),
(64, 'Jour des îles Canaries', 4),
(65, 'Jour de la région Castilla-La Mancha', 4),
(66, 'Fête-Dieu', 4),
(67, 'Jour de la région de Murcie', 4),
(68, 'Jour de La Rioja', 4),
(69, 'Nativité de Saint Jean-Baptiste', 4),
(70, 'Saint Jacques', 4),
(71, 'Assomption de Marie', 4),
(72, 'Jour de Ceuta', 4),
(73, 'Jour de l\'Asturies', 4),
(74, 'Jour de l\'Estrémadure', 4),
(75, 'Fête nationale de la Catalogne', 4),
(76, 'Jour de la Cantabrie', 4),
(77, 'Jour de Melilla', 4),
(78, 'Jour de la communauté valencienne', 4),
(79, 'Fête nationale espagnole', 4),
(80, 'Toussaint', 4),
(81, 'Jour de la constitution', 4),
(82, 'Fête de l\'Immaculée Conception', 4),
(83, 'Noël', 4),
(84, 'Fête de la Saint-Etienne', 4),
(85, 'Jour de l\'an', 5),
(86, 'Epiphanie', 5),
(87, 'Jour du Drapeau', 5),
(88, 'Journée de la mémoire', 5),
(89, 'Anniversaire de l\'unification de l\'Italie', 5),
(90, 'Pâques', 5),
(91, 'Lundi de Pâques', 5),
(92, 'Fête de la libération', 5),
(93, 'Fête du travail', 5),
(94, 'Fête de la République Italienne', 5),
(95, 'Assomption', 5),
(96, 'Toussaint', 5),
(97, 'Journée de l\'Unité nationale', 5),
(98, 'Immaculée Conception', 5),
(99, 'Noël', 5),
(100, 'Fête de la Saint-Etienne', 5),
(101, 'La Sagra', 5),
(102, 'Le Palio', 5),
(103, 'Jour de l\'an', 6),
(104, 'Journée de Martin Luther King', 6),
(105, 'Journée de Robert E. Lee', 6),
(106, 'Anniversaire de Lincoln', 6),
(107, 'Journée de la Présidence', 6),
(108, 'Journée de Casimir Pulaski', 6),
(109, 'Journée de l\'Evacuation', 6),
(110, 'Journée du prince Kuhio', 6),
(111, 'Jour de Seward', 6),
(112, 'Jour de César Chavez', 6),
(113, 'Mardi gras', 6),
(114, 'Vendredi saint', 6),
(115, 'Journée des patriotes', 6),
(116, 'Fête du mémorial des confédérés', 6),
(117, 'Jour du souvenir', 6),
(118, 'Anniversaire de Jefferson Davis', 6),
(119, 'Journée de Kamehameha 1er', 6),
(120, 'Fin de l\'esclavagisme', 6),
(121, 'Jour de l\'Indépendance', 6),
(122, 'Jour d\'Etat', 6),
(123, 'Fête du travail', 6),
(124, 'Jour de Christophe Colomb', 6),
(125, 'Jour de l\'Alaska', 6),
(126, 'Jour des élections', 6),
(127, 'Journée des anciens combattants', 6),
(128, 'Thanksgiving', 6),
(129, 'Noël', 6),
(130, 'Réveillon de la Saint-Sylvestre', 6),
(131, 'Jour de l\'an', 7),
(132, 'Journée Louis Riel', 7),
(133, 'Fête des Insulaires', 7),
(134, 'Fête de la famille', 7),
(135, 'Fête de la Saint-Patrick', 7),
(136, 'Vendredi Saint', 7),
(137, 'Pâques', 7),
(138, 'Fête de la Saint-Georges', 7),
(139, 'Journée nationale des Patriotes', 7),
(140, 'Fête de la Reine', 7),
(141, 'Journée nationale des Autochtones', 7),
(142, 'Fête nationale du Québec', 7),
(143, 'Jour de la Découverte', 7),
(144, 'Fête du Canada', 7),
(145, 'Fête du Nunavut', 7),
(146, 'Fête des Orangistes', 7),
(147, 'Premier lundi d\'Août', 7),
(148, 'Fête du Patrimoine', 7),
(149, 'Jour de la Fondation', 7),
(150, 'Défilé de la coupe d\'or', 7),
(151, 'Fête du Travail', 7),
(152, 'Journée de la vérité et de la réconciliation', 7),
(153, 'Action de grâce', 7),
(154, 'Jour de l\'Armistice', 7),
(155, 'Jour du souvenir', 7),
(156, 'Noël', 7),
(157, 'Boxing Day', 7),
(158, 'Nouvel An', 8),
(159, 'Vendredi saint', 8),
(160, 'lundi de Pâques', 8),
(161, 'Tiradentes, héros national', 8),
(162, 'Fête du travail', 8),
(163, 'Indépendance du Brésil', 8),
(164, 'Notre Dame d\'Aparecida sainte patronne du Brésil', 8),
(165, 'Jour des Morts', 8),
(166, 'Proclamation de la République', 8),
(167, 'Carnaval au Brésil', 8),
(168, 'Jour de la conscience noire', 8),
(169, 'Maracatu', 8),
(170, 'Kuarup', 8),
(171, 'Nouvel An', 9),
(172, 'Vendredi saint', 9),
(173, 'Journée national du travail', 9),
(174, 'Journée des gloires navales', 9),
(175, 'Saint Pierre et Saint Paul', 9),
(176, 'Vierge du Carmen', 9),
(177, 'Assomption de Marie', 9),
(178, 'Journée de l\'Indépendance Nationale', 9),
(179, 'Journée à la Gloire de l\'Armée', 9),
(180, 'Rencontre des deux Mondes', 9),
(181, 'Journée Nationale des Eglises Evangélistes et Protestantes', 9),
(182, 'Journée de tous les Saints', 9),
(183, 'Immaculée conception', 9),
(184, 'Noël', 9),
(185, 'Jour férié bancaire', 9),
(186, 'Nouvel An', 10),
(187, 'Epiphanie', 10),
(188, 'Chandeleur', 10),
(189, 'Proclamation de la constitution', 10),
(190, 'Jour de l\'armée', 10),
(191, 'Jour du drapeau', 10),
(192, 'Carnaval', 10),
(193, 'Anniversaire du president Benito Juarez', 10),
(194, 'Vendredi Saint', 10),
(195, 'Jour du Travail', 10),
(196, 'Anniversaire de la Bataille de Puebla', 10),
(197, 'Jour des mères', 10),
(198, 'Chute de Mexico', 10),
(199, 'Jour de l\'Indépendance', 10),
(200, 'Jour de la race', 10),
(201, 'Toussaint', 10),
(202, 'Jour des Morts', 10),
(203, 'Jour de la révolution de 1910', 10),
(204, 'Fête de la vierge Notre Dame de Guadalupe', 10),
(205, 'Noël', 10),
(206, 'Fête des 15 ans', 10),
(207, 'Jour du nouvel an', 11),
(208, 'Nouvel an Chinois', 11),
(209, 'Festival Qingming', 11),
(210, 'Fête du travail', 11),
(211, 'Festival des bateaux-dragons', 11),
(212, 'Festival de la mi-automne', 11),
(213, 'Fête nationale', 11),
(214, 'Nouvel An japonais', 12),
(215, 'Dezomeshiki', 12),
(216, 'Usokae', 12),
(217, 'Nanakusa', 12),
(218, 'Toka Ebisu Festival', 12),
(219, 'Kagami biraki', 12),
(220, 'Seijin no hi', 12),
(221, 'Koshogatsu', 12),
(222, 'Sagicho', 12),
(223, 'Yamayaki fête du feu de l\'herbe', 12),
(224, 'Festival de la neige de Sapporo', 12),
(225, 'Setsubun fête du lancer de haricots', 12),
(226, 'Festival des lanternes', 12),
(227, 'Kenkoku kinen no hi Anniversaire de la fondation de l\'Etat', 12),
(228, 'Saint-Valentin', 12),
(229, 'Tenno Tanjobi Anniversaire de l\'Empereur', 12),
(230, 'Saidai-ji Eyo matsuri Fête de l\'homme nu', 12),
(231, 'Shuni-e  ou Omizu-tori rituel du puisage de l\'eau', 12),
(232, 'Hina Matsuri fête des poupées', 12),
(233, 'Kasuga Shrine Festival', 12),
(234, 'White Day', 12),
(235, 'Shunbun no hi Jour de l\'équinoxe de printemps', 12),
(236, 'Hana Matsuri', 12),
(237, 'Takayama matsuri Défilé de chars décorés', 12),
(238, 'Yayoi matsuri', 12),
(239, 'Showa no hi Anniversaire de l\'Empereur Showa', 12),
(240, 'Kempo Kinenbi Commémoration de la Constitution', 12),
(241, 'Hakata Dontaku matsuri', 12),
(242, 'Hamamatsu matsuri Fête du cerf-volant', 12),
(243, 'Midori no hi Fête de la nature', 12),
(244, 'Kodomo no hi Jour des enfants', 12),
(245, 'Debut de la pêche au Cormoran Gifu', 12),
(246, 'Kanda matsuri', 12),
(247, 'Aoi Matsuri Festival de la rose trémière', 12),
(248, 'Tosho-gu', 12),
(249, 'Sanja Matsuri', 12),
(250, 'Mifune Matsuri', 12),
(251, 'Koromogae changement d\'uniforme', 12),
(252, 'Sanno matsuri', 12),
(253, 'Fête de la plantation du riz', 12),
(254, 'Chagu-chagu Umakko Fête du cheval', 12),
(255, 'Yamagasa matsuri', 12),
(256, 'Tanabata matsuri Fête des étoiles', 12),
(257, 'O-bon Fête des Morts', 12),
(258, 'Nachi no hi matsuri Fête du feu', 12),
(259, 'Kangensai Music Festival', 12),
(260, 'Gion Matsuri', 12),
(261, 'Umi no hi Jour de la mer', 12),
(262, 'Tenjin Matsuri', 12),
(263, 'Hanabi Taikai Grand feu d\'artifice', 12),
(264, 'Neputa matsuri', 12),
(265, 'Yama no hi Jour de la Montagne', 12),
(266, 'Awa-odori', 12),
(267, 'Daimonji Gozan Okuribi', 12),
(268, 'Kiku no sekku Fête des chrysanthèmes', 12),
(269, 'Hachiman-gu Festival', 12),
(270, 'Tsukimi', 12),
(271, 'Keiro no hi Journée de respect pour les personnes âgées', 12),
(272, 'Shubun no hi', 12),
(273, 'Koromogae changement de garde-robe', 12),
(274, 'Kunchi matsuri', 12),
(275, 'Taiiku no hi Jour de l\'éducation physique', 12),
(276, 'Takayama matsuri', 12),
(277, 'Kenka matsuri', 12),
(278, 'Duburoku matsuri', 12),
(279, 'Fin de la pêche au cormoran', 12),
(280, 'Nagoya Festival', 12),
(281, 'Tosho-gu Fall Festival', 12),
(282, 'Jidai matsuri', 12),
(283, 'Kurama matsuri', 12),
(284, 'Bunka no hi Jour de la Culture', 12),
(285, 'Daimyo Gyoretsu Fête du seigneur Féodal', 12),
(286, 'Shichi-go-san', 12),
(287, 'Tori-no-ichi Foire du coq', 12),
(288, 'Kinro Kansha no hi Fête du travail', 12),
(289, 'On matsuri', 12),
(290, 'Hagoita-ichi Fête des raquettes', 12),
(291, 'Noël', 12),
(292, 'Okera Mairi Ceremony', 12),
(293, 'Namahage', 12),
(294, 'Nouvel An chinois', 13),
(295, 'Saint-Valentin', 13),
(296, 'Makha Bucha', 13),
(297, 'Jour des Chakri', 13),
(298, 'SongKran Nouvel An thaïlandais', 13),
(299, 'Fête du travail', 13),
(300, 'Jour du couronnement du roi Rama X', 13),
(301, 'Cérémonie du Labour Royal', 13),
(302, 'Visakha Bucha', 13),
(303, 'Asahna Bucha', 13),
(304, 'Khao Phansa', 13),
(305, 'Anniversaire de SM le roi Vajiralongkorn', 13),
(306, 'Anniversaire de la reine mère Sirikit et fête des Mères', 13),
(307, 'date du décès de SM le roi Bhumibol Rama IX', 13),
(308, 'Ok Phansa', 13),
(309, 'Jour de Chulalongkorn', 13),
(310, 'loy Krathong', 13),
(311, 'Anniversaire du roi Rama IX et fête des Pères', 13),
(312, 'Jour de la constitution', 13),
(313, 'Noël', 13),
(314, 'Saint-Sylvestre', 13),
(315, 'Jour des enfants', 13),
(316, 'WAI traditionel jour des enseignants', 13),
(317, 'Jour du Muay Thaï', 13),
(318, 'Jour de l\'indépendance', 14),
(319, 'Jour de la République', 14),
(320, 'Anniversaire de Gandhi', 14),
(321, 'Divali', 14),
(322, 'Ganesh Chaturthi', 14),
(323, 'Krishna Jayanti', 14),
(324, 'Pongal', 14),
(325, 'Ugadi', 14),
(326, 'Holi', 14),
(327, 'Rama Navami', 14),
(328, 'Vijayadashami', 14),
(329, 'Onam', 14),
(330, 'Maha Shivaratri', 14),
(331, 'Thaipusam', 14),
(332, 'Id al-fitr', 14),
(333, 'Id al-Adha', 14),
(334, 'Ramadan', 14),
(335, 'Fête de Pâques', 14),
(336, 'Noël', 14),
(337, 'Nouvel An', 15),
(338, 'Jour de l\'Australie', 15),
(339, 'Royal Hobart Regatta', 15),
(340, 'Fête du travail', 15),
(341, 'Adelaide cup', 15),
(342, 'Pâques', 15),
(343, 'Journée de l\'ANZAC', 15),
(344, 'Western Australia Day', 15),
(345, 'Anniversaire de la Reine', 15),
(346, 'Picnic day', 15),
(347, 'Jour de la famille', 15),
(348, 'fête du travail', 15),
(349, 'Recreation Day', 15),
(350, 'Melbourne Cup', 15),
(351, 'réveillon de Noël', 15),
(352, 'Boxing Day', 15),
(353, 'Proclamation Day', 15),
(354, 'Réveillon de la Saint-Sylvestre', 15),
(355, 'Jour de l\'An', 16),
(356, 'Jour de l\'Indépendance', 16),
(357, 'Journée de la femme', 16),
(358, 'Fête du travail', 16),
(359, 'Fête de la jeunesse', 16),
(360, 'Fête nationale', 16),
(361, 'Début du Ramadan', 16),
(362, 'Aid el Kebir', 16),
(363, 'Pâques', 16),
(364, 'Ascension', 16),
(365, 'Pentecote', 16),
(366, 'Assomption', 16),
(367, 'Toussaint', 16),
(368, 'Noël', 16),
(369, 'Fete du travail', 16),
(370, 'Vivre ensemble', 17),
(371, 'Festival du Niger', 17),
(372, 'Saint-Valentin', 17),
(373, 'Journée des Martyrs', 17),
(374, 'Shab-e-Qadr', 17),
(375, 'Korite', 17),
(376, 'Début du ramadan', 17),
(377, 'Pâques', 17),
(378, 'Fête du travail', 17),
(379, 'Jour de l\'Afrique', 17),
(380, 'Id-el-Kabir', 17),
(381, 'Ashura', 17),
(382, 'Nouvel An', 18),
(383, 'Fête nationale jour de l\'Indépendance', 18),
(384, 'Fête du travail', 18),
(385, 'Journée de la femme', 18),
(386, 'Fête du tirailleur Sénégalais', 18),
(387, 'Journée de commémoration du massacre des tirailleurs de Thiaroye 44', 18),
(388, 'Tamkharit', 18),
(389, 'Magal de Touba', 18),
(390, 'Maouloud', 18),
(391, 'Début du ramadan', 18),
(392, 'Eid Al Fitr Korite', 18),
(393, 'Tabaski Aid el Kebir', 18),
(394, 'Pâques', 18),
(395, 'Ascension', 18),
(396, 'Pentecôte', 18),
(397, 'Assomption', 18),
(398, 'Toussaint', 18),
(399, 'Noël', 18),
(400, 'Naufrage du Joola', 18),
(401, 'Saint-Valentin', 18),
(402, 'Nouvel An', 19),
(403, 'Anniversaire de la fondation de l\'Arabie Saoudite', 19),
(404, 'Journée de l\'Association du Royaume', 19),
(405, 'Début du Ramadan', 19),
(406, 'Fête de la rupture du Jeûne Eid Al Fitr', 19),
(407, 'Fête du sacrifice Eid Al Adha', 19),
(408, 'Nouvel An Islamique Muharram', 19),
(409, 'Nouvel An', 20),
(410, 'Epiphanie', 20),
(411, 'Lundi pur', 20),
(412, 'Fête nationale de la Grèce', 20),
(413, 'Vendredi saint', 20),
(414, 'Fête du travail', 20),
(415, 'Lundi de Pâques', 20),
(416, 'Lundi de Pentecôte', 20),
(417, 'Assomption de Marie', 20),
(418, 'Jour du Non', 20),
(419, 'Noël', 20),
(420, 'Gloire à la mère du Christ', 20),
(421, 'Nouvel An', 21),
(422, 'Libération du Sinaï', 21),
(423, 'Fête du Travail', 21),
(424, 'Anniversaire de la République', 21),
(425, 'Fête de la Libération', 21),
(426, 'Fête des forces armées', 21),
(427, 'Jour de Suez', 21),
(428, 'Jour de la Victoire', 21),
(429, 'Noël copte', 21),
(430, 'Sham el-Nassim', 21),
(431, 'Aid el Fitr', 21),
(432, 'Aid el Adha', 21),
(433, 'El am Hejir', 21),
(434, 'Mouled naissance du Prophète', 21),
(435, 'Nouvel AN', 22),
(436, 'Journée de la souveraineté nationale et des enfants', 22),
(437, 'Fête du Travail', 22),
(438, 'Journée de Commémoration d\'Ataturk de la Jeunesse et des Sports', 22),
(439, 'Journée de la Démocratie et de l\'Unité nationale', 22),
(440, 'Jour de la Victoire', 22),
(441, 'Fête de la République', 22),
(442, 'Aïd el-Fitr', 22),
(443, 'Aïd El Adha', 22);

-- --------------------------------------------------------

--
-- Structure de la table `sous_sous_categorie`
--

CREATE TABLE `sous_sous_categorie` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) DEFAULT NULL,
  `sous_categorie_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `sous_sous_categorie`
--

INSERT INTO `sous_sous_categorie` (`id`, `titre`, `sous_categorie_id`) VALUES
(1, 'sweats', 1),
(2, 'Robes', 1),
(3, 'Hauts et t-shirts', 1),
(4, 'Pantalons et leggings', 1),
(5, 'Combinaisons', 1),
(6, 'Lingerie et pyjamas', 1),
(7, 'Vêtements de sport', 1),
(8, 'Manteaux', 1),
(9, 'Blazers et tailleurs', 1),
(10, 'Jupes', 1),
(11, 'Jeans', 1),
(12, 'Shorts', 1),
(13, 'Maillot de bain', 1),
(15, 'Costumes et tenues particulieres', 1),
(16, 'Autres', 1),
(17, 'Mocassins et chaussures bateaux', 2),
(18, 'Mules et sabot', 2),
(19, 'Claquettes et tongs', 2),
(21, 'Chaussures avec lacets', 2),
(22, 'Sandales', 2),
(23, 'Chaussures de sport', 2),
(24, 'Ballerines', 2),
(25, 'Bottes', 2),
(26, 'Espadrilles', 2),
(27, 'Chaussures avec talons', 2),
(28, 'Babies et Mary-Jane', 2),
(29, 'Chaussons et pantoufles', 2),
(30, 'Baskets', 2),
(31, 'Sacs de plage', 3),
(32, 'Sacs seau', 3),
(33, 'Pochettes', 3),
(34, 'Sacs de sport', 3),
(35, 'Besaces', 3),
(36, 'Sacs de voyage', 3),
(38, 'Maternité', 1),
(39, 'Cartables et sacoches', 3),
(40, 'Sacs fourre-tout', 3),
(42, 'Wristlets', 3),
(43, 'Sacs a dos', 3),
(44, 'Mallettes', 3),
(45, 'Sacs banane', 3),
(46, 'Housses pour vêtements', 3),
(47, 'Sacs a mains', 3),
(48, 'Fourre-tout et sacs marins', 3),
(49, 'Trousses à maquillage', 3),
(50, 'Sacs en bandouliere', 3),
(51, 'Porte-monnaie', 3),
(52, 'Ceintures', 4),
(53, 'Accesoires pour cheveux', 4),
(54, 'Chapeaux & casquettes', 4),
(55, 'Porte-clés', 4),
(56, 'Lunettes de soleil', 4),
(57, 'Montres', 4),
(58, 'Bandanas et foulards', 4),
(59, 'Gants', 4),
(60, 'Mouchoirs de poche', 4),
(61, 'Bijoux', 4),
(62, 'Echarpes et châles', 4),
(63, 'Parapluies', 4),
(64, 'Autres accessoires', 4),
(65, 'Parfums', 5),
(66, 'Accessoires de beauté', 5),
(67, 'Manucure', 5),
(68, 'Soins cheveux', 5),
(69, 'Maquillage', 5),
(70, 'Soins visage', 5),
(71, 'Soins mains', 5),
(72, 'Soins du corps', 5),
(73, 'Autres cosmétiques et accessoires', 5),
(74, 'Manteaux et vestes', 6),
(75, 'Costumes et blazers', 6),
(76, 'Pantalons', 6),
(77, 'Sous-vetements et chaussettes', 6),
(78, 'Maillots de bain', 6),
(79, 'Jeans', 6),
(80, 'Hauts et t-shirts', 6),
(81, 'Sweats et pulls', 6),
(82, 'Shorts', 6),
(83, 'Pyjamas', 6),
(84, 'Vetements de sport', 6),
(85, 'Bottes', 7),
(86, 'Espadrilles', 7),
(87, 'Chaussures habillées', 7),
(88, 'Chaussons et pantoufles', 7),
(89, 'Baskets', 7),
(90, 'Mocassins et chaussures bateaux', 7),
(91, 'Mules et sabots', 7),
(92, 'Claquettes et tongs', 7),
(93, 'Sandales', 7),
(94, 'Chaussures de sport', 7),
(95, 'Bandanas et foulards pour cheveux', 8),
(96, 'Bretelles', 8),
(97, 'Mouchoirs de poche', 8),
(98, 'Bijoux', 8),
(99, 'Echarpes et châles', 8),
(100, 'Cravates et nœuds papillons', 8),
(101, 'Sacs et sacoches', 8),
(102, 'Ceintures', 8),
(103, 'Gants', 8),
(104, 'Chapeaux & casquettes', 8),
(105, 'Pochettes de costume', 8),
(106, 'Lunettes de soleil', 8),
(107, 'Montres', 8),
(108, 'Autres', 8),
(110, 'Accessoires', 9),
(111, 'Soins du corps', 9),
(112, 'Parfums', 9),
(113, 'Coffrets', 9),
(114, 'Soins visage', 9),
(115, 'Soins cheveux', 9),
(116, 'Soins mains et ongles', 9),
(117, 'Maquillage', 9),
(118, 'Autres cosmetiques', 9),
(119, 'Chaussures de créateurs', 10),
(120, 'Vêtements de créateurs', 10),
(121, 'Sacs de créateurs', 10),
(122, 'Accessoires de créateurs', 10),
(123, 'Accessoires de créateurs', 11),
(124, 'Chaussures de créateurs', 11),
(125, 'Vêtements de créateurs', 11),
(126, 'Chaussures', 12),
(127, 'Pulls & sweats', 12),
(128, 'Robes', 12),
(129, 'Pantalons et shorts', 12),
(130, 'Accessoires', 12),
(131, 'Sous-vêtements', 12),
(132, 'Vêtements de sport', 12),
(133, 'Jumeaux et plus', 12),
(134, 'Tenue de soirée', 12),
(135, 'Bébé filles', 12),
(136, 'Vêtements extérieur', 12),
(137, 'Chemises et t-shirts', 12),
(138, 'Jupes', 12),
(139, 'Sac et sac à dos', 12),
(140, 'Equipement de natation', 12),
(141, 'Pyjamas et chemises de nuit', 12),
(142, 'lots de vêtements', 12),
(143, 'Déguisements', 12),
(144, 'Autres', 12),
(145, 'Chaussures', 13),
(146, 'Pull & sweats', 13),
(147, 'Pantalons et shorts', 13),
(148, 'Accessoires', 13),
(149, 'Sous-vêtements', 13),
(150, 'Vêtements de sport', 13),
(151, 'Jumeaux et plus', 13),
(152, 'Tenues de soirée', 13),
(153, 'Bébé garçons', 13),
(154, 'Vêtements extérieur', 13),
(155, 'Chemises et t-shirts', 13),
(156, 'Sac et sac a dos', 13),
(157, 'Equipement de natation', 13),
(158, 'Pyjamas', 13),
(159, 'Lots de vetements', 13),
(160, 'Deguisements', 13),
(161, 'Autres', 13),
(162, 'Jeux et jouets electroniques', 14),
(163, 'Jeux educatifs', 14),
(164, 'Hochets & anneaux', 14),
(165, 'Jeux de construction', 14),
(166, 'Doudous', 14),
(167, 'Figurines', 14),
(168, 'Poupees, poupons et accessoires', 14),
(169, 'Peluches', 14),
(170, 'Jeux & jouets musicaux', 14),
(171, 'Jouets en bois', 14),
(172, 'Vaisselles pour enfant', 15),
(173, 'Equipements de natation', 15),
(174, 'Accessoires pratiques', 15),
(175, 'Bavoirs', 15),
(176, 'Sécurité et protection enfant', 15),
(177, 'Linge de lit', 15),
(178, 'Porte-bebe et echarpes de portage', 15),
(179, 'Couches et soins', 15),
(180, 'Balançoires et sauteuses', 15),
(181, 'Pots', 15),
(182, 'Poussette sport', 16),
(183, 'Poussettes pour jumeaux', 16),
(184, 'Poussettes-cannes', 16),
(185, 'Poussettes polyvalentes', 16),
(186, 'Accessoires de poussette', 16),
(187, 'Jouets  a tirer et a pousser', 17),
(188, 'Trotinettes', 17),
(189, 'Velo', 17),
(190, 'Luges et skis et snowboards', 17),
(191, 'Trotteurs', 17),
(192, 'Sieges velo et remorques', 17),
(193, 'Tricycles', 17),
(194, 'Vehicules de plein air', 17),
(195, 'Chaises hautes', 18),
(196, 'Sieges auto', 18),
(197, 'Lits a barreaux', 19),
(198, 'Matelas pour lits bebe et enfant', 19),
(199, 'Parcs', 19),
(200, 'Mobiliers enfant', 19),
(201, 'Berceaux et couffins', 19),
(202, 'Lits enfants', 19),
(203, 'Tapis de sol et dalles en mousse', 19),
(204, 'Matelas a langer', 19),
(205, 'Fournitures scolaires', 20),
(206, 'Cartables', 20),
(207, 'Couvertures', 23),
(208, 'Coussins decoratifs', 23),
(209, 'Linge de table', 23),
(210, 'Serviettes', 23),
(211, 'Linge de lit', 23),
(212, 'Rideaux et voilages', 23),
(213, 'Tapis', 23),
(214, 'Tapisseries decoratives', 23),
(215, 'Horloges', 24),
(216, 'Encadrements', 24),
(217, 'Rangements', 24),
(218, 'Bougies & bougeoirs', 24),
(219, 'Etageres murales', 24),
(220, 'Miroirs', 24),
(221, 'Vases', 24),
(222, 'Vaisselle', 25),
(223, 'Couverts', 25),
(224, 'Verres', 25),
(225, 'Cartes et enveloppes', 26),
(226, 'Papier cadeau et sacs', 26),
(227, 'Accessoires de fete', 26),
(228, 'Decorations pour le sapin', 26),
(229, 'Banderoles & drapeaux et guirlandes', 26),
(230, 'Lumieres decoratives', 26),
(231, 'Decorations festives', 26),
(232, 'Decorations de table', 26),
(234, 'gun', 8);

-- --------------------------------------------------------

--
-- Structure de la table `trace_connexion_user`
--

CREATE TABLE `trace_connexion_user` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_ip` varchar(255) DEFAULT NULL,
  `browser` varchar(255) DEFAULT NULL,
  `login_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `trace_connexion_user`
--

INSERT INTO `trace_connexion_user` (`id`, `user_id`, `user_ip`, `browser`, `login_date`) VALUES
(1, 1, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0', '2024-11-08 15:46:08'),
(2, 1, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0', '2024-11-08 15:58:41'),
(3, 2, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0', '2024-11-08 16:45:04'),
(4, 2, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0', '2024-11-09 10:38:19'),
(5, 1, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0', '2024-11-18 08:41:16'),
(6, 8, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0', '2024-11-18 08:42:38'),
(7, 9, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0', '2024-11-20 10:26:39'),
(8, 1, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0', '2024-11-26 15:00:30'),
(9, 1, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0', '2025-09-09 02:07:04'),
(10, 3, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0', '2025-09-15 10:41:45'),
(11, 1, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0', '2025-09-15 22:44:06'),
(12, 1, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G955U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36 Edg/140.0.0.0', '2025-09-16 10:28:13'),
(13, 1, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0', '2025-09-29 11:51:02'),
(14, 3, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0', '2025-09-30 14:27:10'),
(15, 1, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0', '2025-09-30 14:30:02'),
(16, 3, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0', '2025-09-30 14:31:28'),
(17, 1, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0', '2025-10-01 11:57:12'),
(18, 1, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0', '2025-10-03 10:49:27'),
(19, 5, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0', '2025-10-08 10:15:16'),
(20, 1, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-08 14:48:35'),
(21, 6, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-08 14:50:37'),
(22, 6, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-08 15:09:31'),
(23, 1, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-08 15:22:08'),
(24, 3, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-08 15:26:15'),
(25, 1, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-08 15:34:31'),
(26, 7, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-08 15:35:52'),
(27, 4, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-21 22:35:26'),
(28, 8, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-22 11:41:04'),
(29, 4, '0:0:0:0:0:0:0:1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', '2025-10-22 11:47:49');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mot_de_passe` varchar(255) DEFAULT NULL,
  `date_inscription` datetime DEFAULT current_timestamp(),
  `date_connexion` datetime DEFAULT current_timestamp(),
  `ville` varchar(255) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `photo_profil` varchar(255) DEFAULT NULL,
  `isBanned` tinyint(1) DEFAULT NULL,
  `adresse` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `nom`, `email`, `mot_de_passe`, `date_inscription`, `date_connexion`, `ville`, `description`, `photo_profil`, `isBanned`, `adresse`) VALUES
(1, 'Sophie', 'sophie@sophie', '$2a$12$9.BjzK3ivkF.1eMuY0pu6uyp.9tMWWDov0zqPwQac08DhGkRL8pZ2', '2025-03-03 12:51:16', NULL, NULL, NULL, NULL, 0, NULL),
(3, 'Jonathan', 'jonat@jonat', '$2a$12$MHMRa9XuSLZKVzsBSUyHzuVtdYdIO9UHPWw0.ZkIBlrWax8ihGNYS', '2025-05-18 15:36:01', NULL, NULL, NULL, NULL, 0, NULL),
(4, 'didier', 'didier@didier', '$2a$12$XOWnCjJHGB24JZqwRD0E4eh8nhV0GkG.vPbBZgwL3AefvqPSrSsM6', '2025-08-13 09:16:46', NULL, NULL, NULL, NULL, 0, NULL),
(5, 'Kalee', 'kalee@kalee', '$2a$12$bwNNOEgZIY51shBFjxgUZeX/bqbxatvvhMT5te5AsvSdMhqNC1qs.', '2025-10-08 11:46:01', NULL, NULL, NULL, NULL, 0, NULL),
(6, 'Atlante', 'atlante@atlante', '$2a$12$nVoeB0QvmTF56UvOezFQ0ecfCjtzc7nrgKTf7tp0kNMvJ2yfLnkEi', '2025-10-08 16:50:13', NULL, NULL, NULL, NULL, 0, NULL),
(7, 'andy', 'andy@andy', '$2a$12$XiQXP/aY12Ch85dvU8/xjOd3RmnPKuR5uE88E5YKaTwDDbpX.uq3W', '2025-10-08 17:35:20', NULL, NULL, NULL, NULL, 0, NULL),
(8, 'ARTHUR', 'arthur@arthur', '$2a$12$0ajxlDY5JBftw55uVLJajel3kE4L3xn3iEIO4Wo6wwAW1/N9E1Nte', '2025-10-22 13:40:42', NULL, NULL, NULL, NULL, 0, NULL);

--
-- Déclencheurs `utilisateur`
--
DELIMITER $$
CREATE TRIGGER `avant_inscription` BEFORE INSERT ON `utilisateur` FOR EACH ROW BEGIN
DECLARE email_existe INT;
SELECT COUNT(*) INTO email_existe FROM utilisateur
WHERE email = NEW.email;
IF email_existe > 0 THEN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'cet email existe déjà dans la base de données.';
END IF;
END
$$
DELIMITER ;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `actegorie`
--
ALTER TABLE `actegorie`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `administrateur`
--
ALTER TABLE `administrateur`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_idutila` (`utilisateur_id`),
  ADD KEY `fk_idsscata` (`sous_sous_categorie_id`),
  ADD KEY `fk_idssacta` (`sous_sous_actegorie_id`);

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_idutilcom` (`utilisateur_id`);

--
-- Index pour la table `conversation`
--
ALTER TABLE `conversation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `participant1_id` (`participant1_id`),
  ADD KEY `participant2_id` (`participant2_id`),
  ADD KEY `fk_idartconv` (`article_id`);

--
-- Index pour la table `evaluation`
--
ALTER TABLE `evaluation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_idevaleval` (`evaluateur_id`),
  ADD KEY `fk_idvalueeval` (`evalue_id`);

--
-- Index pour la table `favori`
--
ALTER TABLE `favori`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_idutilf` (`utilisateur_id`),
  ADD KEY `fk_idartf` (`article_id`);

--
-- Index pour la table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_idutilex` (`expediteur_id`),
  ADD KEY `fk_idutildest` (`destinataire_id`),
  ADD KEY `fk_idartm` (`article_id`),
  ADD KEY `fk_idconvers` (`conversation_id`);

--
-- Index pour la table `offre`
--
ALTER TABLE `offre`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_idutilo` (`utilisateur_id`),
  ADD KEY `fk_idarto` (`article_id`);

--
-- Index pour la table `photo_article`
--
ALTER TABLE `photo_article`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_idartpa` (`article_id`);

--
-- Index pour la table `recherche`
--
ALTER TABLE `recherche`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_idutilr` (`utilisateur_id`);

--
-- Index pour la table `resume_commande`
--
ALTER TABLE `resume_commande`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_idcomresco` (`commande_id`),
  ADD KEY `fk_idart` (`article_id`);

--
-- Index pour la table `sous_actegorie`
--
ALTER TABLE `sous_actegorie`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_idactsa` (`actegorie_id`);

--
-- Index pour la table `sous_categorie`
--
ALTER TABLE `sous_categorie`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_idcatsc` (`categorie_id`);

--
-- Index pour la table `sous_sous_actegorie`
--
ALTER TABLE `sous_sous_actegorie`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_idssactsa` (`sous_actegorie_id`);

--
-- Index pour la table `sous_sous_categorie`
--
ALTER TABLE `sous_sous_categorie`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_idsscatsc` (`sous_categorie_id`);

--
-- Index pour la table `trace_connexion_user`
--
ALTER TABLE `trace_connexion_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_iduser` (`user_id`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `actegorie`
--
ALTER TABLE `actegorie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `administrateur`
--
ALTER TABLE `administrateur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `commande`
--
ALTER TABLE `commande`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `conversation`
--
ALTER TABLE `conversation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `evaluation`
--
ALTER TABLE `evaluation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `favori`
--
ALTER TABLE `favori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT pour la table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT pour la table `offre`
--
ALTER TABLE `offre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `photo_article`
--
ALTER TABLE `photo_article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT pour la table `recherche`
--
ALTER TABLE `recherche`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT pour la table `resume_commande`
--
ALTER TABLE `resume_commande`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `sous_actegorie`
--
ALTER TABLE `sous_actegorie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT pour la table `sous_categorie`
--
ALTER TABLE `sous_categorie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT pour la table `sous_sous_actegorie`
--
ALTER TABLE `sous_sous_actegorie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=447;

--
-- AUTO_INCREMENT pour la table `sous_sous_categorie`
--
ALTER TABLE `sous_sous_categorie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=236;

--
-- AUTO_INCREMENT pour la table `trace_connexion_user`
--
ALTER TABLE `trace_connexion_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `fk_idssacta` FOREIGN KEY (`sous_sous_actegorie_id`) REFERENCES `sous_sous_actegorie` (`id`),
  ADD CONSTRAINT `fk_idsscata` FOREIGN KEY (`sous_sous_categorie_id`) REFERENCES `sous_sous_categorie` (`id`),
  ADD CONSTRAINT `fk_idutila` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `fk_idutilcom` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `conversation`
--
ALTER TABLE `conversation`
  ADD CONSTRAINT `conversation_ibfk_1` FOREIGN KEY (`participant1_id`) REFERENCES `utilisateur` (`id`),
  ADD CONSTRAINT `conversation_ibfk_2` FOREIGN KEY (`participant2_id`) REFERENCES `utilisateur` (`id`),
  ADD CONSTRAINT `fk_idartconv` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`);

--
-- Contraintes pour la table `evaluation`
--
ALTER TABLE `evaluation`
  ADD CONSTRAINT `fk_idevaleval` FOREIGN KEY (`evaluateur_id`) REFERENCES `utilisateur` (`id`),
  ADD CONSTRAINT `fk_idvalueeval` FOREIGN KEY (`evalue_id`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `favori`
--
ALTER TABLE `favori`
  ADD CONSTRAINT `fk_idartf` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`),
  ADD CONSTRAINT `fk_idutilf` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `fk_idartm` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`),
  ADD CONSTRAINT `fk_idconvers` FOREIGN KEY (`conversation_id`) REFERENCES `conversation` (`id`),
  ADD CONSTRAINT `fk_idutildest` FOREIGN KEY (`destinataire_id`) REFERENCES `utilisateur` (`id`),
  ADD CONSTRAINT `fk_idutilex` FOREIGN KEY (`expediteur_id`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `offre`
--
ALTER TABLE `offre`
  ADD CONSTRAINT `fk_idarto` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`),
  ADD CONSTRAINT `fk_idutilo` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `photo_article`
--
ALTER TABLE `photo_article`
  ADD CONSTRAINT `fk_idartpa` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`);

--
-- Contraintes pour la table `recherche`
--
ALTER TABLE `recherche`
  ADD CONSTRAINT `fk_idutilr` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `resume_commande`
--
ALTER TABLE `resume_commande`
  ADD CONSTRAINT `fk_idart` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`),
  ADD CONSTRAINT `fk_idcomresco` FOREIGN KEY (`commande_id`) REFERENCES `commande` (`id`);

--
-- Contraintes pour la table `sous_actegorie`
--
ALTER TABLE `sous_actegorie`
  ADD CONSTRAINT `fk_idactsa` FOREIGN KEY (`actegorie_id`) REFERENCES `actegorie` (`id`);

--
-- Contraintes pour la table `sous_categorie`
--
ALTER TABLE `sous_categorie`
  ADD CONSTRAINT `fk_idcatsc` FOREIGN KEY (`categorie_id`) REFERENCES `categorie` (`id`);

--
-- Contraintes pour la table `sous_sous_actegorie`
--
ALTER TABLE `sous_sous_actegorie`
  ADD CONSTRAINT `fk_idssactsa` FOREIGN KEY (`sous_actegorie_id`) REFERENCES `sous_actegorie` (`id`);

--
-- Contraintes pour la table `sous_sous_categorie`
--
ALTER TABLE `sous_sous_categorie`
  ADD CONSTRAINT `fk_idsscatsc` FOREIGN KEY (`sous_categorie_id`) REFERENCES `sous_categorie` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
